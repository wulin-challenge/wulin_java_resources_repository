var str = '';
str += '<object id="SignatureAPI" width="0" height="0" classid="clsid:79F9A6F8-7DBE-4098-A040-E6E0C3CF2001" codebase=""iSignatureAPI.ocx#version=8,0,0,0">';
str += '</object>';
document.write(str);