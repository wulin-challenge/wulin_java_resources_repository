package com.seeyon.v3x.plugin.azt.po;

import java.io.Serializable;

import com.seeyon.ctp.common.po.BasePO;
/**
 * 
 * 客开 项目名称：新疆兵团 作者：wangyinan 修改日期：2014-05-20 [修改功能：安证通盖章] start
 * 
 */
public class MYAZTSignDataPO extends BasePO implements Serializable {


	private static final long serialVersionUID = 3779413525957590461L;

	private String signdata; //签章数据
	
	private String fid;//签章文件
	
	private String flink;//签章环节

	private String signdate;//签章时间

	public MYAZTSignDataPO() {

	}

	/**
	 * @return the signdata
	 */
	public String getSigndata() {
		return signdata;
	}

	/**
	 * @param signdata
	 *            the signdata to set
	 */
	public void setSigndata(String signdata) {
		this.signdata = signdata;
	}

	public String getFid() {
		return fid;
	}

	public void setFid(String fid) {
		this.fid = fid;
	}

	public String getFlink() {
		return flink;
	}

	public void setFlink(String flink) {
		this.flink = flink;
	}

	public String getSigndate() {
		return signdate;
	}

	public void setSigndate(String signdate) {
		this.signdate = signdate;
	}

}
/**
 * 
 * 客开 项目名称：新疆兵团 作者：wangyinan 修改日期：2014-05-20 [修改功能：安证通盖章] end
 * 
 */
