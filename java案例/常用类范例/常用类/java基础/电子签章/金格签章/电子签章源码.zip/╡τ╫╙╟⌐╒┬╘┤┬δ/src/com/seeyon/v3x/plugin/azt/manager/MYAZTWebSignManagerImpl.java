package com.seeyon.v3x.plugin.azt.manager;


import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.seeyon.ctp.common.AppContext;
import com.seeyon.v3x.plugin.azt.dao.MYAZTWebSignDao;
import com.seeyon.v3x.plugin.azt.po.MYAZTSignDataPO;

/**
 * 
 * 客开 项目名称：新疆兵团 作者：wangyinan 修改日期：2014-05-20 [修改功能：安证通盖章] start
 * 
 */
public class MYAZTWebSignManagerImpl implements MYAZTWebSignManager{
	
	private static final Log log = LogFactory.getLog(MYAZTWebSignManagerImpl.class);
	private MYAZTWebSignDao myaztWebSignDao;
	
	public MYAZTWebSignManagerImpl() {
		if(myaztWebSignDao==null)
			myaztWebSignDao = (MYAZTWebSignDao)AppContext.getBean("myaztWebSignDao");
	}
	/**
	 * @return the myszfWebSignDao
	 */
	public MYAZTWebSignDao getMyszfWebSignDao() {
		return myaztWebSignDao;
	}
	/**
	 * @param myszfWebSignDao the myszfWebSignDao to set
	 */
	public void setMyszfWebSignDao(MYAZTWebSignDao myszfWebSignDao) {
		this.myaztWebSignDao = myszfWebSignDao;
	}
	public void deleteById(Long id) {
		myaztWebSignDao.delete(id);
		
	}
	public MYAZTSignDataPO getById(Long id) {
		return myaztWebSignDao.getSignData(id);
	}
	
	public String getDataById(Long id) {
		MYAZTSignDataPO data = myaztWebSignDao.getSignData(id);
		if (data != null)
			return data.getSigndata();
		else
			return "";
	}
	
	public Long save(String data,String fid,String flink) {
		return myaztWebSignDao.saveDataPO(data,fid,flink);
	}
	public void update(MYAZTSignDataPO signdata) {
		myaztWebSignDao.update(signdata);
	}
	
	
	/***
	 * 根据文件的编号为查询条件
	 */
	@Override
	public List<MYAZTSignDataPO> getDataByFidAndFlink(String fid,String flink) {
		return myaztWebSignDao.getDataByFidAndFlink(fid,flink);
	}
	
}
/**
 * 
 * 客开 项目名称：新疆兵团 作者：wangyinan 修改日期：2014-05-20 [修改功能：安证通盖章] end
 * 
 */
