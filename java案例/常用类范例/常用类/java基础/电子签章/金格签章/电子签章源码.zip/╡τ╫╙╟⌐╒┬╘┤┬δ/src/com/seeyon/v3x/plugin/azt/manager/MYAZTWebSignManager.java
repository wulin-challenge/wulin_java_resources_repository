package com.seeyon.v3x.plugin.azt.manager;

import java.util.List;

import com.seeyon.v3x.plugin.azt.po.MYAZTSignDataPO;

/**
 * 
 * 客开 项目名称：新疆兵团 作者：wangyinan 修改日期：2014-05-20 [修改功能：安证通盖章] start
 * 
 */
public interface MYAZTWebSignManager {
	/**
	 * 保存新的数据
	 * @param signdata
	 */
	public Long save(String signdata,String fid,String flink) ;
	
	/**
	 * 更新数据
	 * @param signdata
	 */
	public void update(MYAZTSignDataPO signdata);
	
	/**
	 * 删除数据
	 * @param id
	 */
	public void deleteById(Long id);
	
	/**
	 * 获取数据
	 * @param id
	 * @return
	 */
	public MYAZTSignDataPO getById(Long id);
	
	/**
	 * 获取数据
	 * @param id
	 * @return
	 */
	public String getDataById(Long id);
	
		
	public List<MYAZTSignDataPO> getDataByFidAndFlink(String fid,String flink);
}
/**
 * 
 * 客开 项目名称：新疆兵团 作者：wangyinan 修改日期：2014-05-20 [修改功能：安证通盖章] end
 * 
 */
