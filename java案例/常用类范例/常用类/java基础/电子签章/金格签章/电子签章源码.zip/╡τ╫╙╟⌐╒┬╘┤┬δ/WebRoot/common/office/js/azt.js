﻿/*客开 项目名称：新疆兵团项目  作者：wangyinan 修改日期：2014-5-20 [修改功能：安证通电子签章修改]start */
var aztobjname ;
// 获取页面中指定ID的元素的坐标
    function Get_OCX_Original_XY(objID) {
        var element = document.getElementById(objID);
        if (arguments.length != 1 || element == null) {
            return null;
        }
        var offsetTop = element.offsetTop;
        var offsetLeft = element.offsetLeft;

        var current = element.offsetParent;　　
        while (current !== null) {
            offsetTop += current.offsetTop;
            offsetLeft += current.offsetLeft;
            current = current.offsetParent;　　　　
        }

        var labels = new Array(offsetTop, offsetLeft);
        return labels;
    }

   
	function moveControl(c, a, b)
	{
      	if(c==null || c.length<=0)
			c=aztobjname;
		if(a<0 || b<0)
		{
		  var element = window.document.getElementById(c);
         a = element.offsetTop;
         b = element.offsetLeft;
        }		
		doMove(a, b, c);
	}
	function doMove(a, b, c)
	{
		document.all[c].style.visibility = "hidden";
		var nw = document.all[c].style.pixelWidth;
		var nh = document.all[c].style.pixelHeight;
		document.all[c].style.left = a;
		document.all[c].style.top = b;
		document.all[c].style.visibility = "visible";
	} 
    // 注意：网页中必须要定义该脚本，否则无法完成印章控件大小的初始化
    function resizeControl(c, a, b)
	{
		if(c==null || c.length<=0)
			c=aztobjname;
		doResizeControl(a, b, c);
	}
	function doResizeControl(a, b, c)
	{
		document.all[c].style.visibility = "hidden";
		document.all[c].style.pixelWidth = a;
		document.all[c].style.pixelHeight = b;
		document.all[c].style.visibility = "visible";
	}
    function addSign(objName) {
		var control = objName;
		aztobjname = objName;
        // 取得当前表单的名称：用于签章服务中记录签章日志
        var name ;//= document.getElementById("dataName_"+controlId).value;
		name = "signData";
        var sealControl = document.getElementById(objName);
       	// 缺省为电子私章
       	var sealType = 2;
       //	if (controlId == "AztSow2")
       	//	sealType = 2;
       		

        sealControl.SetSealMode("ONE");
        sealControl.SetSealFlag(sealType);
        sealControl.ESASetProperty("LEFT", 0);
        sealControl.ESASetProperty("TOP", 0);
        sealControl.SetSealMove("MOVE");
        var lRet = sealControl.ESAOnAddNew(name, sealType, 0, "");
        if (lRet != 0) {
			//alert("error"+lRet);
        	sealControl.ESAShowErrorMsg(lRet);
		}
        else {
        	// 计算印章摆放位置的偏移量（印章宽和高的一半的负数）
        	var w = sealControl.ESAGetWidth();
        	var h = sealControl.ESAGetHeight();
        	moveControl(objName, -(w / 2), -(h / 2));
        }
    }

	  // 注意：网页中必须要定义该脚本函数，否则印章控件无法获取网页中被保护的数据
    function ESAGetData(control) {
    	// alert("ID为："+ control + " 的控件，正在通过网页中的脚本获取需要保护的数据或需要验证的数据！");
		var str = ""
    	// 本示例中，两个印章控件都统一用相同的数据
    	//var title = document.getElementById("title").value;
		return str ; 
    }
/* 当页面没有objcet对象的时候就需要创建该对象 */
function createObject(objName,affairId){
var hwObj = document.getElementById(objName);
  if(hwObj==null){
	var recordId ,actorid;
	aztobjname = objName;
	//获取对象，并且分解，中间使用下划线分解
	if(objName!=null && objName.indexOf("_") > 0 ){
		recordId=objName.substring(objName.indexOf("_")+1,objName.length);
		actorid = objName.substring(0,objName.indexOf("_"));
	}
	var insertObj =document.getElementById(affairId);
	if(insertObj!=null){
		hwObj=createHandWrite(objName,"",recordId,insertObj,false,affairId);
	}
  }
return hwObj;
}
//新的页面中状态盖章信息
function aztloadPage(objName,flink){
    var s2 = createObject(objName,flink);
	aztobjname = objName;
	var objNameda = objName;
	//alert(objName.indexOf("##")); //查看盖章中是否有##,则表示为load载入内容
	if(objName!=null && objName.indexOf("##")>0){
		objNameda = objName.substring(0,objName.indexOf("##"));
	}
	var datainfo = getSignData(objNameda,flink);
	if(s2!=null){
		// 加载个人私章
		s2.ESAVerifySowSign(datainfo, datainfo.length);
				
				// 计算印章的位置偏移量
		var w = s2.ESAGetWidth();
		var h = s2.ESAGetHeight();
		moveControl(aztobjname, -(w / 2), -(h / 2));	
	}
}

var objdata = "";
//获取数据对象
function getSignData(fid,flink) {
  jQuery.ajax({
	type: "post",
	url: '/seeyon/aztSign.do?method=getData',
	data:"fid="+ fid+"&flink="+flink,
	dataType: 'json',
	async:false,
	success: function(result){
		if(result.success=="true"){						
		  objdata=result.datainfo;
		}else{
		  objdata= "";
		}
	}
  });  
 return objdata;
}

function getAffairIdByFid(fid) {
  jQuery.ajax({
	type: "post",
	url: '/seeyon/aztSign.do?method=getAffairIdByFid',
	data:"fid="+ fid,
	dataType: 'json',
	async:false,
	success: function(result){
		if(result!=null){
			if(result.success=="true"){		
			  objdata=result.affids;
			}else{
			  objdata= "";
			}
		}
	}
  });  
 return objdata;
}

//获取数据对象
function saveAztData(fid,flink,data) {
var ret = "false";
  jQuery.ajax({
	type: "post",
	url: '/seeyon/aztSign.do?method=newData',
	data:"fid="+ fid+"&flink="+flink+"&data="+data,
	dataType: 'json',
	async:false,
	success: function(result){
		if(result.success=="true"){						
			ret= "true";
		}else
			ret= "false";
	}
  }); 
  return ret;
}

function getAffrie(){
	initSpans();
	opinionSpans
}

/*客开 项目名称：新疆兵团项目  作者：wangyinan 修改日期：2014-5-20 [修改功能：安证通电子签章修改]end */