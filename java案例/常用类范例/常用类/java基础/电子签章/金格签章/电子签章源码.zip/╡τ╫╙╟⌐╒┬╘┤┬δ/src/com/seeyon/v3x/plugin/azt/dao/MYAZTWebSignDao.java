package com.seeyon.v3x.plugin.azt.dao;

import java.util.List;

import com.seeyon.ctp.common.dao.CTPBaseDao;
import com.seeyon.v3x.plugin.azt.po.MYAZTSignDataPO;
/**
 * 
 * 客开 项目名称：新疆兵团 作者：wangyinan 修改日期：2014-05-20 [修改功能：安证通盖章] start
 * 
 */
public abstract interface MYAZTWebSignDao extends CTPBaseDao<MYAZTSignDataPO> {

	public MYAZTSignDataPO getSignData(Long id);

	public Long saveDataPO(String data, String fid, String flink);

	public void deleteDataPO(Long id);

	public List<MYAZTSignDataPO> getDataByFidAndFlink(String fid, String flink);
}
/**
 * 
 * 客开 项目名称：新疆兵团 作者：wangyinan 修改日期：2014-05-20 [修改功能：安证通盖章] end
 * 
 */
