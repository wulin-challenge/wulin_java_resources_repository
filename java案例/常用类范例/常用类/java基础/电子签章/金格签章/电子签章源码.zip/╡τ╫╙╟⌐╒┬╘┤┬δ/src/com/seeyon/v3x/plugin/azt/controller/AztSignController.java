package com.seeyon.v3x.plugin.azt.controller;

import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.web.servlet.ModelAndView;

import com.seeyon.ctp.common.AppContext;
import com.seeyon.v3x.common.web.BaseController;
import com.seeyon.v3x.plugin.azt.manager.MYAZTWebSignManager;
import com.seeyon.v3x.plugin.azt.po.MYAZTSignDataPO;

/**
 * 
 * 客开 项目名称：新疆兵团 作者：wangyinan 修改日期：2014-05-20 [修改功能：安证通盖章] start
 * 
 */
public class AztSignController extends BaseController {
	private static final Log log = LogFactory.getLog(AztSignController.class);
	private MYAZTWebSignManager myAZTWebSignManager;

	public MYAZTWebSignManager getMyAZTWebSignManager() {
		return myAZTWebSignManager;
	}

	public void setMyAZTWebSignManager(MYAZTWebSignManager myAZTWebSignManager) {
		this.myAZTWebSignManager = myAZTWebSignManager;
	}
	
	/*
	 * 保存数据
	 */
	public ModelAndView newData(HttpServletRequest request,HttpServletResponse response) throws Exception {
		String data = request.getParameter("data");
		String fid = request.getParameter("fid");
		String flink = request.getParameter("flink");
		myAZTWebSignManager = (MYAZTWebSignManager)AppContext.getBean("myAZTWebSignManager");
		PrintWriter out = response.getWriter(); 
		try {
			List<MYAZTSignDataPO> ls = myAZTWebSignManager.getDataByFidAndFlink(fid,flink);
			if(ls!=null && ls.size()>0){
				MYAZTSignDataPO sign = ls.get(0);
				myAZTWebSignManager.deleteById(sign.getId());
			}
			Long id = myAZTWebSignManager.save(data,fid,flink);
			//out.print(id);
			String success =(id!=null && id>0)?"true":"false";
			JSONObject json = new JSONObject();
			json.putOpt("id", id);
			json.putOpt("success", success);
			out.println(json.toString());
		}
		catch (Exception e) {
			e.printStackTrace();
			log.error("保存安正通签章数据异常 ", e);
		}
		return null;
	}
	
	/*
	 * 获取数据
	 */
	public ModelAndView getData(HttpServletRequest request,HttpServletResponse response) throws Exception {
		//获得文件的id标识 并且获取当前的节点信息
		String fid = request.getParameter("fid");
		String flink = request.getParameter("flink");
		PrintWriter out = response.getWriter(); 
		String datainfo="";
		try {
			//Long id = new Long(fid);
			List<MYAZTSignDataPO> ls = myAZTWebSignManager.getDataByFidAndFlink(fid,flink);
			if (ls != null && ls.size()>0){
				MYAZTSignDataPO data= ls.get(0);
				datainfo = data.getSigndata();
			}
			
			String success =(datainfo!=null && datainfo.length()>0)?"true":"false";
			JSONObject json = new JSONObject();
			json.putOpt("datainfo", datainfo);
			json.putOpt("success", success);
			out.println(json.toString());
		}
		catch (Exception e) {
			e.printStackTrace();
			log.error("获取安正通签章数据异常", e);
		}
		return null;
	}
	
	/*
	 * 获取数据
	 */
	public ModelAndView updateData(HttpServletRequest request,HttpServletResponse response) throws Exception {
		String ids = request.getParameter("id");
		String data = request.getParameter("data");
		PrintWriter out = null; 
		try {
			MYAZTSignDataPO datas = new MYAZTSignDataPO();
			datas.setId(new Long(ids));
			datas.setSigndata(data);
			myAZTWebSignManager.update(datas);
		}
		catch (Exception e) {
			log.error("获取安正通签章数据异常", e);
		}
		return null;
	}

}
/**
 * 
 * 客开 项目名称：新疆兵团 作者：wangyinan 修改日期：2014-05-20 [修改功能：安证通盖章] end
 * 
 */