package com.seeyon.v3x.plugin.azt.controller;

import com.seeyon.ctp.common.AbstractSystemInitializer;
/**
 * 
 * 客开 项目名称：新疆兵团 作者：wangyinan 修改日期：2014-05-20 [修改功能：安证通盖章] start
 * 
 */
public class SystemInitializer extends AbstractSystemInitializer {
	  public void destroy() {
		  
	  }

	public void initialize() {
		System.out.println("AZT Init...........");
	}
}
/**
 * 
 * 客开 项目名称：新疆兵团 作者：wangyinan 修改日期：2014-05-20 [修改功能：安证通盖章] end
 * 
 */