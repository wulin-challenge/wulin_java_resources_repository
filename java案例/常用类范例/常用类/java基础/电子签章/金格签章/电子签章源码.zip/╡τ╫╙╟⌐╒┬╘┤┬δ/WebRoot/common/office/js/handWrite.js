/**
 *Created by muj!
 *OFFICE常见BUG说明：
 *1。专业签章-参数设置-选项【浮于文字上方】
 *   -- 浮于文字上方和下方，主要是针对打印输出功能做的,而不是显示的时候,测试下打印就能看到效果了!
 *
 * 
 * 
 */


/**
 * 显示office控件
 */
 /*
手写批注控件参数说明：
editType＝“1,0”;
       第一位是对office的0只读，1可写不留痕迹，2可写保留痕迹
       第二位是对手写批注的0不可以修改，1，可以修改
ShowType＝0；显示什么状态，修改不修改不由此决定
       0：当前是清稿
       1：文字批注
       2：手写批注
LastType＝＝0
	0：当前是清稿
       1：文字批注
       2：手写批注

*/
/**
ocxMode :控件模式,simple为简单模式(简单的编辑控件,不提供痕迹保留和,手写批注,使用于会议,计划,文档),normal:为普通模式
         displayBulletin:公告显示模式
*/

var isLoadOfficeFile=true;//是否调入了正文


var oInterval = null;//控件延时调入定时器
var fileType = "";

var editType;
if(parent.editType){
  editType = parent.editType;
}else{
  transAttribute(parent.editTypeList);
}

var hasSign=true;//是否有签名印章的权限
var wordTextContent="";//保存word的文字内容,盖章后可以移动印章,修改文字,保存的时候判断文字是否被修改,如果修改了禁止保存;
var curDataID="";//记录当前版本对应数据的ID
var curMenuID=0;//记录当前版本菜单ID,用于菜单变灰控制
var curMenuEditType="";//记录当前版本的编辑模式,用于控制菜单
var backupIds="";//记录备份文件id
var contentId=parent.fileId;
var jsLocalLanguage= parent.webRoot + "/common/office/" +parent.v3x.currentLanguage+"_txt";

var category=parent.category;
var lastUpdateTime="";//记录正文最后修改日期，修改时判断是否需要重新调入；在调入时此变量赋值

var page_OcxState="loading";//记录控件状态,打开完成后设置为complete

var isSignOperation=false;//是否是签章操作的状态，即页面上执行了签章操作。如果执行了签章操作，即为修改状态。

var reWrite=false;//文档掉入之后，是否进行过重新批注
 
var gRibbonStatus=100;  //设置全局变量,-1表示没有安装office2007,如果是0，表示没有值或设置最大化,如果是4，表示设置为最小化


var newPdfId="";        //转化为PDF文档时候新生成的PDF文档的ID。
var isToPdf=false;      //当前操作是否是WORD转PDF。
var isShowShenYueMenu = true; //是否显示审阅菜单
var hasAdvanceOcx = parent.hasAdvanceOcx;             //是否高级版


//----------------弹出模态对话框禁止使用insert菜单--------------------------
//作用：控制OFFICE菜单

//是否需要仅用insert菜单,只有xls在弹出模态窗口中才禁止
var disableInsertMenu=null;
function WebOfficeInsertMenuDisable(ocxObj,DisableMenu){
	if(disableInsertMenu==null)
	{
  		if(ocxObj.FileType==".xls" && top.dialogArguments!=null)
  		{
  			disableInsertMenu=true;
  		}
  		else
  		{
  			disableInsertMenu=false;
  		}
	}	
	if(disableInsertMenu==false){return;}
  
  //alert(DisableMenu);
  if (DisableMenu){
      //OFFICE2000-2003的插入菜单禁止
      ocxObj.DisableMenu("插入(&I)");  //禁止"插入"菜单 
      
      //OFFICE2007的插入菜单隐藏
      ocxObj.RibbonUIXML = '' +
      '<customUI xmlns="http://schemas.microsoft.com/office/2006/01/customui">' +
      '  <ribbon startFromScratch="false">'+                    //不显示所有选项卡控制 false显示选项卡；true不显示选项卡
      '    <tabs>'+
      '      <tab idMso="TabInsert" visible="false">' +         //关闭插入工具栏
      '      </tab>'+
      '    </tabs>' +
      '  </ribbon>' +
      '</customUI>';
  }else{
      //OFFICE2000-2003的插入菜单显示
      ocxObj.EnableMenu("插入(&I)");  //显示"插入"菜单
  }
}
//------------------------------结束------------------------------

function showOfficeDiv(_fileType){
	if(_fileType == fileType){
		return;
	}
	
	fileType = _fileType;
	
	if(parent.editTypeList.loadOffice == false){
	  isLoadOfficeFile = false;
    return;
  }
	
	try{
		oInterval = window.setInterval("loadOffice()", 200);
	}
	catch(e){
		alert(e.message)
	}
}
function updateOfficeState(state)
{
  var ocxObj = document.getElementById("WebOffice");
  ocxObj.EditType = state;
  editType=state;
}
//删除office正文中的痕迹，并且保存office正文
function removeTrailAndSave(){
	//需要先打开正文才能清除痕迹。
	if(!parent.contentUpdate){
		checkOpenState();
	}
	var ocxObj = document.getElementById("WebOffice");
	//关闭痕迹
	ocxObj.EditType="1,0"; 
	//清除痕迹,需要try catch.Excel正文转发会报js错误。
	try{ocxObj.WebObject.Application.ActiveDocument.AcceptAllRevisions();}catch(e){} 
	
	//提供花脸查看功能
	ocxObj.WebSetMsgByName("editType","clearDocument");
	
	//保存正文
	parent.contentUpdate=true;
	parent.checkExistBody();
	if(!parent.saveContent()){return false;}
	else  {return true;}
}
//新建公文模板的时候：删除office正文中的痕迹，并且保存office正文，不保存EDOC_BODY对象。
function removeTrailAndSaveWhenTemplate(){
	//需要先打开正文才能清除痕迹。
	checkOpenState();
	var ocxObj = document.getElementById("WebOffice");
	//关闭痕迹
	ocxObj.EditType="1,0"; 
	//清除痕迹
	try{ocxObj.WebObject.Application.ActiveDocument.AcceptAllRevisions(); }catch(e){}
	
	//提供花脸查看功能
	ocxObj.WebSetMsgByName("editType","clearDocument");
	
	//保存正文
	parent.contentUpdate=true;
	//parent.checkExistBody();
	if(parent.saveOffice()==false)
    {
      return false;
    }
    //parent.draftTaoHong="draftTaoHong";
    return true;
}
//拟文的时候：删除office正文中的痕迹，并且保存office正文
function removeTrailAndSaveWhenDraft(){
	//需要先打开正文才能清除痕迹。
	if(!parent.contentUpdate){
		checkOpenState();
	}
	var ocxObj = document.getElementById("WebOffice");
	//关闭痕迹
	ocxObj.EditType="1,0"; 
	//清除痕迹
	ocxObj.WebObject.Application.ActiveDocument.AcceptAllRevisions(); 
	
	//提供花脸查看功能
	ocxObj.WebSetMsgByName("editType","clearDocument");
	
	//保存正文
	parent.contentUpdate=true;
	parent.checkExistBody();
	if(parent.saveOffice()==false)
    {
      return false;
    }
    parent.draftTaoHong="draftTaoHong";
    return true;
}
function loadOffice()
{
	if(!isHandWriteRef())return;
	var ocxObj = document.getElementById("WebOffice");
		
	if(!ocxObj || ocxObj.readyState != 4){
		return false;
	}

	window.clearInterval(oInterval);
	
	var officeOcxDiv=parent.document.getElementById("edocContentDiv");
	if(officeOcxDiv!=null && officeOcxDiv.style.display=="none")
	{
		isLoadOfficeFile=false;
		return true;
	}
	
	//ocxObj.alert(ocxObj.Office2007Ribbon);	
	//只读情况下，把office2007的工具栏最小话
	ocxObj.FileType = "." + fileType;
	if(editType=="0,0" || editType=="4,0")
	{
		gRibbonStatus = ocxObj.Office2007Ribbon;     // -1表示没有安装Office2007,4表示设置功能区最小化,0设置功能区最大化
  		if (gRibbonStatus!=-1){   //OFFICE2007存在最大化
    		ocxObj.Office2007Ribbon=4;
   		}
	}	
	
	
	WebOfficeInsertMenuDisable(ocxObj,false);
	_loadOffice();
	//隐藏花脸
	if(typeof(parent.isShowHualian)!='undefined'&&parent.isShowHualian!=null&&!parent.isShowHualian){
		for(i=201;i<206;i++)
		{
			ocxObj.DisableMenu(getVerMenuName(i));
		}
	}
}

function checkOpenState()
{
	if(isLoadOfficeFile==false)
	{
		_loadOffice();
		isLoadOfficeFile=true;
	}
	//refreshOfficeLable();
}

//刷新Office中文中的Label.
function refreshOfficeLable(sendForm){
	//先取消标签中的设置值
	
	//刷新套红后正文中的标签。需要先将OFFICE控件设置为可编辑模式。
	if(!sendForm){
		var sendForm=parent.document.getElementById("sendForm");
	}
	if(sendForm){
		var ocxObj = document.getElementById("WebOffice");
		if(ocxObj.EditType=="0,0"||ocxObj.EditType=="4,0"){
			var srcEditType=ocxObj.EditType;
			ocxObj.EditType="1,0";
			setAllLable(sendForm,"edoc",parent.extendArray);
			ocxObj.EditType=srcEditType;
		}else{
			setAllLable(sendForm,"edoc",parent.extendArray);
		}
	}
}
//得到正文中书签的个数，可以根据此来判断正文是否已经进行了套红操作。
function getBookmarksCount(){
	var mCount=0;
	var ocxObj = document.getElementById("WebOffice");
	try{
	 	mCount = ocxObj.WebObject.Bookmarks.Count;
	}catch(e){}
	return mCount;
}
function checkNeedSave()
{	
	var ret=true;	
	if(isLoadOfficeFile==true){return true;}
	if(parent.isNewOfficeFilePage==true)
	{//新建页面
	    _loadOffice();
		isLoadOfficeFile=true;
		ret=true;
		
	}
	else
	{//中间office处理修改页面
	  if(isLoadOfficeFile==true){ret=true;}
	  else {ret=false;}
	}	
	return ret;
}
function isLoadOffice(){
	if(page_OcxState == "complete"){
		return true;
	}
	return false;
}
/**
 * 审阅菜单的设置策略：
 *  2003受WebSetRevision接口的控制。
 *  2007 & 2010 用如下 RibbonUIXML 的方式控制。
 * @param WebOffice
 */
//设置OFFICE2007的选项卡显示
function WebSetRibbonUIXML(WebOffice){
	try{ 
		WebOffice.RibbonUIXML = '' +
		  '<customUI xmlns="http://schemas.microsoft.com/office/2006/01/customui">' +
		  '  <ribbon startFromScratch="false">'+                    //不显示所有选项卡控制 false显示选项卡；true不显示选项卡
		  '    <tabs>'+
		  '      <tab idMso="TabReviewWord" visible="true">' +     //关闭审阅工具栏
		  '      </tab>'+
		  '    </tabs>' +
		  '  </ribbon>' +
		  '</customUI>';
	}catch(e){
		
	}
}

/**
 * 起草
 */
function _loadOffice(){	
	var ocxObj = document.getElementById("WebOffice");
		
	if(!ocxObj || ocxObj.readyState != 4){
		return false;
	}
	
	window.clearInterval(oInterval);
	try{
		ocxObj.ShowToolBar = "0";
		//ocxObj.WebUrl = parent.webRoot + "/officeservlet";
		ocxObj.WebUrl = parent.webRoot +"/officeservlet";
		ocxObj.RecordID = contentId;
		ocxObj.EditType = editType;
		ocxObj.ChangeSize=true;   //设置为允许全屏时修改全屏窗口的大小
		ocxObj.Language = jsLocalLanguage;
		if(fileType.indexOf(".")!= -1){
			ocxObj.FileType = fileType;
		    ocxObj.FileName = parent.getOcxFileName() + fileType.substring(1);
		}else{
			ocxObj.FileType ="."+ fileType;
			ocxObj.FileName = parent.getOcxFileName() + fileType;
		}
		ocxObj.UserName = parent.currUserName;
		ocxObj.Template = "";
				
		ocxObj.WebSetMsgByName("CREATEDATE", parent.createDate);
		ocxObj.WebSetMsgByName("CATEGORY", "1");
		ocxObj.WebSetMsgByName("originalFileId", parent.originalFileId);
		ocxObj.WebSetMsgByName("originalCreateDate", parent.originalCreateDate);
		ocxObj.WebSetMsgByName("needCloneFile", parent.needCloneFile);
		ocxObj.WebSetMsgByName("needReadFile", parent.needReadFile);
		
		initOcxMenu(ocxObj);//初始化控件菜单
		
	    if(!checkFileSize(parent.officeFileRealSize,parent.officeOcxUploadMax)) 
	    	return false;
	   
	    WebSetRibbonUIXML(ocxObj)

		var status1 = ocxObj.WebOpen();
		
//		 if (ocxObj.FileType==".wps"){   //控制WPS文档处于运行模式
//              if (WebWpsFormsDesign()){
//                   WebWpsToggleFormsDesign();
//                 }
//          }
		
		//设置正文更新时间
		lastUpdateTime=ocxObj.WebGetMsgByName("OfficeUpdateTime");
		
		setOcxMenuState(ocxObj);//根据控件的模式，使用的模块设在菜单的状态			
		
		adjustMenu(ocxObj);		
		setSignatureColor(ocxObj);
		page_OcxState="complete";
		isLoadOfficeFile=true;	
		setOfficeShowPicture(ocxObj,true);
		return status1;
	}
	catch(e){
		if((e.number & 0xFFFF)==438){
			alert(getOfficeLanguage("alert_err_UpdateOcx"));
		}
		else{
			alert(""+(e.number & 0xFFFF) + "\n\n" + e.description);
		}	  
	}
}

/**
 * 设置客户端本地OFFICE，显示图片，否则印章图片可能显示不出来。
 * @param ocxObj
 * @param state
 */
function setOfficeShowPicture(ocxObj,state){
	try{
		ocxObj.WebObject.Application.ActiveWindow.View.ShowDrawings = state;
	}catch(e){
		
	}
}
/**
 * 显示或隐藏工具栏，重新设置一下工具栏状态，避免出现Excel的正文隐藏前几行的问题
 */
function resetToolBar(ocxObj){
	  try{
	    var mApp = ocxObj.WebObject.Application;
	    //显示或隐藏工具栏
	    if(ocxObj.FileType == ".xls"){
	      if(mApp.ExecuteExcel4Macro('Get.ToolBar(7,"Ribbon")')){
	        mApp.ExecuteExcel4Macro('Show.ToolBar("Ribbon", false)');
	        mApp.ExecuteExcel4Macro('Show.ToolBar("Ribbon", true)');
	      }else{
	        mApp.ExecuteExcel4Macro('Show.ToolBar("Ribbon", true)');
	        mApp.ExecuteExcel4Macro('Show.ToolBar("Ribbon", false)');
	      }
	    }
	  }
	  catch(e){
	  }
}
function checkFileSize(officeFileRealSize,officeOcxUploadMax){
	try{
		if(typeof(officeFileRealSize)!='undefined'  &&  typeof(officeOcxUploadMax)!='undefined'
			&& officeFileRealSize!='' && typeof(officeOcxUploadMax)!=''){
			if(parseFloat(officeFileRealSize)>parseFloat(officeOcxUploadMax)){
				alert(getOfficeLanguage("alert_err_OcxFileBig_not_open",officeOcxUploadMax));
				return false;
			}
		}
	}catch(e){
		
	}
	return true;
}


/**
 * 设置印章颜色，如果是部门归档的公文，则设置印章为灰色的，其他的情况不变，维持原来文件的颜色
 */
var setSignatureBlack="";
function setSignatureColor(ocxObj){
    if(typeof(parent.setSignatureBlack) != "undefined"){
         setSignatureBlack = parent.setSignatureBlack ;
    }
   
    if(setSignatureBlack == 'true'){
        var hasSign=ocxObj.SignatureCount(true)>0 || ocxObj.SignatureCount(false)>0;//是否有合法印章	
    	var isProtect=IsOfficeProtection(ocxObj);
    	if(hasSign){	
    		try{
    			if(isProtect==1)
        		{
        			ocxObj.WebSetProtect(false,"");
        			ocxObj.SignatureColor(false);
            		ocxObj.WebSetProtect(true,"");
        		}else{
        			//保存本地文件前把印章变灰，使印章实效
        			ocxObj.SignatureColor(false);
        		}
    		}catch(e){}
    		
    	}
    }
}
function WebWpsFormsDesign(){
	var ocxObj = document.getElementById("WebOffice");
  mResult = !ocxObj.WebObject.UserMode;
 
  return (mResult);
}

function WebWpsToggleFormsDesign(){
	var ocxObj = document.getElementById("WebOffice");
    ocxObj.WebObject.UserMode = !ocxObj.WebObject.UserMode;
}
//判断当前页面是否是协同拟文( newCollaboration.jsp)页面
function isNewCollPage(){
	if(typeof(parent.currentPage)!="undefined"
		&& parent.currentPage=="newColl")
		return true;
	return false;
}
//判断当前页面是否是拟文( newEodc.jsp)页面
function isNewEdocPage(){
	if(typeof(parent.currentPage)!="undefined"
		&& parent.currentPage=="newEdoc")
		return true;
	return false;
}
//拟文页面是否调用了模板。
function isFromTemplateOfNewEdocPage(){
	if(typeof(parent.isFromTemplate)!="undefined"
		&& parent.isFromTemplate)
		return true;
	return false;
}
//是否是模板制作页面
function isTemplete(){
	if(typeof(parent.isTemplete)!="undefined"
		&& parent.isTemplete)
		return true;
	return false;
}
//是否是登记，并且是从待登记列表中进来的。
function isFromRegsitPendingList(){
	var comm=parent.document.getElementById("comm");
	if(comm && comm.value=="register")
		return true;
	return false;
}
//设置菜单状态，是否可用，不可用的菜单，变灰
function setOcxMenuState(ocxObj)
{
  var ret=false;   
  if(editType=="1,0")//起草
  {
    //ocxObj.DisableMenu("menu_CharPostil,menu_HandWritePostil,menu_ClearTrail,menu_ResetPostil,menu_CheckSeal,menu_SginSeal,menu_HiddenTrail,menu_DisplayTrail,menu_BrowseChar,menu_BrowseHandWrite");
    // test code
    ocxObj.DisableMenu(getOfficeLanguage("menu_CharPostil,menu_EditContent,menu_HandWritePostil,menu_ResetPostil,menu_HiddenTrail,menu_BrowseChar,menu_BrowseHandWrite"));
	if(ocxObj.LastType!=2)
	{//最新为文字
		ocxObj.DisableMenu(getOfficeLanguage("menu_ClearTrail"));
		/**痕迹控制
		 * 1、放开修订菜单,让用户可以自由选择
		 * 2、单位管理员制作模板默认不选中修订
		 * 3、直接拟文默认不选中修订
		 * 4、调用公文模板默认选中修订
		 * 5、待登记的登记时，要选中修订**/
		if(isNewEdocPage()){  //拟文页面（1,直接拟文默认不保留痕迹 2,调用模板保留痕迹）
			ocxObj.WebSetRevision(false,false,false,isShowShenYueMenu);
			if(isFromTemplateOfNewEdocPage() || isFromRegsitPendingList())
				ocxObj.WebSetRevision(false,true,false,isShowShenYueMenu);
		}else if(isTemplete()){//制作公文模板不保留痕迹
			ocxObj.WebSetRevision(false,false,false,isShowShenYueMenu);
		}else if(isNewCollPage()){//新建协同默认不保留痕迹
			ocxObj.WebSetRevision(false,false,false,isShowShenYueMenu);
		}else{
			ocxObj.WebSetRevision(false,true,false,isShowShenYueMenu);
		}
	}
  }
  else if(editType=="0,0" ||editType=="4,0")//只读
  {
  	//wait to do..
  	//curMenuID=200;
	if(curMenuID==0){initBackUpMenuState(ocxObj);}
    ocxObj.DisableMenu(getOfficeLanguage("menu_CharPostil,menu_HandWritePostil,menu_ClearTrail,menu_ResetPostil,menu_SginSeal,menu_OpenFile,menu_HiddenTrail,menu_BrowseChar,menu_BrowseHandWrite,menu_PageSet"));
    //只读状态下应该不显示痕迹，先显示痕迹按钮才显示
    ocxObj.WebSetRevision(false,true,false,isShowShenYueMenu);
    if(ocxObj.LastType==2)
    {//显示手写批注的时候隐藏痕迹,和印章校验按钮
      ocxObj.DisableMenu(getOfficeLanguage("menu_DisplayTrail,menu_CheckSeal,menu_BrowseHandWrite,menu_SaveFile"));
      ocxObj.EnableMenu(getOfficeLanguage("menu_BrowseChar"));
    }
    else
    {//文字最新,添加切换到文字浏览得按钮
      if(ocxObj.Pages>0){ocxObj.EnableMenu(getOfficeLanguage("menu_BrowseHandWrite"));}
      ocxObj.EnableMenu(getOfficeLanguage("menu_DisplayTrail"));
    }
    if(typeof(parent.canEdit)!="undefined"&&parent.canEdit=="true"){
    	ocxObj.EnableMenu(getOfficeLanguage("menu_EditContent"));
    }else{
    	ocxObj.DisableMenu(getOfficeLanguage("menu_EditContent"));
    }
  }
  else
  {
    ocxObj.ShowToolBar="0";
  }
  ret=true;
  return ret;
}
/*初始化备份菜单状态*/
function initBackUpMenuState(ocxObj)
{
  curDataID=ocxObj.RecordID;
  curMenuID=200;
  backupIds=ocxObj.WebGetMsgByName("backupIds");
  var ids="";
  var i,mid;
  if(backupIds.length<=0){return;}
  ids=backupIds.split(",");
  if(ids.length>0)
  {
    for(i=0;i<ids.length;i++)
    {
	mid=201+i;
	if(curMenuID==mid){break;}
	ocxObj.EnableMenu(getVerMenuName(mid));
    }
  }
}
function initOcxMenu(ocxObj)
{
	try{    
    ocxObj.pencolor="#FF0000";
    ocxObj.penwidth="1";
    try{ocxObj.Print=true;}catch(e){}
    ocxObj.AppendMenu("1",getOfficeLanguage("menu_OpenFile"),"10");
    ocxObj.AppendMenu("2",getOfficeLanguage("menu_SaveFile"),"2");
	ocxObj.AppendMenu("106",getOfficeLanguage("menu_PageSet"),"28");
    ocxObj.AppendMenu("107",getOfficeLanguage("menu_Print"),"13");
    ocxObj.AppendMenu("108",getOfficeLanguage("menu_PrintPreview"),"80");
    ocxObj.AppendMenu("109",getOfficeLanguage("menu_EditContent"),"132");
    if(ocxObj.FileType==".xls"||ocxObj.FileType==".xlsx"||ocxObj.FileType==".wps"){
    	ocxObj.DisableMenu(getOfficeLanguage("menu_PrintPreview"));
    }
	if(ocxObj.EditType!="1,0" && curMenuID==0)
	{//版本菜单在 正常模式,第一次初始化,并且非起草才出现
	    ocxObj.AppendMenu("603","-");
		var i=0;
		var imgId="";
		for(i=200;i<206;i++)
		{
			imgId=""+(i-170);
			if(i==200){imgId="40";}
			ocxObj.AppendMenu(i,getVerMenuName(i),imgId);
			ocxObj.DisableMenu(getVerMenuName(i));
		}
	}
	ocxObj.AppendMenu("604","-");
	ocxObj.AppendMenu("102",getOfficeLanguage("menu_SaveExit"),"16");
    ocxObj.AppendMenu(getOfficeLanguage("menu_A8Col"),"-");    
    if(ocxObj.VersionEx()=="Advance")
    {
      ocxObj.AppendMenu("3",getOfficeLanguage("menu_CharPostil"),"23");
      ocxObj.AppendMenu("4",getOfficeLanguage("menu_HandWritePostil"),"24");
      ocxObj.AppendMenu("6",getOfficeLanguage("menu_ResetPostil"),"30");
      ocxObj.AppendMenu("600","-");
    }

    //if(nodeActorId!=passReadId)
    {
	  ocxObj.AppendMenu("5",getOfficeLanguage("menu_ClearTrail"),"25");
      ocxObj.AppendMenu("13",getOfficeLanguage("menu_DisplayTrail"),"26");
      ocxObj.AppendMenu("12",getOfficeLanguage("menu_HiddenTrail"),"29");
      ocxObj.AppendMenu("601","-");
      ocxObj.AppendMenu("11",getOfficeLanguage("menu_SginSeal"),"15");
    }
    ocxObj.AppendMenu("10",getOfficeLanguage("menu_CheckSeal"),"20");
    if(ocxObj.VersionEx()=="menu_TopVer")
    {
      ocxObj.AppendMenu("602","-");
      ocxObj.AppendMenu("14",getOfficeLanguage("menu_BrowseChar"),"42");
      ocxObj.AppendMenu("15",getOfficeLanguage("menu_BrowseHandWrite"),"41");
    }
    //正文类型是word，并且可以编辑，并且安装金格二维码
    var PDF417Manager = parent.document.getElementById("PDF417Manager");
    if(PDF417Manager && typeof parent.CopyRight && (ocxObj.FileType == ".doc" || ocxObj.FileType == ".docx")){
    	ocxObj.AppendMenu("18",getOfficeLanguage("menu_BarCode"),"22");
    	ocxObj.DisableMenu(getOfficeLanguage("menu_BarCode"));
    }
    ocxObj.AppendMenu(getOfficeLanguage("menu_A8Other"),"-");
    ocxObj.AppendMenu("101",getOfficeLanguage("menu_FullScreenMode"),"22");
    ocxObj.AppendMenu("100",getOfficeLanguage("menu_OcxVer"),"17");
    if(ocxObj.WindowStatus==1){ocxObj.DisableMenu(getOfficeLanguage("menu_SaveExit"));}
        ocxObj.DisableMenu("合并文档(&D)...");
        ocxObj.DisableMenu("保护文档(&P)...");
        ocxObj.DisableMenu("宏(&M)");
      //  ocxObj.DisableMenu("选项(&O)...");
        ocxObj.DisableMenu("书签(&K)...");
    }catch(ea){var errStr=ea.number & 0xFFFF;errStr=errStr+":"+ea.description;ocxObj.alert(errStr);}
}

function getVerMenuName(id)
{
  if(id==200){return getOfficeLanguage("menu_CurrentVer");}
  else if(id==201){return getOfficeLanguage("menu_Ver1");}
  else if(id==202){return getOfficeLanguage("menu_Ver2");}
  else if(id==203){return getOfficeLanguage("menu_Ver3");}
  else if(id==204){return getOfficeLanguage("menu_Ver4");}
  else if(id==205){return getOfficeLanguage("menu_Ver5");}
}

function getVerMenuDataId(ocxObj,mid)
{  
  if(mid==200){return curDataID;}
  else
  {
    return backupIds.split(",")[mid-201];
  }
}

function removeOfficeDiv(){
	var o = document.getElementById("officeDivInner");
	if(o){
		o.removeNode(true);
	}
	
	var contentObj = document.getElementById("content");
	if(contentObj){	
		contentObj.value = originContent;
	}
}
/**
 * 将当前文档转化为PDF文档
 * newPdfFileId：新生成的PDF文档的ID.
 */
function transformWordToPdf(newPdfFileId){
    
    if(typeof(newPdfFileId)!="undefined" && newPdfFileId!="")
        newPdfId=newPdfFileId;  
    else {
        //alert_convertToPdfInvalidArgument:当前文档转化为PDF文档的时候，传入的参数不合法，请重新设置参数
        ocxObj.alert(getOfficeLanguage("alert_convertToPdfInvalidArgument"));
        return false;
    }
    isToPdf=true;//当前操作时转化为PDF。
    
    checkOpenState();
    var state= saveOffice();
    return state;
}
/**
 * 
 */
function saveOffice(stdOffice) {
	if(!isHandWriteRef())return;
    var ocxObj = document.getElementById("WebOffice");
  //如果是word类型的公文正文不需要转换成标准office正文
    var edocType=parent.document.getElementById("edocType");
    if(edocType){
    	ocxObj.WebSetMsgByName("notJinge2StandardOffice","true");
    }
    if(!isToPdf){//如果转PDF操作的话，肯定是要向后台保存的，所以不需要判断是否保存
    	if(checkNeedSave()==false){return true;}
    	if(ocxObj.EditType == "0,0"){	//只读状态得文档没有必要保存
    		return true;
    	}
    }
	//刷新Office正文中的Lable.
	//refreshOfficeLable();
	var state=false;
	
	try{
		ocxObj.WebSetProtect(false, "");  //""表示密码为系统默认
		try
		{//在只读方式下不可以修改
    		if(ocxObj.ShowType==1 && ocxObj.EditType=="0,1"){ocxObj.ShowType=2;}//当前显示文字，但文字不可以修改，手写可修改
    		if(ocxObj.ShowType==2 && (ocxObj.EditType=="1,0" || ocxObj.EditType=='2,0')){ocxObj.ShowType=1;}//当前显示手写，但手写不可以修改，文字可修改
  		}catch(e){}
  		ocxObj.WebSetMsgByName("CATEGORY", "1");
		ocxObj.WebSetMsgByName("clientVer", ocxObj.Version());//客户端控件版本,放置版本和服务器端不一致
		if(ocxObj.ShowType==0){ocxObj.WebSetMsgByName("editType","clearDocument");}//清稿保留备份
		
		/*通过下面这种方式设置的参赛，在经过一次服务交换后会丢失，需要重新设置*/
		ocxObj.WebSetMsgByName("originalFileId", parent.originalFileId);
		ocxObj.WebSetMsgByName("originalCreateDate", parent.originalCreateDate);
		ocxObj.WebSetMsgByName("CREATEDATE", parent.createDate);
		ocxObj.WebSetMsgByName("needCloneFile", parent.needCloneFile);
		ocxObj.WebSetMsgByName("needReadFile", parent.needReadFile);
		ocxObj.WebSetMsgByName("draftTaoHong",parent.draftTaoHong);//是否进行了拟文套红。
		ocxObj.WebSetMsgByName("needInsertToV3XFile",parent.needInsertToV3XFile);

		// 是否编辑的上传文档
		ocxObj.WebSetMsgByName("stdOffice", stdOffice);
		 
		
		
		//没必要每次保存的时候临时到父窗口取ID，当切换的时候会出现问题
		ocxObj.RecordID = parent.fileId;
		if(_checkSignUpdate(ocxObj)==false){return false;}
		ocxObj.MaxFileSize=parent.officeOcxUploadMax;
		
		//套红失败，不允许保存
		if(ocxObj.WebGetMsgByName("CUROPERATE")=="TaoHong")
		{
			ocxObj.alert(getOfficeLanguage("alert_err_taohong"));
			return false;			
		}
		var state =false;
		if(isToPdf){
    		//如果是Word转PDF正文，设置转化后的PDF正文的ID，并且调用WEBSAVEPDF保存方法
    		ocxObj.WebSetMsgByName("newPdfFileId", newPdfId);
    		ocxObj.WebSetMsgByName("toFileType","pdf");
    		state = ocxObj.WebSavePDF();
    		//设置JS变量，清空参数。以免保存office正文的时候将这些参数传递到了后台。
    		isToPdf = false;  
    		ocxObj.WebSetMsgByName("newPdfFileId","");
    		ocxObj.WebSetMsgByName("toFileType","");
		}else{
		    state = ocxObj.WebSave();
		}
		if(state==false){
		    if(ocxObj.Status.indexOf("versionError")>=0){  
		    	//版本不一致.
		        ocxObj.alert(getOfficeLanguage("alert_err_OcxVer"));
		    }else if(ocxObj.Status.indexOf("Please Install Adobe PDF")>=0){
		    	//安装PDF虚拟打印机
		        ocxObj.alert(getOfficeLanguage("alert_pleaseInstallAdobePDF"));
		    }else if(ocxObj.Status.indexOf("saveFaile")>=0){
		    	//保存正文失败，后台异常
		    	ocxObj.alert(getOfficeLanguage("alert_saveFaile")); 
		    }else if(ocxObj.Status!=null){
		    	//文件太大了的提示信息HandWrite会自己给出来的。不需要我们再这里处理，HandWrite给出的提示：“文件太大，不允许在线打开!(10k)";
				//保存正文失败,服务器返回信息{0}
		    	ocxObj.alert(getOfficeLanguage("alert_saveFaile")); 
		    }
		}
		
//		if(state==false && ocxObj.Status.indexOf("err")>=0&&ocxObj.EditType!="1,0")
//  		{
//  		ocxObj.alert(getOfficeLanguage("alert_err_OcxVer"));
//  		}
//  		else if(state==false&&ocxObj.EditType!="1,0"){
//			 if(ocxObj.Status!=null)
//					ocxObj.alert(getOfficeLanguage("alert_err_OcxFileBig",ocxObj.Status));
//	
//		      }
		parent.fileSize = ocxObj.WebGetMsgByName("fileSize")
	}
	catch(ea){
		var errStr = ea.number & 0xFFFF + ":" + ea.description;
		ocxObj.alert(errStr);
	}
	
	return state;
}
function FullSize()
{
	if(!isHandWriteRef())return;
	checkOpenState();
  var ocxObj = document.getElementById("WebOffice");
  if(ocxObj.WindowStatus!=0)
  {  	
  	ocxObj.FullSize();
  	WebOfficeInsertMenuDisable(ocxObj,true);
  }
  if(ocxObj.WindowStatus==0)
  {
    ocxObj.DisableMenu(getOfficeLanguage("menu_FullScreenMode"));
    ocxObj.EnableMenu(getOfficeLanguage("menu_SaveExit"));
  }
  setToolsPrintState(ocxObj);
  if(ocxObj.FileType == ".xls"){
		resetToolBar(ocxObj);
  }
}
//是否保留痕迹
function isTrack(){
	var isTrack=true
	try{
		isTrack=ocxObj.WebObject.TrackRevisions;
	}catch(e){}
	return isTrack;
}
//控件自定义菜单，事件响应函数
function OnMenuClick(vIndex,vCaption)
{

    var ocxObj=document.getElementById("WebOffice");
    //ocxObj.alert("("+vIndex+"="+vCaption+")");
    //ocxObj.alert("vIndex="+vIndex+"  ShowType="+ocxObj.ShowType+"   LastType="+ocxObj.LastType);
    //屏蔽，文字批注，手写批注，文档清稿三个按钮的重复点击
    //if((vIndex==3 && ocxObj.ShowType==1) || (vIndex==4 && ocxObj.ShowType==2)){return;}
    if (vIndex==0){ocxObj.CreateFile();}
    else if (vIndex==1)
	{//打开本地文件，如果需要打开网络上文件,用WebOffice.WebOpen();
		try{ocxObj.WebOpenLocalFile();}catch(e){ocxObj.alert(""+(e.number & 0xFFFF)+e.description);}
	}
    else if (vIndex==2)
	{
		var saveRes=saveLocalFile(ocxObj);
		if(saveRes!="" && typeof(parent.officeOcxOperateOver)=="function"){parent.officeOcxOperateOver('saveLocal');}
	} //如果需要保存到网络文件,用WebOffice.WebSave();
    else if (vIndex==3)//文字批注按钮
    {
      setMenuState(ocxObj,getOfficeLanguage("menu_SginSeal"),hasSign);
      if(ocxObj.ShowType==0 && ocxObj.modify==true)
      {//由文档清稿切换到文字修改,如果清稿的时候修改了文字,重新掉入文档
        if(ocxObj.confirm(getOfficeLanguage("alert_cancelClearDocument"))==false){return;}
        reLoad(ocxObj);
      }
      if(ocxObj.LastType==2)
      {//最新的为手写批注
        ocxObj.alert(getOfficeLanguage("alert_ClearDoc"));
        ocxObj.EditType="0,1";
        ocxObj.DisableMenu(getOfficeLanguage("menu_SginSeal"));
      }
      if(ocxObj.LastType==0 || ocxObj.LastType==1)
      {//最新为文字
      	ocxObj.EditType="2,0";
      }
      ocxObj.ShowType=1;
      //切换后初始化隐藏痕迹      
      ocxObj.WebSetRevision(false,true,false,isShowShenYueMenu);    	
      ocxObj.EnableMenu(getOfficeLanguage("menu_SaveFile,menu_DisplayTrail,menu_PageSet,menu_ClearTrail"));
      ocxObj.DisableMenu(getOfficeLanguage("menu_CharPostil,menu_HiddenTrail"));   
      if(hasAdvanceOcx == true)
        ocxObj.EnableMenu(getOfficeLanguage("menu_HandWritePostil"));
    }
    else if (vIndex==4)//手写批注按钮
    {
      if(ocxObj.ShowType==0 && ocxObj.modify==true)
      {//由文档清稿切换到文字修改,如果清稿的时候修改了文字,重新掉入文档
        if(ocxObj.confirm(getOfficeLanguage("alert_cancelClearDocument"))==false){return;}
        reLoad(ocxObj);
      }
      else if(reWrite){ocxObj.ReWrite();}//进行过重新批注后，从文字切换到手写需要重新批注
      else if(ocxObj.LastType==0 || ocxObj.LastType==1)
      {//最新为文字批注
        if(ocxObj.Pages>0)
        {//当前有手写批注
          ocxObj.alert(getOfficeLanguage("alert_restTrail"));
          ocxObj.EnableMenu(getOfficeLanguage("menu_ResetPostil,menu_CharPostil"));
          ocxObj.ShowType=2;
          ocxObj.EditType="2,0";
          ocxObj.DisableMenu(getOfficeLanguage("menu_HandWritePostil,menu_CheckSeal,menu_SginSeal,menu_DisplayTrail,menu_HiddenTrail,menu_PageSet"));
          return;
        }
      }
      ocxObj.EnableMenu(getOfficeLanguage("menu_CharPostil,menu_ClearTrail"));
      ocxObj.DisableMenu(getOfficeLanguage("menu_HandWritePostil,menu_SaveFile,menu_PageSet"));
      ocxObj.ShowType=2;
      ocxObj.EditType="0,1";
      ocxObj.DisableMenu(getOfficeLanguage("menu_CheckSeal,menu_SginSeal,menu_DisplayTrail,menu_HiddenTrail"));
    }
    else if (vIndex==5)//文档清稿按钮
    {
      //保证手写和文字的一直,重新掉入文档
      if(ocxObj.modify==true)
      {
        //if(ocxObj.confirm(getOfficeLanguage("alert_lostContent"))==false){return;}
        //reLoad(ocxObj);
        //提示用户是否需要保存;
	  	if(ocxObj.confirm(getOfficeLanguage("alert_saveEdit"))==true)
	  	{
			if(saveOffice()==false)
			{
				ocxObj.alert(getOfficeLanguage("alert_SaveFalseNotChange"));
				return;
			}
	  	}
	  	else
	  	{
	  		reLoad(ocxObj);
	  	}
      }
      if(ocxObj.LastType==0 || ocxObj.LastType==1)
      {//清稿时如果文字时最新的,这时候需要重新生成批注格式
        ocxObj.ReWrite();
      }
      //为了显示痕迹，此处设置为2,0
      ocxObj.EditType="2,0";
      if(hasAdvanceOcx == true)
        ocxObj.ShowType = 0;
      else
        ocxObj.ShowType = 1;
      ocxObj.WebObject.AcceptAllRevisions();
      //清稿状态是不保留痕迹的，显示痕迹，隐藏痕迹菜单不需要显示
      //ocxObj.EnableMenu(getOfficeLanguage("menu_CheckSeal,menu_DisplayTrail,menu_HiddenTrail"));
      ocxObj.EnableMenu(getOfficeLanguage("menu_CheckSeal,menu_CharPostil"));
      ocxObj.DisableMenu(getOfficeLanguage("menu_DisplayTrail,menu_HiddenTrail,menu_ClearTrail"));
     
      if(hasAdvanceOcx == true)
        ocxObj.EnableMenu(getOfficeLanguage("menu_HandWritePostil"));
      //37299 清稿模式不能盖章
      setMenuState(ocxObj,getOfficeLanguage("menu_SginSeal"),false);
    }
    else if (vIndex==6)//重新批注按钮
    {
    	ocxObj.ReWrite();
    	reWrite=true;
    	ocxObj.DisableMenu(getOfficeLanguage("menu_ResetPostil"));
    	ocxObj.EditType="0,1";
    	ocxObj.ShowType=2;
    }
  //  else if (vIndex==10){ocxObj.WebShowSignature();}
    else if (vIndex==10)
    {
		/*
      var mtmpEditType=ocxObj.EditType;
      if (mtmpEditType.substring(0,1)=='4'){   //批注锁定模式
        ocxObj.EditType="1,0"
        ocxObj.WebShowSignature();
        ocxObj.EditType=mtmpEditType;
      }else{
        ocxObj.WebShowSignature();
      }
	  */
	  /*客开 项目名称：新疆兵团项目  作者：weijuan 修改日期：2014-5-31 [修改功能：安证通电子签章验证]start */
	  var bl;
	//alert("验证签章");
	  bl =printdoc.ValidateDoc();
		if(bl)
		{
		 alert("验证成功,图章有效！");
		 }
		else
		{
		 alert("验证失败,图章无效");
		} 
		/*客开 项目名称：新疆兵团项目  作者：weijuan 修改日期：2014-5-31 [修改功能：安证通电子签章验证]end */
    }
	else if (vIndex==11)//盖章
    {
	  //*客开 项目名称：新疆兵团项目  作者：weijuan 修改日期：2014-5-31 [修改功能：安证通电子签章修改]start */
	  //单击签章加载正文为修改编辑状态，可直接盖章
	  
	  //4、是否有合法印章		
		var hasSign=ocxObj.SignatureCount(true)>0;
		if(hasSign){
			ocxObj.alert(getOfficeLanguage("alert_SignNotEdic"));
			return;
		}
		FullSize();
		var canSign=parent.hasSign;//是否有签章权限
		if(typeof(parent.parent.updateContent)=='function'){
		  parent.parent.updateContent();
		}else{
		  ModifyContent(canSign);
		}
		parent.contentUpdate=true;
		
	  //modify by 使用安正通电子印章 start[盖word]
	 // if(ocxObj.FileType==".doc"){
		 var net = -1;
            net = printdoc.addSign("123", 0, "", 1, 0, "", 0, 0, ""); //静态加盖印章
            /*if (net == 0) {
                //alert("盖章成功");
            } else {
                //alert("盖章失败");
            }*/
	  //}
	  //modify by 使用安正通电子印章 end[盖word]
	 /*
	 //modify by 使用安正通电子印章 start[盖excel]
	  if (ocxObj.FileType==".xls"){
			var i;
			i = printdoc.addSign("123", 0, "", 1, 0, "", 0, 0, ""); //静态加盖印章
            if (i == 0) {
                alert("盖章成功");
            } else {
                alert("盖章失败");
            }
	  }
	 //modify by 使用安正通电子印章 end[盖excel]
	 */
	/*客开 项目名称：新疆兵团项目  作者：weijuan 修改日期：2014-5-31 [修改功能：安证通电子签章修改]end */
    }
    else if (vIndex==12)//点击隐藏痕迹
    {
    	//ocxObj.WebObject.ShowRevisions=false;
    	ocxObj.WebSetRevision(false,isTrack(),false,isShowShenYueMenu);
    	ocxObj.DisableMenu(getOfficeLanguage("menu_HiddenTrail"));
    	ocxObj.EnableMenu(getOfficeLanguage("menu_DisplayTrail"));
    }
    else if (vIndex==13)//点击显示痕迹
    {
    	//ocxObj.WebObject.ShowRevisions=true;
    	ocxObj.WebSetRevision(true,isTrack(),false,isShowShenYueMenu);
    	ocxObj.EnableMenu(getOfficeLanguage("menu_HiddenTrail"));
    	ocxObj.DisableMenu(getOfficeLanguage("menu_DisplayTrail"));
    }
    else if (vIndex==14)
    {//点击只读状态得“浏览文字”按钮
    	ocxObj.ShowType=1;
    	ocxObj.DisableMenu(getOfficeLanguage("menu_BrowseChar"));
    	ocxObj.EnableMenu(getOfficeLanguage("menu_BrowseHandWrite,menu_DisplayTrail,menu_CheckSeal,menu_SaveFile"));
    }
    else if (vIndex==15)
    {//点击只读状态得“浏览手写”按钮
        ocxObj.ShowType=2;
    	ocxObj.EnableMenu(getOfficeLanguage("menu_BrowseChar"));
    	ocxObj.DisableMenu(getOfficeLanguage("menu_BrowseHandWrite,menu_DisplayTrail,menu_HiddenTrail,menu_CheckSeal,menu_SaveFile"));
    }
    else if(vIndex==100)
    {
      ocxObj.alert(getOfficeLanguage("alert_Ocx")+" "+ocxObj.VersionEx()+"("+ocxObj.Version()+")");
      //当excel程序跟控件冲突，互锁时，可以点击版本按钮，一般情况不会出现冲突互锁；特殊情况这样可以解除互锁
      ocxObj.Active();
    }
    else if(vIndex==101)//全屏模式
    {
      FullSize();
    }
    else if(vIndex==102)//保存退出
    {
      if(_checkSignUpdate(ocxObj)==false)
      {
           return false;
      }

      ocxObj.SmallSize();
      if(ocxObj.WindowStatus==1)
      {
        ocxObj.DisableMenu(getOfficeLanguage("menu_SaveExit"));
        ocxObj.EnableMenu(getOfficeLanguage("menu_FullScreenMode"));
      }
      setToolsPrintState(ocxObj);
      if(parent.editOnline){
      	parent.editOnlineFunction();
      }
    }
    else if(vIndex==-1)//全屏窗口点击关闭后
    {
      ocxObj.DisableMenu(getOfficeLanguage("menu_SaveExit"));
      ocxObj.EnableMenu(getOfficeLanguage("menu_FullScreenMode"));
      if(typeof(parent.editOnline)!='undefined' && parent.editOnline){
         parent.editOnlineFunction();
      }
    }
    else if(vIndex==106)//页面设置
    {
      WebOpenPageSetup(ocxObj);
    }
	else if(vIndex==107)//弹出打印对话框
    { 
      ocxObj.WebOpenPrint();
      if(typeof(parent.officeOcxOperateOver)=="function"){parent.officeOcxOperateOver('print');}
    }
    else if(vIndex>=200 && vIndex<=205)//版本菜单切换
    {
	shiftVer(ocxObj,vIndex,vCaption);
    }else if(vIndex==108){
    	if (ocxObj.FileType==".doc"){
    		try{
    			if(ocxObj.WebObject.Application.ActiveWindow.ActivePane.View.Type==4){
    				ocxObj.WebObject.Application.ActiveWindow.ActivePane.View.Type = 3; //页面视图
    			}else{
    				ocxObj.WebObject.Application.ActiveWindow.ActivePane.View.Type = 4; //打印预览
    			}
    		}catch(e){}
    	}else{
    		return;
    	}
    }else if(vIndex==109){//修改正文
		//4、是否有合法印章		
		var hasSign=ocxObj.SignatureCount(true)>0;
		if(hasSign){
			ocxObj.alert(getOfficeLanguage("alert_SignNotEdic"));
			return;
		}
		FullSize();
		var canSign=parent.hasSign;//是否有签章权限
		if(typeof(parent.parent.updateContent)=='function'){
		  parent.parent.updateContent();
		}else{
		  ModifyContent(canSign);
		}
		parent.contentUpdate=true;
    }else if(vIndex==18){
    	parent.genBarCode(".gif");
    }
    else {alert('编号:'+vIndex+'\n\r'+'标题:'+vCaption+'\n\r'+'请根据这些信息编写具体功能');}    
}

//保存到本地文件，全部保存为可编辑状态，印章变灰；
//保存到本地后，脱离系统，无法保证保存到本地的文件不被修改，除非使用专业的电子签章系统
//以前只对wps，word保存后全部可编辑，修改为所有全部可以编辑包括.et,.xls文件；
//以前如果只读隐藏痕迹保留会删除痕迹，原因是以前存储后为只读，office2007问题每次打开都显示痕迹还无法隐藏；现在保存可编辑后不在删除痕迹保存
function saveLocalFile(ocxObj)
{

  var saveRes=false;
  var isProtect=0;
  isProtect=IsOfficeProtection(ocxObj);
  if(isProtect==0){//没有锁定
	  try{
			ocxObj.SignatureColor(false);
	  }catch(e){}
	  saveRes=dealTrackSaveLocalFile(ocxObj,false,false);
	  //保存后恢复正常印章
	  if(setSignatureBlack != 'true'){
		  try{
				ocxObj.SignatureColor(true);
		  }catch(e){}
	  }
  }else{//文档有锁定
	  var temp=ocxObj.editType;
	  ocxObj.editType='1,0';
	  //保存本地文件前把印章变灰，使印章实效
	  try{
			ocxObj.SignatureColor(false);
	  }catch(e){}
	  
	  saveRes=dealTrackSaveLocalFile(ocxObj,false,true);
	  if(setSignatureBlack != 'true'){  //部门归档本身就是暗色的就不需要变回彩色了。
		  try{
				ocxObj.SignatureColor(true);
		  }catch(e){}
	  }
	  ocxObj.editType=temp;
  }
  return saveRes;
}
/**保存到本地是否需要设置随机密码**/
function setPasswordSaveLocalFile(ocxObj,setPassword)
{
	var ret  = false;
	if(setPassword)
	{
		var randomPass=""+Math.random();  
		ocxObj.WebSetProtect(true,randomPass);
		var tempFileName=ocxObj.FileName;
		var subjectValue=parent.getSubjectValue();
		try{
			if(subjectValue!=null&&subjectValue!=""&&subjectValue!="<点击此处填写标题>"){
				ocxObj.FileName=parent.getSubjectValue();
			}
			ret = ocxObj.WebSaveLocalFile();
			ocxObj.FileName=tempFileName;
		}catch(e){
			ocxObj.FileName=tempFileName;
		};
		ocxObj.WebSetProtect(false,randomPass);
	}
	else
	{
	  try{
      //如果正文中有印章，保存前则设置为受保护的状态
      if(ocxObj.SignatureCount(true)>0){
    	  try{
			  ocxObj.SignatureColor(false);
		  }catch(e){}
    	  ocxObj.WebSetProtect(true,"");
      }else{
    	  ocxObj.WebSetProtect(false,"");
      }
      var tempFileName=ocxObj.FileName;
		var subjectValue=parent.getSubjectValue();
		try{ 
			if(subjectValue!=null&&subjectValue!=""&&subjectValue!="<点击此处填写标题>"){
				ocxObj.FileName=parent.getSubjectValue();
			}
			ret = ocxObj.WebSaveLocalFile();
			ocxObj.FileName=tempFileName;
		}catch(e){
			ocxObj.FileName=tempFileName;
		};
      //保存后恢复正常印章
      if(setSignatureBlack != 'true'){
    	  try{
				ocxObj.SignatureColor(true);
		  }catch(e){}
      }
    }catch(e){};
	}
	return ret ;
}
/**保存到本地时候,对痕迹的处理,由于office问题,保存到本地默认是显示痕迹,只能先删除痕迹然后撤销**/ 
function dealTrackSaveLocalFile(ocxObj,setPassword,isProtect)
{
	if(isProtect){
		ocxObj.WebSetProtect(false,"");
	}
	var ret = false;
	if(ocxObj.FileType==".doc" || ocxObj.FileType==".wps")
	{
		//acceptAllRevisions(ocxObj);  //清除痕迹
		if(isProtect){
			ocxObj.WebSetProtect(true,"");
		}
		ret = setPasswordSaveLocalFile(ocxObj,setPassword);
		ocxObj.WebAcceptAllRevisions(ret);//清除保存到本地文档的痕迹
		//ocxObj.WebObject.Undo();         //撤销上一步的操作 
	}
	else
	{
		ret = setPasswordSaveLocalFile(ocxObj,setPassword);
	}
	if(isProtect){
		ocxObj.WebSetProtect(true,"");
	}
	return ret ;
}

function acceptAllRevisions(ocxObj){
	try{
		ocxObj.WebObject.Application.ActiveDocument.AcceptAllRevisions(); 
	}catch(e){
		
	}
}


//开页面配置对话框
function WebOpenPageSetup(ocxObj){
	try{
		ocxObj.WebObject.Application.Dialogs(178).Show();
	}catch(e){}
	try{
		ocxObj.WebObject.Application.Dialogs(7).Show();
	}catch(e){}	
	try{
		ocxObj.WebObject.Application.Dialogs(16389).Show();
	}catch(e){}
}

function setMenuState(ocx,menuName,state)
{
  if(state){ocx.EnableMenu(menuName);}
  else{ocx.DisableMenu(menuName);}
}
function _sign(ocxObj)
{
	//有专业签章，不能再盖图片章
	if(HasSpecialSignature(ocxObj)){
		alert(getOfficeLanguage("alert_info_canNotSign"));
		return false;
	}
try{
  //新建时候不进行同时修改校验
  if(ocxObj.EditType=="1,0")
  {
  	return ocxObj.WebOpenSignature();  	
  }
	
  var isModify=checkModify(contentId,ocxObj);
  if(isModify!=false)
  {    
    return false;
  }
  
  if(_checkSignUpdate(ocxObj))
  {
  	var srcEditType="";
    var tempStr;
    //保护状态,在全屏切换后会丢失
    //if(ocxObj.EditType=="4,0"){ocxObj.WebSetProtect(false,"");}
    if(ocxObj.EditType=="4,0"){srcEditType="4,0";ocxObj.EditType="1,0";}
    var disPageBlank=true;
    if(ocxObj.FileType==".doc" || ocxObj.FileType==".wps")
    {
    	disPageBlank=ocxObj.WebObject.ActiveWindow.View.DisplayPageBoundaries;    	
    	if(disPageBlank==false)
    	{
    		ocxObj.WebObject.ActiveWindow.View.DisplayPageBoundaries=true;	
    	}
    }
    //盖章之前清除正文痕迹
    /*if(ocxObj.FileType==".doc" || ocxObj.FileType==".wps"||ocxObj.FileType==".docx")
    {
    	acceptAllRevisions(ocxObj);
    }*/
    if(ocxObj.WebOpenSignature())
    {//盖章后，要想移动印章，就不能在保护文档，所有做了一个功能，盖章后先记录当前文字，保存的时候，检查文字是否改变
      if(ocxObj.FileType==".doc"){wordTextContent=ocxObj.WebObject.Content.Text;}
	 // ocxObj.CopyType=false;
    }
    else
    {
      //if(ocxObj.EditType=="4,0"){ocxObj.WebSetProtect(true,"");}
      if(srcEditType=="4,0"){ocxObj.EditType="4,0";}
    }
    if(disPageBlank==false)
    {
    	ocxObj.WebObject.ActiveWindow.View.DisplayPageBoundaries=false;
    }
  }  
  isSignOperation=true;
 }catch(e){}
}
/**
  如果盖过章,检查盖章后是否进行了文字修改
**/
function _checkSignUpdate(ocxObj)
{
try{
  if(ocxObj.SignatureCount(true)>0 && wordTextContent!="")
  {//已经进行过盖章
    tempStr=ocxObj.WebObject.Content.Text;
    if(wordTextContent!=tempStr)
    {
      ocxObj.alert(getOfficeLanguage("alert_SignNoEffect"));
      _loadOffice();
      WebOpenSignature();
      return false;
    }
  }
  }catch(e){}
  return true;
}
//检查contentId的文档是否有人修改,无人修改时返回"false",有人修改时返回修改人员的用户名称
function checkModify(contentId,ocxObj)
{ 
  if((ocxObj.EditType!="0,0" && ocxObj.EditType!="4,0" )|| isSignOperation)
  {//已经是编辑模式，已经标记为自己修改，避免多次校验,签章模式也为4,0,所以另外添加参数isSignOperation来标识是否做了签章操作。
      return false;
  }
  var requestCaller = new XMLHttpRequestCaller(this, "ajaxHandWriteManager", "editObjectState",false);
  requestCaller.addParameter(1, "String", contentId);  
  var ds = requestCaller.serviceRequest();
  if(ds.get("curEditState")=="true")
  {
  	//alert(getOfficeLanguage("用户")+ds.get("userName")+getOfficeLanguage("正在编辑此文件，不能修改！"));    
  	ocxObj.alert(getOfficeLanguage("alert_NotEdit",ds.get("userName")));    
    return true;
  }
  //新建文档，不需要更新
  if(ds.get("lastUpdateTime")==null){return false;}
  //判断是否是用户保护，用户保护可能是excel表格的部分保护，无法恢复，只能重新调入
  var isUserPassword=isUserOfficeProtection(ocxObj);
  if(isUserPassword){editType="2,1";}
  if(ds.get("lastUpdateTime")!=lastUpdateTime || isUserPassword)
  {
  	  	_loadOffice();
  }  
  return false;
}
function setMenuStateByEditType(ocxObj,editType,isSign)
{
  if(editType=="2,1")
  {  
	if(ocxObj.LastType==2)//目前显示是手写批注
  	{
    	if(ocxObj.ShowType!=2){ocxObj.ShowType=2;}//浏览的时候已经切换到文字模式,目前手写是最新的,切换到手写模式
    	ocxObj.EnableMenu(getOfficeLanguage("menu_CharPostil,menu_ClearTrail"));	  
  	}
  	else
  	{
    	if(ocxObj.ShowType!=1){ocxObj.ShowType=1;}
    	ocxObj.WebSetRevision(false,true,false,isShowShenYueMenu);
    	ocxObj.EnableMenu(getOfficeLanguage("menu_ClearTrail,menu_PageSet,menu_DisplayTrail"));
    	if(hasAdvanceOcx == true){
        ocxObj.EnableMenu(getOfficeLanguage("menu_HandWritePostil"));
      }
  	}
  	ocxObj.DisableMenu(getOfficeLanguage("menu_BrowseChar,menu_BrowseHandWrite"));
  	if(isSign)
  	{
  		hasSign=true;//有签名印章的权限
  		if(ocxObj.LastType==0 || ocxObj.LastType==1){ocxObj.EnableMenu(getOfficeLanguage("menu_SginSeal"));}//当最新为文字的时候才可以显示印章
  		else if(ocxObj.LastType==2){ocxObj.DisableMenu(getOfficeLanguage("menu_CheckSeal"));}
  	}
  }
  else if(editType=="0,0" || editType=="4,0")
  {
  	if(ocxObj.ShowType==1)//文字批注
  	{
  		ocxObj.EnableMenu(getOfficeLanguage("menu_CheckSeal,menu_DisplayTrail"));  		
  	}
  	else if(ocxObj.ShowType==2)//手写批注
  	{
  		ocxObj.DisableMenu(getOfficeLanguage("menu_CheckSeal,menu_DisplayTrail"));
  	}
  	ocxObj.DisableMenu(getOfficeLanguage("menu_SginSeal"));
  }
  
}
function ModifyContent(isSign)
{
	
try{
  var ocxObj=document.getElementById("WebOffice");
  checkOpenState();
  if(curMenuID!=200){ocxObj.alert(getOfficeLanguage("alert_CurrectVerNoEdit"));return;}  
  //已经是编辑模式 或者 清稿模式，不在作任何操作  
  if(ocxObj.EditType=="2,1" || ocxObj.EditType=="0,1" || ocxObj.EditType=="2,0" || ocxObj.ShowType==0){return true;}
  //文字编辑模式，有合法印章时禁止修改正文
  if(ocxObj.ShowType==1 && ocxObj.SignatureCount(true)>0)
  {
	  ocxObj.alert(getOfficeLanguage("alert_SignNotEdic"));
	  ocxObj.EditType="0,0";
	  return false;
  }
  var isModify=checkModify(contentId,ocxObj);
  if(isModify!=false)
  {    
    return false;
  }

  //ocxObj.CopyType=true;  
  ocxObj.EditType="2,1";
  setMenuStateByEditType(ocxObj,ocxObj.EditType,isSign);
  //设置文档痕迹保留的状态 参数1:不显示痕迹 参数2:不保留痕迹 参数3:不打印时有痕迹 参数4:不显痕迹处理工具
  ocxObj.WebSetRevision(false,true,false,isShowShenYueMenu);//切换到修改状态时默认为不隐藏痕迹
  //文字编辑模式，检查是有印章，有印章，禁止拷贝
//  if(ocxObj.ShowType==1)
//  {
//	if(ocxObj.SignatureCount(true)>0)
//	{
//		ocxObj.CopyType=false;
//	}
//  }
  adjustMenu(ocxObj);
  return true;
}catch(ea){var errStr=ea.number & 0xFFFF;errStr=errStr+":"+ea.description;alert(errStr);}
return false;
}

/*整体调整菜单,对于xls去掉手写批准相关,只有起草才有打开文件菜单*/
function adjustMenu(ocxObj)
{
  try{
    var docType=ocxObj.FileType.toLowerCase();
    if(docType==".xls" || docType==".et")
    {
      ocxObj.DisableMenu(getOfficeLanguage("menu_CharPostil,menu_HandWritePostil,menu_ClearTrail,menu_ResetPostil,menu_HiddenTrail,menu_DisplayTrail,menu_BrowseChar,menu_BrowseHandWrite"));
    }
    if(docType==".et")
    {
    	ocxObj.DisableMenu(getOfficeLanguage("menu_PageSet"));
    }
    //有印章的时候不允许清稿
    if(HasSpecialSignature(ocxObj))  ocxObj.DisableMenu(getOfficeLanguage("menu_ClearTrail"));
    //2005917_001zhangh begain
    if(ocxObj.EditType!="1,0")
    {//只有在新建的时候才有,打开文件,保存文件
      ocxObj.DisableMenu(getOfficeLanguage("menu_OpenFile"));
    }
    //2005917_001zhangh end

      ocxObj.WebToolsVisible(getOfficeLanguage('menu_A8Col'),false);
      
      //setAllToolsState(ocxObj,false);
      //根据页面设置控制菜单
      setToolsPrintState(ocxObj);
      if(parent.officecanSaveLocal=="false")
      {
      	//暂时屏蔽如下行，金格控件问题，禁止拷贝后，无法生成手写批注，控件更新后，再屏蔽拷贝功能
      	//ocxObj.CopyType=false;
      	ocxObj.DisableMenu(getOfficeLanguage("menu_SaveFile"));
      	//ocxObj.DisableMenu(getOfficeLanguage("menu_SaveExit"));
      }  
       //公文模块才需要进行控制
      if(parent.document.getElementById("edocType")){
      		isAuthorityToCopy(ocxObj);
      }
      if(isFromRegsitPendingList()){  //登记页面清除痕迹 
    	  ocxObj.WebObject.Application.ActiveDocument.AcceptAllRevisions();  //清除痕迹
      }
      var PDF417Manager = parent.document.getElementById("PDF417Manager");
      if(PDF417Manager && typeof parent.CopyRight && (ocxObj.FileType == ".doc" || ocxObj.FileType == ".docx") 
    		  && (ocxObj.EditType == "1,0" || ocxObj.EditType == "2,0" || ocxObj.EditType == "3,0" || ocxObj.EditType == "2,1" || ocxObj.EditType == "1,1") || ocxObj.EditType == "3,1"){
    	  ocxObj.EnableMenu(getOfficeLanguage("menu_BarCode"));
      }
    }catch(e){}
}
//是否有复制正文的权限 
//如果节点有【(正文修改||正文保存)&&没有印章】的权限，则允许复制office正文。
function isAuthorityToCopy(ocxObj){
	 var bool=false;
	 var edocType=parent.document.getElementById("edocType").value;
	 
	 //1.发文，收文，签报 新建页面具有拷贝权限

 	 if(parent.currentPage && parent.currentPage=="newEdoc"){
 		ocxObj.CopyType=true;
 		return;
 	 }
 	 //2、中间处理节点由节点权限来判断。
	 //if(parent.officecanPrint=="true") bool= true;
	 if(parent.officecanSaveLocal=="true")  bool= true;	
	// 取detail对话框右边showDialogram.jsp页面中的js变量canEdit(是否有修改正文的权限)  
	 if(typeof(parent.canEdit)!="undefined"){
		if(parent.canEdit=="true")bool=true; 
	 }
	 //4、是否有合法印章		
	 var hasSign=ocxObj.SignatureCount(true)>0;
	 
	 if(bool && !hasSign)  {
	 	ocxObj.CopyType=true;
	 }else {
	 	ocxObj.CopyType=false;
	 	//必须设置成0,0,不要随意修改，否则可以拷贝
	 	ocxObj.EditType="0,0";
	 }
}
function WebOpenSignature()
{
  checkOpenState();
  var ocxObj=document.getElementById("WebOffice");
  //<!--****修改号="20060607zhangh_003"  区域="1"  *****************开始-->
  //如果上次编辑为手写批注模式最新为手写，当前不是清稿模式，不能盖章
  //                          最新为文字（上次编辑为文字或者清稿），当前为手写批注模式，不允许盖章
  if((ocxObj.LastType==2 && ocxObj.ShowType!=0) || ((ocxObj.LastType==0 || ocxObj.LastType==1) && ocxObj.ShowType==2))
  {
    ocxObj.alert(getOfficeLanguage("alert_NotSign"));
    return;
  }
  //当文字只读模式盖章，把文字状态模式修改为4，手写编辑模式保持不变
  //已经是编辑模式 或者 清稿模式，允许盖章，不设置成盖章模式  
  if(!(ocxObj.EditType=="2,1" || ocxObj.EditType=="0,1" || ocxObj.EditType=="2,0" || ocxObj.ShowType==0))
  {
	  ocxObj.EditType="4,0";
  }
  //检查当前显示模式，如果是手写批注模式，切换到文字模式
  if(ocxObj.ShowType==2){ocxObj.ShowType=1;}
  //<!--****修改号="20060607zhangh_003"  区域="1"  *****************结束-->
  ocxObj.EnableMenu(getOfficeLanguage("menu_SginSeal"));
 // ocxObj.CopyType=false;
  FullSize();
}

//当前参数重新掉入文档
function reLoad(ocxObj)
{
	var ret=false;
	try{
  		reWrite=false;
  		ret=ocxObj.WebOpen();
  	}catch(ea){var errStr=ea.number & 0xFFFF;errStr=errStr+":"+ea.description;alert(errStr);ret=false;}
  	return ret;
}
//修改正文时，记录修改人，退出时取消修改状态
function OcxUnLoad()
{  
  try{if(parent.isNewOfficeFilePage==true){return;};}catch(e){}
  if(checkNeedSave()==false){return;}
  var ocxObj = document.getElementById("WebOffice");
  if(ocxObj.EditType == "0,0"){	//只读状态得文档没有必要保存
		return;
  }
  try{ ocxObj.WebClose();}catch(e){}
  var requestCaller = new XMLHttpRequestCaller(this, "ajaxHandWriteManager", "deleteUpdateObj",false);
  requestCaller.addParameter(1, "String", contentId);  
  var ds = requestCaller.serviceRequest();  
}
//4,0盖章，也得保存，不管默认是什么编辑状态，花脸统一设置成0，0，不可随意改动。
//每次花脸保存的时候，都会覆盖当前正文，因为保存时候的RECORDID取的是parent.fileId.除非改变这个值
//此函数没有设置这个值，所以有覆盖当前正文的可能。修改时请注意。
function shiftVer(ocxObj,mIndex,vCaption)
{  
  if(mIndex!=200)//查看历史版本时,先检查对当前版本的修改是否保存
  {
    if(ocxObj.EditType!="0,0")
    {
      //提示用户是否需要保存;
	  if(ocxObj.confirm(getOfficeLanguage("alert_saveEdit"))==true)
	  {
		if(saveOffice()==false)
		{
			ocxObj.alert(getOfficeLanguage("alert_SaveFalseNotChange"));
			return;
		}
	  }
    }
    ocxObj.WebSetMsgByName("checkBack","false");//显示备份版本时,不需要检查备份
    //第一次进行版本切换时候,保存当前版本编辑状态
    if(curMenuEditType==""){curMenuEditType=ocxObj.EditType;}
  }
  contentId=getVerMenuDataId(ocxObj,mIndex);
  editType="0,0";
  _loadOffice();
  //if(_loadOffice())
  {
	ocxObj.DisableMenu(getVerMenuName(mIndex));
	ocxObj.EnableMenu(getVerMenuName(curMenuID));
	curMenuID=mIndex;
	if(mIndex==200)//切换到当前版本后,设在编辑模式和菜单
	{
		ocxObj.EditType=curMenuEditType;
		setMenuStateByEditType(ocxObj,curMenuEditType,hasSign);
	}
  }
}
function taohongLogo(ocxObj){
	//判断套红模板中是否存在logoimg书签
	try{
		var bool=false;
		var mCount = ocxObj.WebObject.Bookmarks.Count;
		for(i=1;i<mCount+1;i++){
			var markname=ocxObj.WebObject.Bookmarks(i).Name;
			if(markname=="logoimg"){bool=true;break;}
		}
		if(bool){
			ocxObj.WebInsertImage("logoimg","logoimg.gif",true,4);
		}
	}catch(e){}
}
function taohongForm(dataForm,templateUrl,templateType,dataList)
{
	checkOpenState();
  var ocxObj = document.getElementById("WebOffice");
  ocxObj.Template=templateUrl;
  ocxObj.WebSetMsgByName("COMMAND","INSERTFILE");
   
  	   	if(ocxObj.WebLoadTemplate())
  		{  	
  			ocxObj.EditType="1,0";
			setAllLable(dataForm,templateType,dataList);
			//FullSize();
			ocxObj.WebSetMsgByName("CREATEDATE", parent.createDate);
			ocxObj.WebSetMsgByName("needReadFile", "true");
			ocxObj.WebSetMsgByName("checkBack", "false");	
			taohongLogo(ocxObj);		
			ocxObj.WebInsertFile();
			ocxObj.DisableMenu(getOfficeLanguage("menu_BrowseChar,menu_BrowseHandWrite,menu_HiddenTrail,menu_DisplayTrail"));
		} 	
		//套红后，隐藏痕迹，设置痕迹控制菜单
		ocxObj.WebSetRevision(false,true,false,isShowShenYueMenu);
		ocxObj.DisableMenu(getOfficeLanguage("menu_HiddenTrail"));
    	ocxObj.EnableMenu(getOfficeLanguage("menu_DisplayTrail"));
}

function taohong(dataForm,templateUrl,templateType,dataList)
{
	
  checkOpenState();

  var ocxObj = document.getElementById("WebOffice");
  ocxObj.Template=templateUrl;
  
  //增加防护，避免没有套红成功保存，原文件内容丢失问题
  
  ocxObj.WebSetMsgByName("CUROPERATE","TaoHong");
  ocxObj.WebSetMsgByName("COMMAND","INSERTFILE");
   
  	   	if(ocxObj.WebLoadTemplate())
  		{  	
  			ocxObj.EditType="1,0";
  			ocxObj.EnableMenu(getOfficeLanguage("menu_PageSet"));
			setAllLable(dataForm,templateType,dataList);
			FullSize();
			ocxObj.WebSetMsgByName("CREATEDATE", parent.createDate);
			ocxObj.WebSetMsgByName("needReadFile", "true");
			ocxObj.WebSetMsgByName("checkBack", "false");
			taohongLogo(ocxObj);								
			if(ocxObj.WebInsertFile()){ocxObj.WebSetMsgByName("CUROPERATE","");}			
			ocxObj.DisableMenu(getOfficeLanguage("menu_BrowseChar,menu_BrowseHandWrite,menu_HiddenTrail,menu_DisplayTrail"));
		} 	
		//套红后，隐藏痕迹，设置痕迹控制菜单
		ocxObj.WebSetRevision(false,false,false,isShowShenYueMenu);
		ocxObj.DisableMenu(getOfficeLanguage("menu_HiddenTrail"));
    	ocxObj.EnableMenu(getOfficeLanguage("menu_DisplayTrail"));   
  	    contentUpdate=true;	
}


function setAllLable(dataForm,templateType,dataList)
{
	try{
		for(var i = 0; i < dataList.length; i++){
			var name = dataList[i].name;
			var index = name.indexOf("my:");
			var label = name.substring(3,name.length);			
			if(index!=-1){
				try{setLable(label,dataList[i].value);}catch(e){}				
			}
		}
	}catch(e){}

	var len = dataForm.elements.length;
	
	if(templateType=="edoc"){ // 正文套红
		for(var i=0;i<len;i++){
			var name = dataForm.elements[i].name;
			if(!name)continue;
			var index = name.indexOf("my:");
			var label = name.substring(3,name.length);			
			if(index!=-1){
				if(label == "doc_mark" || label == "doc_mark2" || label == "serial_no"){
					try{
						var docMark = dataForm.elements[name].value;
						if (docMark.indexOf("|") != -1) {
							var docMarkArray = docMark.split("|");
							if(docMarkArray.length > 1){
								setLable(label,docMarkArray[1]);
							}
						} else {
							setLable(label,docMark);
						}
						continue;
					}catch(e){}					
				}
				var tagName = dataForm.elements[name].tagName;
				if(tagName !="undefined" && (tagName == "SELECT" || tagName == "select")){
					if(label == "doc_mark"){
							try{
								var docMark = dataForm.elements[name].value;
								var docMarkArray = docMark.split("|");
								if(docMarkArray.length > 1){
									setLable(label,docMarkArray[1]);
								}
							}catch(e){}					
					}else{
						var select = dataForm.elements[i];
						for(var j=0;j<select.options.length;j++)
						{
							if(select.options[j].selected == true){
								try{setLable(label,select.options[j].text);}catch(e){}								
							}
						}
	
					}			
				}else{
					try{setLable(label,dataForm.elements[name].value);}catch(e){}	
				}
			}
		}
	}
	else{ // 文单套红
		for(var i=0;i<len;i++){
			var name = dataForm.elements[i].name;
			var index = name.indexOf("my:");
			var label = name.substring(3,name.length);			
				if(index!=-1){
					//孙老师意见：文单套红只是不套正文的内容，其他的都要套。
					if(label=="Content"){
						continue;
					}
					
					if(label == "doc_mark" || label == "doc_mark2" || label == "serial_no"){
						try{
							var docMark = dataForm.elements[name].value;
							if (docMark.indexOf("|") != -1) {
								var docMarkArray = docMark.split("|");
								if(docMarkArray.length > 1){
									setLable(label,docMarkArray[1]);
								}
							} else {
								setLable(label,docMark);
							}
							continue;
						}catch(e){}					
					}
					var tagName = dataForm.elements[name].tagName;
					if(tagName !="undefined" && (tagName == "SELECT" || tagName == "select")) {
						var select = dataForm.elements[i];
						for(var j=0;j<select.options.length;j++)
						{
							if(select.options[j].selected == true){
								try{setLable(label,select.options[j].text);}catch(e){}								
							}
						}
					}else{
						try{
							setLable(label,dataForm.elements[name].value);
						}catch(e){
							
						}	
					}
				}		
			}
		}	
		taohongOpinion();
}

//套红意见。
function taohongOpinion(){
	try{
		var  opinionArr = parent.getOpinionsForTaoHong(); 
		var opinions = opinionArr[0];
		var senderOpinion = opinionArr[1];
		if(opinions){
			for(var i=0 ;i<opinions.length ; i++){
				setLable(opinions[i][0],opinions[i][1]);
			}
		}
		if(senderOpinion){
			setLable("niwen",senderOpinion);
			setLable("dengji",senderOpinion);
		}
	}catch(e){
		
	}
}

function setLable(mylable,mycontent)
{  
	var ocxObj = document.getElementById("WebOffice");
	if(mylable.search("date")!=-1)
	{//名称中包括了data就为date数据类型
		if(mylable=="signing_date"){//签发日期转化为大写。
			mycontent=parent.date2chinese0(mycontent);
		}else{
			mycontent=parent.date2chinese1(mycontent);
		}
	}
	//套红时发文单位显示格式
	if(mylable.search("send_unit")!=-1) {
		if(parent.contentIframe) {
			var sendForm = parent.contentIframe.document.getElementById("sendForm");
			if(sendForm.taohongSendUnitType && sendForm.taohongSendUnitType.value==1) {
				var sendUnitName = parent.getSendUnitName(mylable);
				if(sendUnitName!=null && sendUnitName!="") {
					mycontent = sendUnitName;
				}
			}			
		}
	}
	
  	try{ocxObj.WebSetBookmarks(mylable,mycontent);}catch(e){alert(e);}
}
function officePrint()
{
	if(!isHandWriteRef())return;
	var ocxObj = document.getElementById("WebOffice");
	checkOpenState();
	FullSize();
	ocxObj.WebOpenPrint();	
}

function getOfficeLanguage(keys)
{
	return parent.getOfficeLanguage(keys,arguments);
}
function setOfficeOcxRecordID(recordId)
{
	var ocxObj = document.getElementById("WebOffice");
	ocxObj.RecordID=recordId;
	contentId=recordId;
	isLoadOfficeFile=false;
	wordTextContent="";
}

function getOfficeOcxRecordID()
{
	var ocxObj = document.getElementById("WebOffice");	
	return contentId;	
}
//得到控件当前版本ID
function getOfficeOcxCurVerRecordID()
{
	if(curMenuID>200)
	{//当前为清稿备份版本
		return curDataID;
	}
	else
	{
		var ocxObj = document.getElementById("WebOffice");	
		return contentId;	
	}
}

////////////////////////////////////////如下代码为判断控件是否保护代码////////////////////////////////////////////////


//作用：判断Excel是否有未选择锁定的单元格
function HasNoLockedRangeXls(ocxObj){
  if(ocxObj.WebObject.ActiveSheet.UsedRange.Locked==true)
  {
  	return true;   //存在单元格锁定
  }
  else
  {
    return false;  //无单元格锁定
  }
}

//判断是否是用户进行了保护,设置了自己的密码
function isUserOfficeProtection(ocxObj)
{
	var ret=false;
	try{	
	if(IsOfficeProtection(ocxObj)==0){return false;}
	ocxObj.WebSetProtect(false,"");
	var proState=IsOfficeProtection(ocxObj);
	if(proState!=0)
	{//用户设置了密码,解锁失败
		return true;
	}
	ocxObj.WebSetProtect(true,"");
	}catch(e){}
	return ret;
}

//作用：判断当前OFFICE文档保护状态
function IsOfficeProtection(ocxObj){
    //alert(FileType);
    var mIsProtection = 0;  //无锁定
    try{
    if (ocxObj.FileType==".doc" || ocxObj.FileType==".wps"){
      if (ocxObj.WebObject.ProtectionType!=-1){  //表示当前DOC文档有锁定
      	mIsProtection = 1;  //全部锁定
      }
    }
    if (ocxObj.FileType==".xls"){
      /*
      webform.WebOffice.SignatureColor(false);    //将签章变为黑白(EXCEL部分锁定无法执行)
      alert("HasNoLockedRange="+HasNoLockedRangeXls());
      alert(webform.WebOffice.WebObject.ActiveSheet.ProtectScenarios);      
      alert(webform.WebOffice.WebObject.ActiveSheet.ProtectContents);
      alert(webform.WebOffice.WebObject.ActiveSheet.ProtectDrawingObjects);
      */
      
      if (HasNoLockedRangeXls(ocxObj)){
      	if (ocxObj.WebObject.ActiveSheet.ProtectScenarios||ocxObj.WebObject.ActiveSheet.ProtectContents||ocxObj.WebObject.ActiveSheet.ProtectDrawingObjects){
      		mIsProtection = 2;  //部分锁定
      	}else{
      	  mIsProtection = 0;  //无锁定
      	}
      }else{
      	if (ocxObj.WebObject.ActiveSheet.ProtectScenarios||ocxObj.WebObject.ActiveSheet.ProtectContents||ocxObj.WebObject.ActiveSheet.ProtectDrawingObjects){
      		mIsProtection = 1;  //全部锁定
      	}else{
      	  mIsProtection = 0;  //无锁定
      	}    
      }
    }
    else if(ocxObj.FileType==".et")
    {
      mIsProtection=IsEtProtection(ocxObj);
    }
    }catch(e){}
    //alert(mIsProtection);
    return (mIsProtection);
}
//作用：判断当前金山表格文档保护状态
function IsEtProtection(ocxObj){
    var mIsProtection = 0;  //无锁定
    //alert(FileType);
    if (ocxObj.FileType==".et"){
      //alert("Locked="+webform.WebOffice.WebObject.ActiveSheet.UsedRange.Locked);
      //alert("ProtectContents="+webform.WebOffice.WebObject.ActiveSheet.ProtectContents);
      
      if(ocxObj.WebObject.ActiveSheet.UsedRange.Locked==9999999){
      	if (ocxObj.WebObject.ActiveSheet.ProtectContents){
      		mIsProtection = 2;  //部分锁定
      	}else{
      	  mIsProtection = 0;  //无锁定
      	}
      }else{
      	if (ocxObj.WebObject.ActiveSheet.ProtectContents){
      		mIsProtection = 1;  //全部锁定
      	}else{
      	  mIsProtection = 0;  //无锁定
      	}    
      }
    }
    //alert(mIsProtection);
    return (mIsProtection);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/**
设置所有菜单的显示状态,false 隐藏 true 显示
**/
function setAllToolsState(ocxObj,state)
{
try{
  //var ocxObj=webform.WebOffice;
  //ocxObj.ShowMenu=state?"1":"0";
  ocxObj.ShowMenu="1";
  ocxObj.WebToolsVisible('Tables and Borders',state);//表格和边框
  ocxObj.WebToolsVisible('Database',state);// 数据库
  ocxObj.WebToolsVisible('Drawing',state);//绘图
  ocxObj.WebToolsVisible('Forms',state);//窗体
  ocxObj.WebToolsVisible('Visual Basic',false);// isual Basic
  ocxObj.WebToolsVisible('Mail Merge',state);// 合并
  ocxObj.WebToolsVisible('Extended Formatting',state);//其它格式
  ocxObj.WebToolsVisible('AutoText',state);//自动图文集
  ocxObj.WebToolsVisible('Web',state);//Web
  ocxObj.WebToolsVisible('Picture',state);//图片
  ocxObj.WebToolsVisible('Control Toolbox',state);//控件工具箱
  ocxObj.WebToolsVisible('Web Tools',state);//Web工具箱
  ocxObj.WebToolsVisible('Standard',false);//标准
  ocxObj.WebToolsVisible('Formatting',false);//格式
  ocxObj.WebToolsVisible('Reviewing',false);//审阅
  ocxObj.WebToolsVisible('Frames',false);//框架集
  ocxObj.WebToolsVisible('WordArt',false);//艺术字
  ocxObj.WebToolsVisible('符号栏',false);//符号栏
  ocxObj.WebToolsVisible('Outlining',false);// 大纲
  ocxObj.WebToolsVisible('E-mail',false);//电子邮件
  ocxObj.WebToolsVisible('Word Count',false);//字数统计
  try{webform.WebOffice.ToolsSpace="0";}catch(e){}//隐藏菜单下面开始无法隐藏的灰色挑
  /*禁止显示word标尺，导致多次打开控件出现异常
  if(ocxObj.FileType==".doc")
  {
    ocxObj.WebObject.ActiveWindow.ActivePane.DisplayRulers=state;//false表示关闭true表示显示
  }
  */
  }catch(ea){var errStr=ea.number & 0xFFFF;errStr=errStr+":"+ea.description;alert(errStr);}
}

//作用：禁止或启用工具 参数1表示工具条名称  参数2表示工具条铵钮的编号  （名称和编号均可查找VBA帮助）
//参数3为false时，表示禁止  参数3为true时，表示启用
function WebToolsEnable(ocxObj,ToolName,ToolIndex,Enable){
  try{
    ocxObj.WebToolsEnable(ToolName,ToolIndex,Enable);    
  }catch(e){}
}

function WebToolsPrintState(ocxObj,Enable)
{
    try{
    	if ((ocxObj.FileType==".doc")||(ocxObj.FileType==".xls"))
    	{
        	WebToolsEnable(ocxObj,'Standard',2521,Enable);  //屏蔽打印铵钮
        	WebToolsEnable(ocxObj,'Standard',108,Enable);  //屏蔽打印预览按钮
      	}
      	if ((ocxObj.FileType==".wps")||(ocxObj.FileType==".et"))
      	{
      	    try{
        	   ocxObj.WebObject.Application.CommandBars("Standard").Controls("打印").Enabled = Enable;  //屏蔽打印铵钮
        	   ocxObj.WebObject.Application.CommandBars("Standard").Controls("打印预览(&V)").Enabled = Enable;  //屏蔽打印铵钮
      	    }catch(e){}
      	}
      	ocxObj.Print=Enable;
  	}catch(e){}
}

function contentIsModify()
{
	var ocxObj = document.getElementById("WebOffice");
	if(ocxObj.EditType=="0,0"){return false;}
	//没有盖章的时候，状态为4,0的时候，返回false，表示没有修改正文。
	if(ocxObj.EditType=="4,0"&&!isSignOperation) return false;
	return ocxObj.Modify;
}

function setToolsPrintState(ocxObj)
{
	  //根据页面设置控制菜单	  
      if(parent.officecanPrint=="false")
      {
      	ocxObj.DisableMenu(getOfficeLanguage("menu_Print"));
      	ocxObj.DisableMenu(getOfficeLanguage("menu_PrintPreview"));
      	WebToolsPrintState(ocxObj,false);
      }
       if(parent.officecanSaveLocal=="false"){	
          	ocxObj.DisableMenu(getOfficeLanguage("menu_SaveFile"));
      }
}
//å¤æ­æ­£æä¸­æ¯å¦æäºå°ç« 
function getSignatureCount(){
  var ocxObj=document.getElementById("WebOffice");
  checkOpenState();
  return ocxObj.SignatureCount(true)>0;
}
/**
 *是否有专业签章、
 */
function HasSpecialSignature(ocxObj){
  var i,Shape;
  var Result = false;
  try{
	  var shapes = ocxObj.WebObject.Shapes;
	  if(shapes == undefined){
		  return Result;
	  }
      for(i=1;i<= shapes.Count;i++){
        Shape = shapes.Item(i);
        if(Shape.Type == 12){
          if(Shape.OLEFormat.ClassType == "iSignatureOffice.SignatureCtrl"){
            Result = true;
            break;
          }
        }
      }
  }catch(e){}
  return Result;
}
var isAlert = false;
//如果不安装就引用不了。这里是引用的判断。
function isHandWriteRef(){
	var status=true;
	try{
		var ocxObj = document.getElementById("WebOffice");
//		var mObj = new ActiveXObject("HandWrite.HandWriteCtrl");
//		ocxObj.WebReFresh();
		ocxObj.WebGetMsgByName("needReadFile");
	}catch(e){
		//报异常就是没有引用的意思。
		status = false;
		/*if(!isAlert) {
			alert(getOfficeLanguage("alert_err_HandWrite_Disbaled"));
			isAlert = true;
		}*/
		//代码合并有误，解决office提示不断提出，应该使用以下方式
		alert(getOfficeLanguage("alert_err_HandWrite_Disbaled"));
		if(oInterval) {
			window.clearInterval(oInterval);
		}
	}
	return status;
}
//删除文档中所有书签
function delBookMarks(){
	try{
		var ocxObj = document.getElementById("WebOffice");
		var mCount = ocxObj.WebObject.Bookmarks.Count;
		for(i=1;i<mCount+1;i++){
			ocxObj.WebObject.Bookmarks(1).Delete();
		}
	}catch(e){
		
	}
}
/**
 * 激活office控件.
 */
function activeOcx(){
	var ocxObj = document.getElementById("WebOffice");
	if(ocxObj!= null){
		try{
			ocxObj.Active(true);
		}catch(e){
			
		}
	}
}

function transAttribute(_editType){
  var ocxObj = document.getElementById("WebOffice");
  var result,type;
  if(ocxObj){
    type = ocxObj.EditType;
  }else{
    type ="0,0";
  }
  var arr = type.split(",");
  if(arr){
    if(_editType.canEdit == "0" && _editType.canCopy == "0"){
      arr[0] = "0";
    }else if(_editType.canEdit == "0" &&  _editType.canCopy == "1"){
      arr[0] = "4";
    }else if(_editType.canEdit == "1"){
      arr[0] = "1";
    }else if(_editType.hasTrail == "0" || _editType.hasTrail == "1"){
      arr[1] = _editType.hasTrail;
    }
    result = arr[0] + "," + arr[1];
    if(ocxObj)
      ocxObj.EditType = result;
  }
  editType = result;
}

/*客开 项目名称：新疆兵团项目  作者：weijuan 修改日期：2014-5-20 [修改功能：安证通电子签章修改]start */
document.write('<OBJECT classid="clsid:55289447-C9FF-424B-B08B-7EA6DAC45061" CODEBASE="printdoc.ocx#version=2,0,0,0" id="printdoc"></OBJECT>');
/*客开 项目名称：新疆兵团项目  作者：weijuan 修改日期：2014-5-20 [修改功能：安证通电子签章修改]end */