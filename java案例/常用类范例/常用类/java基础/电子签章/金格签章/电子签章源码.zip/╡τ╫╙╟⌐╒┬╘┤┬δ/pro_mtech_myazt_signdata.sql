/*
MySQL Data Transfer
Source Host: localhost
Source Database: v3xxj
Target Host: localhost
Target Database: v3xxj
Date: 2014-6-2 10:56:18
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for pro_mtech_myazt_signdata
-- ----------------------------
DROP TABLE IF EXISTS `pro_mtech_myazt_signdata`;
CREATE TABLE `pro_mtech_myazt_signdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sign_data` text,
  `f_id` varchar(50) DEFAULT NULL,
  `f_link` varchar(50) DEFAULT NULL,
  `sign_date` varchar(23) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
