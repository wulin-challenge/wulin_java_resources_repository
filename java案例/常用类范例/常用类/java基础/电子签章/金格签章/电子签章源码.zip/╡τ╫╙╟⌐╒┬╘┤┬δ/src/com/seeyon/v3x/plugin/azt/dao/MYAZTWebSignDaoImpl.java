package com.seeyon.v3x.plugin.azt.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.seeyon.ctp.common.dao.BaseHibernateDao;
import com.seeyon.ctp.util.DateUtil;
import com.seeyon.v3x.plugin.azt.po.MYAZTSignDataPO;
/**
 * 
 * 客开 项目名称：新疆兵团 作者：wangyinan 修改日期：2014-05-20 [修改功能：安证通盖章] start
 * 
 */
public class MYAZTWebSignDaoImpl extends BaseHibernateDao<MYAZTSignDataPO>
		implements MYAZTWebSignDao {
	private static final Log log = LogFactory.getLog(MYAZTSignDataPO.class);

	public MYAZTSignDataPO getSignData(Long id) {
		try {
			return super.get(id);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return null;
		}
	}

	public Long saveDataPO(String data, String fid, String flink) {
		try {
			MYAZTSignDataPO dto = new MYAZTSignDataPO();
			// dto.setId(UUIDLong.absLongUUID());
			dto.setFid(fid);
			dto.setFlink(flink);
			dto.setSigndata(data);
			dto.setSigndate(DateUtil.format(new Date(),
					DateUtil.YEAR_MONTH_DAY_HOUR_MINUTE_SECOND_PATTERN));
			save(dto);
			return dto.getId();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public void deleteDataPO(Long id) {
		String hql = "delete from MYAZTSignDataPO where id=:id ";
		Map nameParameters = new HashMap();
		nameParameters.put("id", id);
		super.bulkUpdate(hql, nameParameters, new Object[0]);
	}

	public List<MYAZTSignDataPO> getDataByFidAndFlink(String fid, String flink) {
		String hql = "from MYAZTSignDataPO where fid=:fid and flink=:flink";
		List<MYAZTSignDataPO> ls = null;
		try {
			Map nameParameters = new HashMap();
			nameParameters.put("fid", fid);
			nameParameters.put("flink", flink);
			ls = super.find(hql, nameParameters, new Object[0]);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ls;
	}

}
/**
 * 
 * 客开 项目名称：新疆兵团 作者：wangyinan 修改日期：2014-05-20 [修改功能：安证通盖章] end
 * 
 */