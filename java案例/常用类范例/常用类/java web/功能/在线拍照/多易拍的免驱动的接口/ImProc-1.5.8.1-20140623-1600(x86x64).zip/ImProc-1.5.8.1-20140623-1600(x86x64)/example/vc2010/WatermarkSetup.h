#pragma once

class CWatermarkSetup : public CDialog
{
	DECLARE_DYNAMIC(CWatermarkSetup)
	DECLARE_MESSAGE_MAP()
public:
	enum { IDD = IDD_WATERMARK_SETUP };

	CWatermarkSetup(HANDLE hVideoInput); 
	virtual ~CWatermarkSetup();
	virtual void DoDataExchange(CDataExchange* pDX);
protected:
	HANDLE m_hVideoInput;
	size_t m_nDeviceIndex;
	CString m_szText;
	CString m_szRectX;
	CString m_szRectY;
	CString m_szRectW;
	CString m_szRectH;
	CString m_szFont;
	CString m_szSize;
	CString m_szColor;
	CString m_szTrans;
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedWatermarkMasktorect();
	afx_msg void OnBnClickedOk();
	afx_msg void OnEnChangeWatermarkText();
	afx_msg void OnEnChangeWatermarkFont();
};
