Extensions
---
1. BarcodeR
2. Zxing

Version
---
1.3.1. Video record
1.3.2. Grab to base64
1.3.3. CustomExposure
1.4.0. GrabToPdf, JpegToPdf
1.4.2. AutoGrab
1.4.3. Enhance, CameraControl, VideoProcAmp
1.4.4. QRcode
1.4.5. TIFF-JPEGv7
1.4.6. SetStopOnChange, GetDeviceFormatIndex,
       ShowSaveFileDialog, Undistort
1.4.7. HttpPostFile, AutoGrab(ByTime), MouseEnable,HttpPostFileH
1.4.8. GetJpegQuality, CombineImages, Watermark
1.4.9. StitchImages, GetDeviceType
1.5.0. Rotate Any Angle
1.5.1. Fill Border
1.5.3. JpegToTiff, FillHole(1.5.3.2)
1.5.4. ShowGrabbedFile, JPEG/TIFF Tags.
1.5.5. RotateGrabbedFileByString
1.5.6. GrabToFile(GIF)
1.5.7. RotateImage
1.5.8. JpegToZip
