﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace VideoInputForm
{
    class VideoInput
    {
        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool PostMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

        #region Release
        [DllImport("VideoInput.dll")]
        public static extern IntPtr CreateVideoInput();
        #endregion

        #region Open/Close
        //Device
        [DllImport("VideoInput.dll")]
        public static extern int GetDeviceIndex(IntPtr handle);

        [DllImport("VideoInput.dll")]
        public static extern bool OpenDevice(IntPtr handle, int nDeviceIndex);

        [DllImport("VideoInput.dll")]
        public static extern int GetDeviceCount(IntPtr handle);

        [DllImport("VideoInput.dll", CharSet = CharSet.Unicode)]
        public static extern bool GetDeviceName(IntPtr handle, int nDeviceIndex, StringBuilder szDeviceName, int nNameSize);

        [DllImport("VideoInput.dll", CharSet = CharSet.Unicode)]
        public static extern int OpenDeviceName(IntPtr handle, StringBuilder szDeviceName);

        //Image
        [DllImport("VideoInput.dll", CharSet = CharSet.Unicode)]
        public static extern bool OpenImageFile(IntPtr handle, StringBuilder szFileName);
        #endregion

        #region Start/Stop
        //Device
        [DllImport("VideoInput.dll")]
        public static extern bool StartPlayDevice(IntPtr handle, int nDeviceIndex);

        //Image
        [DllImport("VideoInput.dll")]
        public static extern bool StartPlayImageFile(IntPtr handle);

        [DllImport("VideoInput.dll")]
        public static extern bool StopPlayImageFile(IntPtr handle);
        #endregion

        #region Preview
        [DllImport("VideoInput.dll")]
        public static extern bool SetPreviewWindow(IntPtr handle, IntPtr hWnd);
        #endregion

        #region Grab
        [DllImport("VideoInput.dll", CharSet = CharSet.Unicode)]
        public static extern string GrabToBase64(IntPtr hVideoInput, string szFileExt);

        [DllImport("VideoInput.dll", CharSet = CharSet.Unicode)]
        public static extern bool GrabToFile(IntPtr handle, string szFileName);

        [DllImport("VideoInput.dll")]
        public static extern bool SetDeviceAutoGrab(IntPtr handle,int nDeviceIndex,bool  bAutoGrab);

        [DllImport("VideoInput.dll")]
        public static extern bool SetDeviceNotifyWindow(IntPtr hVideoInput, int nDeviceIndex, IntPtr hWnd);
        
        #endregion

        #region Src/Dst/Mask
        [DllImport("VideoInput.dll")]
        public static extern bool ZoomDeviceDstRect(IntPtr handle, int nDeviceIndex, float nScaleX, float nScaleY);

        [DllImport("VideoInput.dll")]
        public static extern bool ZoomImageFileDstRect(IntPtr handle, float nScaleX, float nScaleY);
        #endregion

        #region Deskew
        [DllImport("VideoInput.dll")]
        public static extern bool SetDeskewPreview(IntPtr handle, bool bPreview);

        //Device
        [DllImport("VideoInput.dll")]
        public static extern bool SetDeviceDeskew(IntPtr handle, int nDeviceIndex,bool bDeskew);

        [DllImport("VideoInput.dll")]
        public static extern bool SetDeviceDeskewSetting(IntPtr handle,int nDeviceIndex,
                              int nMergeDist, int nDownSize, int nGaussKernel,
                              int nDilateKernel, int nReservX, int nReservY,
                              int nCannyLow, int nCannyHigh);

        [DllImport("VideoInput.dll")]
        public static extern bool GetDeviceDeskewSetting(IntPtr handle,int nDeviceIndex,
                              out int nMergeDist, out int nDownSize, out int nGaussKernel,
                              out int nDilateKernel, out int nReservX, out int nReservY,
                              out int nCannyLow, out int nCannyHigh);

        //Image
        [DllImport("VideoInput.dll")]
        public static extern bool SetImageFileDeskew(IntPtr handle, bool bDeskw);

        [DllImport("VideoInput.dll")]
        public static extern bool GetImageFileDeskew(IntPtr handle);

        [DllImport("VideoInput.dll")]
        public static extern bool SetImageFileDeskewSetting(IntPtr handle,
                              int nMergeDist, int nDownSize, int nGaussKernel,
                              int nDilateKernel, int nReservX, int nReservY,
                              int nCannyLow, int nCannyHigh);
        
        [DllImport("VideoInput.dll")]
        public static extern bool GetImageFileDeskewSetting(IntPtr handle,
                              out int nMergeDist, out int nDownSize, out int nGaussKernel,
                              out int nDilateKernel, out int nReservX, out int nReservY,
                              out int nCannyLow, out int nCannyHigh);
        #endregion
    }
}
