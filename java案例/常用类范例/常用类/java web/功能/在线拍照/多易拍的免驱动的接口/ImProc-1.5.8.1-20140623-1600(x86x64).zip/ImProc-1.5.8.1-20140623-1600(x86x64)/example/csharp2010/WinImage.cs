﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace VideoInputForm
{
    public partial class WinImage : Form
    {
        string filename;
        public WinImage(string filename)
        {
            InitializeComponent();
            this.filename = filename;
            LoadImage(filename);
            this.Text = Path.GetFileName(filename);
        }
        public WinImage(Image img)
        {
            InitializeComponent();
            LoadImage(img);
        }

        #region FUNCTION
        public bool LoadImage(string filename)
        {
            if (!File.Exists(filename))
                return false;
            using (FileStream fs = new FileStream(filename, FileMode.Open))
            {
                Byte[] data = new Byte[fs.Length];
                fs.Read(data, 0, data.Length);
                fs.Close();
                using (MemoryStream ms = new MemoryStream(data))
                {
                    pictureBox1.Image = Image.FromStream(ms);
                }
            }
            /*INFORMATION*/
            RefreshInfo();
            return true;
        }
        public void LoadImage(Image img)
        {
            if (img == null)
                return;
            pictureBox1.Image = img;
            /*INFORMATION*/
            RefreshInfo();
        }
        private void RefreshInfo()
        {
            labelSize.Text = String.Format("Size({0},{1})", pictureBox1.Image.Width, pictureBox1.Image.Height);
            labelDpi.Text = string.Format("DPI={0:0}", ((Bitmap)pictureBox1.Image).HorizontalResolution);
        }
        #endregion
    }
}
