﻿namespace VideoInputForm
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuDeive = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuOpenImage = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.processToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuDeskew = new System.Windows.Forms.ToolStripMenuItem();
            this.menuDeskewEnable = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.menuDeskewSetting = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSnapshot = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureVideo = new System.Windows.Forms.PictureBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureVideo)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuDeive,
            this.fileToolStripMenuItem,
            this.processToolStripMenuItem,
            this.menuSnapshot});
            this.menuStrip1.Name = "menuStrip1";
            // 
            // menuDeive
            // 
            resources.ApplyResources(this.menuDeive, "menuDeive");
            this.menuDeive.Name = "menuDeive";
            // 
            // fileToolStripMenuItem
            // 
            resources.ApplyResources(this.fileToolStripMenuItem, "fileToolStripMenuItem");
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuOpenImage,
            this.menuSaveAs});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            // 
            // menuOpenImage
            // 
            resources.ApplyResources(this.menuOpenImage, "menuOpenImage");
            this.menuOpenImage.Name = "menuOpenImage";
            this.menuOpenImage.Click += new System.EventHandler(this.menuOpenImage_Click);
            // 
            // menuSaveAs
            // 
            resources.ApplyResources(this.menuSaveAs, "menuSaveAs");
            this.menuSaveAs.Name = "menuSaveAs";
            this.menuSaveAs.Click += new System.EventHandler(this.menuSaveAs_Click);
            // 
            // processToolStripMenuItem
            // 
            resources.ApplyResources(this.processToolStripMenuItem, "processToolStripMenuItem");
            this.processToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuDeskew});
            this.processToolStripMenuItem.Name = "processToolStripMenuItem";
            // 
            // menuDeskew
            // 
            resources.ApplyResources(this.menuDeskew, "menuDeskew");
            this.menuDeskew.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuDeskewEnable,
            this.toolStripSeparator1,
            this.menuDeskewSetting});
            this.menuDeskew.Name = "menuDeskew";
            // 
            // menuDeskewEnable
            // 
            resources.ApplyResources(this.menuDeskewEnable, "menuDeskewEnable");
            this.menuDeskewEnable.CheckOnClick = true;
            this.menuDeskewEnable.Name = "menuDeskewEnable";
            this.menuDeskewEnable.CheckedChanged += new System.EventHandler(this.menuDeskewEnable_CheckedChanged);
            // 
            // toolStripSeparator1
            // 
            resources.ApplyResources(this.toolStripSeparator1, "toolStripSeparator1");
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            // 
            // menuDeskewSetting
            // 
            resources.ApplyResources(this.menuDeskewSetting, "menuDeskewSetting");
            this.menuDeskewSetting.Name = "menuDeskewSetting";
            this.menuDeskewSetting.Click += new System.EventHandler(this.menuDeskewSetting_Click);
            // 
            // menuSnapshot
            // 
            resources.ApplyResources(this.menuSnapshot, "menuSnapshot");
            this.menuSnapshot.Name = "menuSnapshot";
            this.menuSnapshot.Click += new System.EventHandler(this.menuSnapshot_Click);
            // 
            // pictureVideo
            // 
            resources.ApplyResources(this.pictureVideo, "pictureVideo");
            this.pictureVideo.BackColor = System.Drawing.Color.Transparent;
            this.pictureVideo.Name = "pictureVideo";
            this.pictureVideo.TabStop = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            resources.ApplyResources(this.openFileDialog1, "openFileDialog1");
            // 
            // saveFileDialog1
            // 
            resources.ApplyResources(this.saveFileDialog1, "saveFileDialog1");
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pictureVideo);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureVideo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuDeive;
        private System.Windows.Forms.PictureBox pictureVideo;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuOpenImage;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem processToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuDeskew;
        private System.Windows.Forms.ToolStripMenuItem menuDeskewEnable;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem menuDeskewSetting;
        private System.Windows.Forms.ToolStripMenuItem menuSaveAs;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem menuSnapshot;
    }
}

