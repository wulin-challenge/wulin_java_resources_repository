﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VideoInputForm
{
    public partial class DeskewSettingDialog : Form
    {
        SetDeskewSetting ParameterChanged;
        int[] currentValues;

        public DeskewSettingDialog(SetDeskewSetting settingChanged, int[] values)
        {
            InitializeComponent();
            ParameterChanged = new SetDeskewSetting(settingChanged);
            currentValues = new int[8];
            SetCurrentValues(values);
            barMergeDist.ValueChanged += Deskew_ValueChanged;
            barDownSize.ValueChanged += Deskew_ValueChanged;
            barGaussKernel.ValueChanged += Deskew_ValueChanged;
            barDilateKernel.ValueChanged += Deskew_ValueChanged;
            barReservX.ValueChanged += Deskew_ValueChanged;
            barReservY.ValueChanged += Deskew_ValueChanged;
            barCannyLow.ValueChanged += Deskew_ValueChanged;
            barCannyHigh.ValueChanged += Deskew_ValueChanged;
        }

        private void SetCurrentValues(int[] values)
        {
            barMergeDist.Value = values[0];
            barDownSize.Value = values[1];
            barGaussKernel.Value = values[2];
            barDilateKernel.Value = values[3];
            barReservX.Value = values[4];
            barReservY.Value = values[5];
            barCannyLow.Value = values[6];
            barCannyHigh.Value = values[7];
        }
        private void Deskew_ValueChanged(object sender, EventArgs e)
        {
            ParameterChanged.Invoke(currentValues[0], currentValues[1], currentValues[2], currentValues[3], currentValues[4], currentValues[5], currentValues[6], currentValues[7]);
        }
        private void barMergeDist_ValueChanged(object sender, EventArgs e)
        {
            int value = (sender as TrackBar).Value;
            textMergeDist.Text = value.ToString();
            currentValues[0] = value;
        }
        private void barDownSize_ValueChanged(object sender, EventArgs e)
        {
            int value = (sender as TrackBar).Value;
            textDownSize.Text = value.ToString();
            currentValues[1] = value;
        }
        private void barGaussKernel_ValueChanged(object sender, EventArgs e)
        {
            int value = (sender as TrackBar).Value;
            textGaussKernel.Text = value.ToString();
            currentValues[2] = value;
        }
        private void barDilateKernel_ValueChanged(object sender, EventArgs e)
        {
            int value = (sender as TrackBar).Value;
            textDliateKernel.Text = value.ToString();
            currentValues[3] = value;
        }
        private void barReservX_ValueChanged(object sender, EventArgs e)
        {
            int value = (sender as TrackBar).Value;
            textReservX.Text = value.ToString();
            currentValues[4] = value;
        }
        private void barReservY_ValueChanged(object sender, EventArgs e)
        {
            int value = (sender as TrackBar).Value;
            textReservY.Text = value.ToString();
            currentValues[5] = value;
        }
        private void barCannyLow_ValueChanged(object sender, EventArgs e)
        {
            int value = (sender as TrackBar).Value;
            textCannyLow.Text = value.ToString();
            currentValues[6] = value;
        }
        private void barCannyHigh_ValueChanged(object sender, EventArgs e)
        {
            int value = (sender as TrackBar).Value;
            textCannyHigh.Text = value.ToString();
            currentValues[7] = value;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }
    }
}
