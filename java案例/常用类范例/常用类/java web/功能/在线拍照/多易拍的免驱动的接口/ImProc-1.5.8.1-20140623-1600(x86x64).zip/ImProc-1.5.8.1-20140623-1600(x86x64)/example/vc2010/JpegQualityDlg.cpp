#include "stdafx.h"
#include "ImProc.h"
#include "JpegQualityDlg.h"
#include <VideoInputDLL.h>

IMPLEMENT_DYNAMIC(CJpegQualityDlg, CDialog)
BEGIN_MESSAGE_MAP(CJpegQualityDlg, CDialog)
	ON_WM_HSCROLL()
END_MESSAGE_MAP()

CJpegQualityDlg::CJpegQualityDlg(HANDLE hVideoInput)
	: CDialog(CJpegQualityDlg::IDD, NULL)
{
	m_hVideoInput = hVideoInput;
}

CJpegQualityDlg::~CJpegQualityDlg()
{
}

void CJpegQualityDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

void CJpegQualityDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	CSliderCtrl* pSlider = (CSliderCtrl*)pScrollBar;
	int nNewPos, nMinPos, nMaxPos;

	nNewPos = pSlider->GetPos();
	pSlider->GetRange(nMinPos, nMaxPos);

	if (nSBCode == SB_LINELEFT) /*nNewPos -= 1*/;
	else if (nSBCode == SB_LINERIGHT) /*nNewPos += 1*/;
	else if (nSBCode == SB_PAGELEFT) /*nNewPos += 10*/;
	else if (nSBCode == SB_PAGERIGHT) /*nNewPos -= 10*/;
	else if (nSBCode == SB_LEFT) nNewPos = nMinPos;
	else if (nSBCode == SB_RIGHT) nNewPos = nMaxPos;
	else if (nSBCode == SB_THUMBPOSITION) nNewPos = nPos;
	else if (nSBCode == SB_THUMBTRACK) nNewPos = nPos;

	nNewPos = min(max(nNewPos, nMinPos), nMaxPos);
	//pSlider->SetPos(nNewPos);

	if (pSlider == GetDlgItem(IDC_JPEG_QUALITY))
	{
		float nJpegQuality = nNewPos * 0.01f;
		CStringW szJpegQuality;
		IP::SetJpegQuality(m_hVideoInput, nJpegQuality);
		szJpegQuality.Format(L"%.2f", nJpegQuality);
		SetDlgItemTextW(TXT_JPEG_QUALITY, szJpegQuality);
	}

	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

BOOL CJpegQualityDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	CSliderCtrl* pJpegQuality;
	CStringW szJpegQuality;
	float nJpegQuality;

	pJpegQuality = (CSliderCtrl*)GetDlgItem(IDC_JPEG_QUALITY);
	nJpegQuality = IP::GetJpegQuality(m_hVideoInput);

	szJpegQuality.Format(L"%.2f", nJpegQuality);
	pJpegQuality->SetRange(0, 100);
	pJpegQuality->SetPos((int)(nJpegQuality * 100 + 0.5f));
	SetDlgItemTextW(TXT_JPEG_QUALITY, szJpegQuality);

	return TRUE;
}
