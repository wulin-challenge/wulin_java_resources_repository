﻿namespace VideoInputForm
{
    partial class DeskewSettingDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.barCannyHigh = new System.Windows.Forms.TrackBar();
            this.barCannyLow = new System.Windows.Forms.TrackBar();
            this.barReservY = new System.Windows.Forms.TrackBar();
            this.barReservX = new System.Windows.Forms.TrackBar();
            this.barDilateKernel = new System.Windows.Forms.TrackBar();
            this.barGaussKernel = new System.Windows.Forms.TrackBar();
            this.barDownSize = new System.Windows.Forms.TrackBar();
            this.textCannyHigh = new System.Windows.Forms.TextBox();
            this.textCannyLow = new System.Windows.Forms.TextBox();
            this.textReservY = new System.Windows.Forms.TextBox();
            this.textReservX = new System.Windows.Forms.TextBox();
            this.textDliateKernel = new System.Windows.Forms.TextBox();
            this.textGaussKernel = new System.Windows.Forms.TextBox();
            this.textDownSize = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.barMergeDist = new System.Windows.Forms.TrackBar();
            this.textMergeDist = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.barCannyHigh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barCannyLow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barReservY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barReservX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barDilateKernel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barGaussKernel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barDownSize)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.barMergeDist)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.barCannyHigh, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.barCannyLow, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.barReservY, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.barReservX, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.barDilateKernel, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.barGaussKernel, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.barDownSize, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.textCannyHigh, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.textCannyLow, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.textReservY, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.textReservX, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.textDliateKernel, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.textGaussKernel, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.textDownSize, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label6, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel1, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.barMergeDist, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.textMergeDist, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 9;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(466, 340);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // barCannyHigh
            // 
            this.barCannyHigh.AutoSize = false;
            this.barCannyHigh.Dock = System.Windows.Forms.DockStyle.Top;
            this.barCannyHigh.Location = new System.Drawing.Point(94, 250);
            this.barCannyHigh.Margin = new System.Windows.Forms.Padding(5);
            this.barCannyHigh.Maximum = 255;
            this.barCannyHigh.Name = "barCannyHigh";
            this.barCannyHigh.Size = new System.Drawing.Size(300, 25);
            this.barCannyHigh.TabIndex = 24;
            this.barCannyHigh.TickStyle = System.Windows.Forms.TickStyle.None;
            this.barCannyHigh.ValueChanged += new System.EventHandler(this.barCannyHigh_ValueChanged);
            // 
            // barCannyLow
            // 
            this.barCannyLow.AutoSize = false;
            this.barCannyLow.Dock = System.Windows.Forms.DockStyle.Top;
            this.barCannyLow.Location = new System.Drawing.Point(94, 215);
            this.barCannyLow.Margin = new System.Windows.Forms.Padding(5);
            this.barCannyLow.Maximum = 255;
            this.barCannyLow.Name = "barCannyLow";
            this.barCannyLow.Size = new System.Drawing.Size(300, 25);
            this.barCannyLow.TabIndex = 23;
            this.barCannyLow.TickStyle = System.Windows.Forms.TickStyle.None;
            this.barCannyLow.ValueChanged += new System.EventHandler(this.barCannyLow_ValueChanged);
            // 
            // barReservY
            // 
            this.barReservY.AutoSize = false;
            this.barReservY.Dock = System.Windows.Forms.DockStyle.Top;
            this.barReservY.Location = new System.Drawing.Point(94, 180);
            this.barReservY.Margin = new System.Windows.Forms.Padding(5);
            this.barReservY.Maximum = 100;
            this.barReservY.Name = "barReservY";
            this.barReservY.Size = new System.Drawing.Size(300, 25);
            this.barReservY.TabIndex = 22;
            this.barReservY.TickStyle = System.Windows.Forms.TickStyle.None;
            this.barReservY.ValueChanged += new System.EventHandler(this.barReservY_ValueChanged);
            // 
            // barReservX
            // 
            this.barReservX.AutoSize = false;
            this.barReservX.Dock = System.Windows.Forms.DockStyle.Top;
            this.barReservX.Location = new System.Drawing.Point(94, 145);
            this.barReservX.Margin = new System.Windows.Forms.Padding(5);
            this.barReservX.Maximum = 100;
            this.barReservX.Name = "barReservX";
            this.barReservX.Size = new System.Drawing.Size(300, 25);
            this.barReservX.TabIndex = 21;
            this.barReservX.TickStyle = System.Windows.Forms.TickStyle.None;
            this.barReservX.ValueChanged += new System.EventHandler(this.barReservX_ValueChanged);
            // 
            // barDilateKernel
            // 
            this.barDilateKernel.AutoSize = false;
            this.barDilateKernel.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDilateKernel.Location = new System.Drawing.Point(94, 110);
            this.barDilateKernel.Margin = new System.Windows.Forms.Padding(5);
            this.barDilateKernel.Name = "barDilateKernel";
            this.barDilateKernel.Size = new System.Drawing.Size(300, 25);
            this.barDilateKernel.TabIndex = 20;
            this.barDilateKernel.TickStyle = System.Windows.Forms.TickStyle.None;
            this.barDilateKernel.ValueChanged += new System.EventHandler(this.barDilateKernel_ValueChanged);
            // 
            // barGaussKernel
            // 
            this.barGaussKernel.AutoSize = false;
            this.barGaussKernel.Dock = System.Windows.Forms.DockStyle.Top;
            this.barGaussKernel.Location = new System.Drawing.Point(94, 75);
            this.barGaussKernel.Margin = new System.Windows.Forms.Padding(5);
            this.barGaussKernel.Name = "barGaussKernel";
            this.barGaussKernel.Size = new System.Drawing.Size(300, 25);
            this.barGaussKernel.TabIndex = 19;
            this.barGaussKernel.TickStyle = System.Windows.Forms.TickStyle.None;
            this.barGaussKernel.ValueChanged += new System.EventHandler(this.barGaussKernel_ValueChanged);
            // 
            // barDownSize
            // 
            this.barDownSize.AutoSize = false;
            this.barDownSize.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDownSize.Location = new System.Drawing.Point(94, 40);
            this.barDownSize.Margin = new System.Windows.Forms.Padding(5);
            this.barDownSize.Name = "barDownSize";
            this.barDownSize.Size = new System.Drawing.Size(300, 25);
            this.barDownSize.TabIndex = 18;
            this.barDownSize.TickStyle = System.Windows.Forms.TickStyle.None;
            this.barDownSize.ValueChanged += new System.EventHandler(this.barDownSize_ValueChanged);
            // 
            // textCannyHigh
            // 
            this.textCannyHigh.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textCannyHigh.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textCannyHigh.Location = new System.Drawing.Point(404, 250);
            this.textCannyHigh.Margin = new System.Windows.Forms.Padding(5);
            this.textCannyHigh.Name = "textCannyHigh";
            this.textCannyHigh.ReadOnly = true;
            this.textCannyHigh.Size = new System.Drawing.Size(57, 22);
            this.textCannyHigh.TabIndex = 17;
            this.textCannyHigh.Text = "0";
            this.textCannyHigh.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textCannyLow
            // 
            this.textCannyLow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textCannyLow.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textCannyLow.Location = new System.Drawing.Point(404, 215);
            this.textCannyLow.Margin = new System.Windows.Forms.Padding(5);
            this.textCannyLow.Name = "textCannyLow";
            this.textCannyLow.ReadOnly = true;
            this.textCannyLow.Size = new System.Drawing.Size(57, 22);
            this.textCannyLow.TabIndex = 16;
            this.textCannyLow.Text = "0";
            this.textCannyLow.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textReservY
            // 
            this.textReservY.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textReservY.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textReservY.Location = new System.Drawing.Point(404, 180);
            this.textReservY.Margin = new System.Windows.Forms.Padding(5);
            this.textReservY.Name = "textReservY";
            this.textReservY.ReadOnly = true;
            this.textReservY.Size = new System.Drawing.Size(57, 22);
            this.textReservY.TabIndex = 15;
            this.textReservY.Text = "0";
            this.textReservY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textReservX
            // 
            this.textReservX.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textReservX.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textReservX.Location = new System.Drawing.Point(404, 145);
            this.textReservX.Margin = new System.Windows.Forms.Padding(5);
            this.textReservX.Name = "textReservX";
            this.textReservX.ReadOnly = true;
            this.textReservX.Size = new System.Drawing.Size(57, 22);
            this.textReservX.TabIndex = 14;
            this.textReservX.Text = "0";
            this.textReservX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textDliateKernel
            // 
            this.textDliateKernel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textDliateKernel.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textDliateKernel.Location = new System.Drawing.Point(404, 110);
            this.textDliateKernel.Margin = new System.Windows.Forms.Padding(5);
            this.textDliateKernel.Name = "textDliateKernel";
            this.textDliateKernel.ReadOnly = true;
            this.textDliateKernel.Size = new System.Drawing.Size(57, 22);
            this.textDliateKernel.TabIndex = 13;
            this.textDliateKernel.Text = "0";
            this.textDliateKernel.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textGaussKernel
            // 
            this.textGaussKernel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textGaussKernel.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textGaussKernel.Location = new System.Drawing.Point(404, 75);
            this.textGaussKernel.Margin = new System.Windows.Forms.Padding(5);
            this.textGaussKernel.Name = "textGaussKernel";
            this.textGaussKernel.ReadOnly = true;
            this.textGaussKernel.Size = new System.Drawing.Size(57, 22);
            this.textGaussKernel.TabIndex = 12;
            this.textGaussKernel.Text = "0";
            this.textGaussKernel.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textDownSize
            // 
            this.textDownSize.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textDownSize.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textDownSize.Location = new System.Drawing.Point(404, 40);
            this.textDownSize.Margin = new System.Windows.Forms.Padding(5);
            this.textDownSize.Name = "textDownSize";
            this.textDownSize.ReadOnly = true;
            this.textDownSize.Size = new System.Drawing.Size(57, 22);
            this.textDownSize.TabIndex = 11;
            this.textDownSize.Text = "0";
            this.textDownSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(5, 250);
            this.label8.Margin = new System.Windows.Forms.Padding(5);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 25);
            this.label8.TabIndex = 7;
            this.label8.Text = "CannyHigh:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(5, 215);
            this.label7.Margin = new System.Windows.Forms.Padding(5);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 25);
            this.label7.TabIndex = 6;
            this.label7.Text = "CannyLow:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(5, 180);
            this.label6.Margin = new System.Windows.Forms.Padding(5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "ReservY:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(5, 110);
            this.label5.Margin = new System.Windows.Forms.Padding(5);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "DilateKernel:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(5, 145);
            this.label4.Margin = new System.Windows.Forms.Padding(5);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "ReservX:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(5, 75);
            this.label3.Margin = new System.Windows.Forms.Padding(5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "GaussKernel:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(5, 40);
            this.label2.Margin = new System.Windows.Forms.Padding(5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "DownSize:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(5, 5);
            this.label1.Margin = new System.Windows.Forms.Padding(5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "MergeDist:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.flowLayoutPanel1, 3);
            this.flowLayoutPanel1.Controls.Add(this.btnCancel);
            this.flowLayoutPanel1.Controls.Add(this.btnOK);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(301, 301);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.flowLayoutPanel1.Size = new System.Drawing.Size(162, 36);
            this.flowLayoutPanel1.TabIndex = 8;
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(84, 10);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "CANCEL";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOK
            // 
            this.btnOK.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOK.Location = new System.Drawing.Point(3, 10);
            this.btnOK.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 0;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // barMergeDist
            // 
            this.barMergeDist.AutoSize = false;
            this.barMergeDist.Dock = System.Windows.Forms.DockStyle.Top;
            this.barMergeDist.Location = new System.Drawing.Point(94, 5);
            this.barMergeDist.Margin = new System.Windows.Forms.Padding(5);
            this.barMergeDist.Maximum = 1000;
            this.barMergeDist.Name = "barMergeDist";
            this.barMergeDist.Size = new System.Drawing.Size(300, 25);
            this.barMergeDist.TabIndex = 9;
            this.barMergeDist.TickStyle = System.Windows.Forms.TickStyle.None;
            this.barMergeDist.ValueChanged += new System.EventHandler(this.barMergeDist_ValueChanged);
            // 
            // textMergeDist
            // 
            this.textMergeDist.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textMergeDist.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textMergeDist.Location = new System.Drawing.Point(404, 5);
            this.textMergeDist.Margin = new System.Windows.Forms.Padding(5);
            this.textMergeDist.Name = "textMergeDist";
            this.textMergeDist.ReadOnly = true;
            this.textMergeDist.Size = new System.Drawing.Size(57, 22);
            this.textMergeDist.TabIndex = 10;
            this.textMergeDist.Text = "0";
            this.textMergeDist.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // DeskewSettingDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 340);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "DeskewSettingDialog";
            this.Text = "DESKEW SETTING";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.barCannyHigh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barCannyLow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barReservY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barReservX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barDilateKernel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barGaussKernel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barDownSize)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.barMergeDist)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox textCannyHigh;
        private System.Windows.Forms.TextBox textCannyLow;
        private System.Windows.Forms.TextBox textReservY;
        private System.Windows.Forms.TextBox textReservX;
        private System.Windows.Forms.TextBox textDliateKernel;
        private System.Windows.Forms.TextBox textGaussKernel;
        private System.Windows.Forms.TextBox textDownSize;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.TrackBar barMergeDist;
        private System.Windows.Forms.TextBox textMergeDist;
        private System.Windows.Forms.TrackBar barCannyHigh;
        private System.Windows.Forms.TrackBar barCannyLow;
        private System.Windows.Forms.TrackBar barReservY;
        private System.Windows.Forms.TrackBar barReservX;
        private System.Windows.Forms.TrackBar barDilateKernel;
        private System.Windows.Forms.TrackBar barGaussKernel;
        private System.Windows.Forms.TrackBar barDownSize;
    }
}