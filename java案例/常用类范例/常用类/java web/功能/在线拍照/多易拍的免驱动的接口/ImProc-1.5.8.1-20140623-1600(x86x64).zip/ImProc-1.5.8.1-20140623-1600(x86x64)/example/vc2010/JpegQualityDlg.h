#pragma once

class CJpegQualityDlg : public CDialog
{
	DECLARE_DYNAMIC(CJpegQualityDlg)
	DECLARE_MESSAGE_MAP()
public:
	CJpegQualityDlg(HANDLE hVideoInput);
	virtual ~CJpegQualityDlg();
	enum { IDD = IDD_JPEG_QUALITY };
protected:
	HANDLE m_hVideoInput;

	virtual void DoDataExchange(CDataExchange* pDX);
	virtual void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
public:
	virtual BOOL OnInitDialog();
};
