#include "stdafx.h"
#include "ImProc.h"
#include "AutoGrabDlg.h"

IMPLEMENT_DYNAMIC(CAutoGrabDlg, CDialog)
BEGIN_MESSAGE_MAP(CAutoGrabDlg, CDialog)
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDOK, &CAutoGrabDlg::OnBnClickedOk)
	ON_BN_CLICKED(BTN_AUTOGRAB_PREFIX, &CAutoGrabDlg::OnBnClickedAutograbPrefix)
END_MESSAGE_MAP()

CAutoGrabDlg::CAutoGrabDlg(int* pLow, int* pHigh, int* pTime,
						   LPWSTR szPrefix, LPWSTR szExt, int nMaxSize)
	: CDialog(CAutoGrabDlg::IDD, NULL)
{
	m_pLow = pLow;
	m_pHigh = pHigh;
	m_pTime = pTime;
	m_szPrefix = szPrefix;
	m_szExt = szExt;
	m_nMaxSize = nMaxSize;
}

CAutoGrabDlg::~CAutoGrabDlg()
{
}

void CAutoGrabDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BOOL CAutoGrabDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	CSliderCtrl* pLow, *pHigh, *pTime;
	CEdit* xLow, *xHigh, *xTime, *xPrefix, *xExt;
	CString szText;

	pLow = (CSliderCtrl*)GetDlgItem(IDC_AUTOGRAB_LOW);
	pHigh = (CSliderCtrl*)GetDlgItem(IDC_AUTOGRAB_HIGH);
	pTime = (CSliderCtrl*)GetDlgItem(IDC_AUTOGRAB_TIME);

	xLow = (CEdit*)GetDlgItem(TXT_AUTOGRAB_LOW);
	xHigh = (CEdit*)GetDlgItem(TXT_AUTOGRAB_HIGH);
	xTime = (CEdit*)GetDlgItem(TXT_AUTOGRAB_TIME);
	xPrefix = (CEdit*)GetDlgItem(IDC_AUTOGRAB_PREFIX);
	xExt = (CEdit*)GetDlgItem(IDC_AUTOGRAB_EXT);

	pLow->SetRange(0, 255);
	pHigh->SetRange(0, 255);
	pTime->SetRange(0, 10000);

	pLow->SetPos(*m_pLow);
	pHigh->SetPos(*m_pHigh);
	pTime->SetPos(*m_pTime);

	szText.Format(TEXT("%d"), *m_pLow); xLow->SetWindowText(szText);
	szText.Format(TEXT("%d"), *m_pHigh); xHigh->SetWindowText(szText);
	szText.Format(TEXT("%d"), *m_pTime); xTime->SetWindowText(szText);
	xPrefix->SetWindowText(m_szPrefix);
	xExt->SetWindowText(m_szExt);

	return TRUE;
}

void CAutoGrabDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	CSliderCtrl* pSlider = (CSliderCtrl*)pScrollBar;
	CSliderCtrl* pLow, *pHigh, *pTime;
	CEdit* xLow, *xHigh, *xTime;
	CString szText;
	int nNewPos, nMinPos, nMaxPos;

	pLow = (CSliderCtrl*)GetDlgItem(IDC_AUTOGRAB_LOW);
	pHigh = (CSliderCtrl*)GetDlgItem(IDC_AUTOGRAB_HIGH);
	pTime = (CSliderCtrl*)GetDlgItem(IDC_AUTOGRAB_TIME);

	xLow = (CEdit*)GetDlgItem(TXT_AUTOGRAB_LOW);
	xHigh = (CEdit*)GetDlgItem(TXT_AUTOGRAB_HIGH);
	xTime = (CEdit*)GetDlgItem(TXT_AUTOGRAB_TIME);

	nNewPos = pSlider->GetPos();
	pSlider->GetRange(nMinPos, nMaxPos);

	if (nSBCode == SB_LINELEFT) /*nNewPos -= 1*/;
	else if (nSBCode == SB_LINERIGHT) /*nNewPos += 1*/;
	else if (nSBCode == SB_PAGELEFT) /*nNewPos += 10*/;
	else if (nSBCode == SB_PAGERIGHT) /*nNewPos -= 10*/;
	else if (nSBCode == SB_LEFT) nNewPos = nMinPos;
	else if (nSBCode == SB_RIGHT) nNewPos = nMaxPos;
	else if (nSBCode == SB_THUMBPOSITION) nNewPos = nPos;
	else if (nSBCode == SB_THUMBTRACK) nNewPos = nPos;

	nNewPos = min(max(nNewPos, nMinPos), nMaxPos);
	szText.Format(TEXT("%d"), nNewPos);

	if (pSlider == pLow) xLow->SetWindowText(szText);
	else if (pSlider == pHigh) xHigh->SetWindowText(szText);
	else if (pSlider == pTime) xTime->SetWindowText(szText);

	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CAutoGrabDlg::OnBnClickedOk()
{
	CSliderCtrl* pLow, *pHigh, *pTime;
	CEdit* xPrefix, *xExt;

	pLow = (CSliderCtrl*)GetDlgItem(IDC_AUTOGRAB_LOW);
	pHigh = (CSliderCtrl*)GetDlgItem(IDC_AUTOGRAB_HIGH);
	pTime = (CSliderCtrl*)GetDlgItem(IDC_AUTOGRAB_TIME);
	xPrefix = (CEdit*)GetDlgItem(IDC_AUTOGRAB_PREFIX);
	xExt = (CEdit*)GetDlgItem(IDC_AUTOGRAB_EXT);

	*m_pLow = pLow->GetPos();
	*m_pHigh = pHigh->GetPos();
	*m_pTime = pTime->GetPos();
	xPrefix->GetWindowTextW(m_szPrefix, m_nMaxSize);
	xExt->GetWindowTextW(m_szExt, m_nMaxSize);

	CDialog::OnOK();
}

void CAutoGrabDlg::OnBnClickedAutograbPrefix()
{
	ITEMIDLIST* pIDL;
	WCHAR buffer[1024];
	BROWSEINFOW bi;

	pIDL = NULL;
	memset(&bi, 0, sizeof(bi));
	memset(buffer, 0, sizeof(buffer));

	bi.ulFlags   = BIF_USENEWUI;
	bi.hwndOwner = GetSafeHwnd();

	::OleInitialize(NULL);

	pIDL = ::SHBrowseForFolderW(&bi);

	if (pIDL)
	{
		if (::SHGetPathFromIDListW(pIDL, buffer) != 0)
		{
			if (buffer[wcslen(buffer) - 1] != L'\\')
				wcscat_s(buffer, L"\\");
			SetDlgItemTextW(IDC_AUTOGRAB_PREFIX, buffer);
		}

		CoTaskMemFree(pIDL);
	}

	::OleUninitialize();
}
