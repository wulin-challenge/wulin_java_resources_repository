#include "stdafx.h"
#include "ImProc.h"
#include "DeskewDlg.h"
#include <VideoInputDLL.h>

IMPLEMENT_DYNAMIC(CDeskewDlg, CDialog);
BEGIN_MESSAGE_MAP(CDeskewDlg, CDialog)
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDOK, &CDeskewDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDC_DESKEW_ROTATE_ONLY, &CDeskewDlg::OnBnClickedDeskewRotateOnly)
	ON_BN_CLICKED(IDC_DESKEW_BLACK_PAD, &CDeskewDlg::OnBnClickedDeskewBlackPad)
	ON_BN_CLICKED(IDC_DESKEW_WHITE_PAD, &CDeskewDlg::OnBnClickedDeskewWhitePad)
END_MESSAGE_MAP()

CDeskewDlg::CDeskewDlg(HANDLE hVideoInput)
	: CDialog(CDeskewDlg::IDD, NULL)
{
	m_hVideoInput = hVideoInput;
}

CDeskewDlg::~CDeskewDlg()
{
}

void CDeskewDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BOOL CDeskewDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	int nMergeDist, nDownSize, nGaussKernel, nDilateKernel;
	int nReservX, nReservY, nCannyLow, nCannyHigh;
	CSliderCtrl* pMergeDist, *pDownSize, *pGaussKernel, *pDilateKernel;
	CSliderCtrl* pReservX, *pReservY, *pCannyLow, *pCannyHigh;
	CEdit* xMergeDist, *xDownSize, *xGaussKernel, *xDilateKernel;
	CEdit* xReservX, *xReservY, *xCannyLow, *xCannyHigh;
	CString szText;
	size_t nDeviceIndex;

	nDeviceIndex = IP::GetDeviceIndex(m_hVideoInput);
	if (IP::IsImageFilePlaying(m_hVideoInput))
	{
		IP::GetImageFileDeskewSetting(
			m_hVideoInput, &nMergeDist, &nDownSize,
			&nGaussKernel, &nDilateKernel, &nReservX, &nReservY,
			&nCannyLow, &nCannyHigh);
	}
	else if (IP::IsDevicePlaying(m_hVideoInput, nDeviceIndex))
	{
		IP::GetDeviceDeskewSetting(
			m_hVideoInput, nDeviceIndex, &nMergeDist, &nDownSize,
			&nGaussKernel, &nDilateKernel, &nReservX, &nReservY,
			&nCannyLow, &nCannyHigh);
	}

	pMergeDist = (CSliderCtrl*)GetDlgItem(IDC_DESKEW_MERGE_DIST);
	pDownSize = (CSliderCtrl*)GetDlgItem(IDC_DESKEW_DOWN_SIZE);
	pGaussKernel = (CSliderCtrl*)GetDlgItem(IDC_DESKEW_GAUSS_KERNEL);
	pDilateKernel = (CSliderCtrl*)GetDlgItem(IDC_DESKEW_DILATE_KERNEL);
	pReservX = (CSliderCtrl*)GetDlgItem(IDC_DESKEW_RESERV_X);
	pReservY = (CSliderCtrl*)GetDlgItem(IDC_DESKEW_RESERV_Y);
	pCannyLow = (CSliderCtrl*)GetDlgItem(IDC_DESKEW_CANNY_LOW);
	pCannyHigh = (CSliderCtrl*)GetDlgItem(IDC_DESKEW_CANNY_HIGH);

	xMergeDist = (CEdit*)GetDlgItem(TXT_DESKEW_MERGE_DIST);
	xDownSize = (CEdit*)GetDlgItem(TXT_DESKEW_DOWN_SIZE);
	xGaussKernel = (CEdit*)GetDlgItem(TXT_DESKEW_GAUSS_KERNEL);
	xDilateKernel = (CEdit*)GetDlgItem(TXT_DESKEW_DILATE_KERNEL);
	xReservX = (CEdit*)GetDlgItem(TXT_DESKEW_RESERV_X);
	xReservY = (CEdit*)GetDlgItem(TXT_DESKEW_RESERV_Y);
	xCannyLow = (CEdit*)GetDlgItem(TXT_DESKEW_CANNY_LOW);
	xCannyHigh = (CEdit*)GetDlgItem(TXT_DESKEW_CANNY_HIGH);

	pMergeDist->SetRange(0, 1000);
	pDownSize->SetRange(0, 10);
	pGaussKernel->SetRange(0, 10);
	pDilateKernel->SetRange(0, 10);
	pReservX->SetRange(0, 100);
	pReservY->SetRange(0, 100);
	pCannyLow->SetRange(0, 255);
	pCannyHigh->SetRange(0, 255);

	pMergeDist->SetPos(nMergeDist);
	pDownSize->SetPos(nDownSize);
	pGaussKernel->SetPos(nGaussKernel);
	pDilateKernel->SetPos(nDilateKernel);
	pReservX->SetPos(nReservX);
	pReservY->SetPos(nReservY);
	pCannyLow->SetPos(nCannyLow);
	pCannyHigh->SetPos(nCannyHigh);

	szText.Format(TEXT("%d"), nMergeDist); xMergeDist->SetWindowText(szText);
	szText.Format(TEXT("%d"), nDownSize); xDownSize->SetWindowText(szText);
	szText.Format(TEXT("%d"), nGaussKernel); xGaussKernel->SetWindowText(szText);
	szText.Format(TEXT("%d"), nDilateKernel); xDilateKernel->SetWindowText(szText);
	szText.Format(TEXT("%d"), nReservX); xReservX->SetWindowText(szText);
	szText.Format(TEXT("%d"), nReservY); xReservY->SetWindowText(szText);
	szText.Format(TEXT("%d"), nCannyLow); xCannyLow->SetWindowText(szText);
	szText.Format(TEXT("%d"), nCannyHigh); xCannyHigh->SetWindowText(szText);

	if (nReservX < 0 && nReservY < 0)
	{
		((CButton*)GetDlgItem(IDC_DESKEW_ROTATE_ONLY))->SetCheck(TRUE);
		OnBnClickedDeskewRotateOnly();
	}

	if (nCannyLow == 0 && nCannyHigh == 0)
	{
		((CButton*)GetDlgItem(IDC_DESKEW_BLACK_PAD))->SetCheck(TRUE);
		OnBnClickedDeskewBlackPad();
	}
	else if (nCannyLow == 50 && nCannyHigh == 200)
	{
		((CButton*)GetDlgItem(IDC_DESKEW_WHITE_PAD))->SetCheck(TRUE);
		OnBnClickedDeskewWhitePad();
	}

	return TRUE;
}

void CDeskewDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	int nMergeDist, nDownSize, nGaussKernel, nDilateKernel;
	int nReservX, nReservY, nCannyLow, nCannyHigh;
	int nNewPos, nMinPos, nMaxPos;
	CSliderCtrl* pMergeDist, *pDownSize, *pGaussKernel, *pDilateKernel;
	CSliderCtrl* pReservX, *pReservY, *pCannyLow, *pCannyHigh;
	CSliderCtrl* pSlider;
	CEdit* xMergeDist, *xDownSize, *xGaussKernel, *xDilateKernel;
	CEdit* xReservX, *xReservY, *xCannyLow, *xCannyHigh;
	CString szText;
	size_t nDeviceIndex;

	nDeviceIndex = IP::GetDeviceIndex(m_hVideoInput);
	if (IP::IsImageFilePlaying(m_hVideoInput))
	{
		IP::GetImageFileDeskewSetting(
			m_hVideoInput, &nMergeDist, &nDownSize,
			&nGaussKernel, &nDilateKernel, &nReservX, &nReservY,
			&nCannyLow, &nCannyHigh);
	}
	else if (IP::IsDevicePlaying(m_hVideoInput, nDeviceIndex))
	{
		IP::GetDeviceDeskewSetting(
			m_hVideoInput, nDeviceIndex, &nMergeDist, &nDownSize,
			&nGaussKernel, &nDilateKernel, &nReservX, &nReservY,
			&nCannyLow, &nCannyHigh);
	}

	pMergeDist = (CSliderCtrl*)GetDlgItem(IDC_DESKEW_MERGE_DIST);
	pDownSize = (CSliderCtrl*)GetDlgItem(IDC_DESKEW_DOWN_SIZE);
	pGaussKernel = (CSliderCtrl*)GetDlgItem(IDC_DESKEW_GAUSS_KERNEL);
	pDilateKernel = (CSliderCtrl*)GetDlgItem(IDC_DESKEW_DILATE_KERNEL);
	pReservX = (CSliderCtrl*)GetDlgItem(IDC_DESKEW_RESERV_X);
	pReservY = (CSliderCtrl*)GetDlgItem(IDC_DESKEW_RESERV_Y);
	pCannyLow = (CSliderCtrl*)GetDlgItem(IDC_DESKEW_CANNY_LOW);
	pCannyHigh = (CSliderCtrl*)GetDlgItem(IDC_DESKEW_CANNY_HIGH);

	xMergeDist = (CEdit*)GetDlgItem(TXT_DESKEW_MERGE_DIST);
	xDownSize = (CEdit*)GetDlgItem(TXT_DESKEW_DOWN_SIZE);
	xGaussKernel = (CEdit*)GetDlgItem(TXT_DESKEW_GAUSS_KERNEL);
	xDilateKernel = (CEdit*)GetDlgItem(TXT_DESKEW_DILATE_KERNEL);
	xReservX = (CEdit*)GetDlgItem(TXT_DESKEW_RESERV_X);
	xReservY = (CEdit*)GetDlgItem(TXT_DESKEW_RESERV_Y);
	xCannyLow = (CEdit*)GetDlgItem(TXT_DESKEW_CANNY_LOW);
	xCannyHigh = (CEdit*)GetDlgItem(TXT_DESKEW_CANNY_HIGH);

	pSlider = (CSliderCtrl*)pScrollBar;
	nNewPos = pSlider->GetPos();
	pSlider->GetRange(nMinPos, nMaxPos);

	if (nSBCode == SB_LINELEFT) /*nNewPos -= 1*/;
	else if (nSBCode == SB_LINERIGHT) /*nNewPos += 1*/;
	else if (nSBCode == SB_PAGELEFT) /*nNewPos += 10*/;
	else if (nSBCode == SB_PAGERIGHT) /*nNewPos -= 10*/;
	else if (nSBCode == SB_LEFT) nNewPos = nMinPos;
	else if (nSBCode == SB_RIGHT) nNewPos = nMaxPos;
	else if (nSBCode == SB_THUMBPOSITION) nNewPos = nPos;
	else if (nSBCode == SB_THUMBTRACK) nNewPos = nPos;

	nNewPos = min(max(nNewPos, nMinPos), nMaxPos);
	szText.Format(TEXT("%d"), nNewPos);

	if (pSlider == pMergeDist)
	{
		nMergeDist = nNewPos;
		xMergeDist->SetWindowText(szText);
	}
	else if (pSlider == pDownSize)
	{
		nDownSize = nNewPos;
		xDownSize->SetWindowText(szText);
	}
	else if (pSlider == pGaussKernel)
	{
		nGaussKernel = nNewPos;
		xGaussKernel->SetWindowText(szText);
	}
	else if (pSlider == pDilateKernel)
	{
		nDilateKernel = nNewPos;
		xDilateKernel->SetWindowText(szText);
	}
	else if (pSlider == pReservX)
	{
		nReservX = nNewPos;
		xReservX->SetWindowText(szText);
	}
	else if (pSlider == pReservY)
	{
		nReservY = nNewPos;
		xReservY->SetWindowText(szText);
	}
	else if (pSlider == pCannyLow)
	{
		nCannyLow = nNewPos;
		xCannyLow->SetWindowText(szText);
	}
	else if (pSlider == pCannyHigh)
	{
		nCannyHigh = nNewPos;
		xCannyHigh->SetWindowText(szText);
	}

	if (IP::IsImageFilePlaying(m_hVideoInput))
	{
		IP::SetImageFileDeskewSetting(
			m_hVideoInput, nMergeDist, nDownSize,
			nGaussKernel, nDilateKernel, nReservX, nReservY,
			nCannyLow, nCannyHigh);
	}
	else if (IP::IsDevicePlaying(m_hVideoInput, nDeviceIndex))
	{
		IP::SetDeviceDeskewSetting(
			m_hVideoInput, nDeviceIndex, nMergeDist, nDownSize,
			nGaussKernel, nDilateKernel, nReservX, nReservY,
			nCannyLow, nCannyHigh);
	}

	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CDeskewDlg::OnBnClickedOk()
{

	CDialog::OnOK();
}

void CDeskewDlg::OnBnClickedDeskewRotateOnly()
{
	size_t nDeviceIndex = IP::GetDeviceIndex(m_hVideoInput);
	int check = ((CButton*)GetDlgItem(IDC_DESKEW_ROTATE_ONLY))->GetCheck();
	int valueX = ((CSliderCtrl*)GetDlgItem(IDC_DESKEW_RESERV_X))->GetPos();
	int valueY = ((CSliderCtrl*)GetDlgItem(IDC_DESKEW_RESERV_Y))->GetPos();
	int nMergeDist, nDownSize, nGaussKernel, nDilateKernel;
	int nReservX, nReservY, nCannyLow, nCannyHigh;

	if (IP::IsImageFilePlaying(m_hVideoInput))
	{
		IP::GetImageFileDeskewSetting(
			m_hVideoInput, &nMergeDist, &nDownSize,
			&nGaussKernel, &nDilateKernel, &nReservX, &nReservY,
			&nCannyLow, &nCannyHigh);
	}
	else if (IP::IsDevicePlaying(m_hVideoInput, nDeviceIndex))
	{
		IP::GetDeviceDeskewSetting(
			m_hVideoInput, nDeviceIndex, &nMergeDist, &nDownSize,
			&nGaussKernel, &nDilateKernel, &nReservX, &nReservY,
			&nCannyLow, &nCannyHigh);
	}

	if (check != 0)
	{
		GetDlgItem(IDC_DESKEW_RESERV_X)->EnableWindow(FALSE);
		GetDlgItem(IDC_DESKEW_RESERV_Y)->EnableWindow(FALSE);

		if (IP::IsImageFilePlaying(m_hVideoInput))
		{
			IP::SetImageFileDeskewSetting(
				m_hVideoInput, nMergeDist, nDownSize,
				nGaussKernel, nDilateKernel, -1, -1,
				nCannyLow, nCannyHigh);
		}
		else if (IP::IsDevicePlaying(m_hVideoInput, nDeviceIndex))
		{
			IP::SetDeviceDeskewSetting(
				m_hVideoInput, nDeviceIndex, nMergeDist, nDownSize,
				nGaussKernel, nDilateKernel, -1, -1,
				nCannyLow, nCannyHigh);
		}
	}
	else
	{
		if (IP::IsImageFilePlaying(m_hVideoInput))
		{
			IP::SetImageFileDeskewSetting(
				m_hVideoInput, nMergeDist, nDownSize,
				nGaussKernel, nDilateKernel, valueX, valueY,
				nCannyLow, nCannyHigh);
		}
		else if (IP::IsDevicePlaying(m_hVideoInput, nDeviceIndex))
		{
			IP::SetDeviceDeskewSetting(
				m_hVideoInput, nDeviceIndex, nMergeDist, nDownSize,
				nGaussKernel, nDilateKernel, valueX, valueY,
				nCannyLow, nCannyHigh);
		}

		GetDlgItem(IDC_DESKEW_RESERV_X)->EnableWindow(TRUE);
		GetDlgItem(IDC_DESKEW_RESERV_Y)->EnableWindow(TRUE);
	}
}

void CDeskewDlg::OnBnClickedDeskewBlackPad()
{
	size_t nDeviceIndex = IP::GetDeviceIndex(m_hVideoInput);
	int check = ((CButton*)GetDlgItem(IDC_DESKEW_BLACK_PAD))->GetCheck();
	int valueL = ((CSliderCtrl*)GetDlgItem(IDC_DESKEW_CANNY_LOW))->GetPos();
	int valueH = ((CSliderCtrl*)GetDlgItem(IDC_DESKEW_CANNY_HIGH))->GetPos();
	int nMergeDist, nDownSize, nGaussKernel, nDilateKernel;
	int nReservX, nReservY, nCannyLow, nCannyHigh;

	if (IP::IsImageFilePlaying(m_hVideoInput))
	{
		IP::GetImageFileDeskewSetting(
			m_hVideoInput, &nMergeDist, &nDownSize,
			&nGaussKernel, &nDilateKernel, &nReservX, &nReservY,
			&nCannyLow, &nCannyHigh);
	}
	else if (IP::IsDevicePlaying(m_hVideoInput, nDeviceIndex))
	{
		IP::GetDeviceDeskewSetting(
			m_hVideoInput, nDeviceIndex, &nMergeDist, &nDownSize,
			&nGaussKernel, &nDilateKernel, &nReservX, &nReservY,
			&nCannyLow, &nCannyHigh);
	}

	if (check != 0)
	{
		GetDlgItem(IDC_DESKEW_CANNY_LOW)->EnableWindow(FALSE);
		GetDlgItem(IDC_DESKEW_CANNY_HIGH)->EnableWindow(FALSE);
		((CButton*)GetDlgItem(IDC_DESKEW_WHITE_PAD))->SetCheck(FALSE);

		if (IP::IsImageFilePlaying(m_hVideoInput))
		{
			IP::SetImageFileDeskewSetting(
				m_hVideoInput, nMergeDist, 1,
				nGaussKernel, 1, nReservX, nReservY,
				0, 0);
		}
		else if (IP::IsDevicePlaying(m_hVideoInput, nDeviceIndex))
		{
			IP::SetDeviceDeskewSetting(
				m_hVideoInput, nDeviceIndex, nMergeDist, 1,
				nGaussKernel, 1, nReservX, nReservY,
				0, 0);
		}

		((CSliderCtrl*)GetDlgItem(IDC_DESKEW_DOWN_SIZE))->SetPos(1);
		((CSliderCtrl*)GetDlgItem(IDC_DESKEW_DILATE_KERNEL))->SetPos(1);
		SetDlgItemText(TXT_DESKEW_DOWN_SIZE, TEXT("1"));
		SetDlgItemText(TXT_DESKEW_DILATE_KERNEL, TEXT("1"));
	}
	else
	{
		if (IP::IsImageFilePlaying(m_hVideoInput))
		{
			IP::SetImageFileDeskewSetting(
				m_hVideoInput, nMergeDist, nDownSize,
				nGaussKernel, nDilateKernel, nReservX, nReservY,
				valueL, valueH);
		}
		else if (IP::IsDevicePlaying(m_hVideoInput, nDeviceIndex))
		{
			IP::SetDeviceDeskewSetting(
				m_hVideoInput, nDeviceIndex, nMergeDist, nDownSize,
				nGaussKernel, nDilateKernel, nReservX, nReservY,
				valueL, valueH);
		}

		GetDlgItem(IDC_DESKEW_CANNY_LOW)->EnableWindow(TRUE);
		GetDlgItem(IDC_DESKEW_CANNY_HIGH)->EnableWindow(TRUE);
	}
}

void CDeskewDlg::OnBnClickedDeskewWhitePad()
{
	size_t nDeviceIndex = IP::GetDeviceIndex(m_hVideoInput);
	int check = ((CButton*)GetDlgItem(IDC_DESKEW_WHITE_PAD))->GetCheck();
	int valueL = ((CSliderCtrl*)GetDlgItem(IDC_DESKEW_CANNY_LOW))->GetPos();
	int valueH = ((CSliderCtrl*)GetDlgItem(IDC_DESKEW_CANNY_HIGH))->GetPos();
	int nMergeDist, nDownSize, nGaussKernel, nDilateKernel;
	int nReservX, nReservY, nCannyLow, nCannyHigh;

	if (IP::IsImageFilePlaying(m_hVideoInput))
	{
		IP::GetImageFileDeskewSetting(
			m_hVideoInput, &nMergeDist, &nDownSize,
			&nGaussKernel, &nDilateKernel, &nReservX, &nReservY,
			&nCannyLow, &nCannyHigh);
	}
	else if (IP::IsDevicePlaying(m_hVideoInput, nDeviceIndex))
	{
		IP::GetDeviceDeskewSetting(
			m_hVideoInput, nDeviceIndex, &nMergeDist, &nDownSize,
			&nGaussKernel, &nDilateKernel, &nReservX, &nReservY,
			&nCannyLow, &nCannyHigh);
	}

	if (check != 0)
	{
		GetDlgItem(IDC_DESKEW_CANNY_LOW)->EnableWindow(FALSE);
		GetDlgItem(IDC_DESKEW_CANNY_HIGH)->EnableWindow(FALSE);
		((CButton*)GetDlgItem(IDC_DESKEW_BLACK_PAD))->SetCheck(FALSE);

		if (IP::IsImageFilePlaying(m_hVideoInput))
		{
			IP::SetImageFileDeskewSetting(
				m_hVideoInput, nMergeDist, 2,
				nGaussKernel, 2, nReservX, nReservY,
				50, 200);
		}
		else if (IP::IsDevicePlaying(m_hVideoInput, nDeviceIndex))
		{
			IP::SetDeviceDeskewSetting(
				m_hVideoInput, nDeviceIndex, nMergeDist, 2,
				nGaussKernel, 2, nReservX, nReservY,
				50, 200);
		}

		((CSliderCtrl*)GetDlgItem(IDC_DESKEW_DOWN_SIZE))->SetPos(2);
		((CSliderCtrl*)GetDlgItem(IDC_DESKEW_DILATE_KERNEL))->SetPos(2);
		SetDlgItemText(TXT_DESKEW_DOWN_SIZE, TEXT("2"));
		SetDlgItemText(TXT_DESKEW_DILATE_KERNEL, TEXT("2"));
	}
	else
	{
		if (IP::IsImageFilePlaying(m_hVideoInput))
		{
			IP::SetImageFileDeskewSetting(
				m_hVideoInput, nMergeDist, nDownSize,
				nGaussKernel, nDilateKernel, nReservX, nReservY,
				valueL, valueH);
		}
		else if (IP::IsDevicePlaying(m_hVideoInput, nDeviceIndex))
		{
			IP::SetDeviceDeskewSetting(
				m_hVideoInput, nDeviceIndex, nMergeDist, nDownSize,
				nGaussKernel, nDilateKernel, nReservX, nReservY,
				valueL, valueH);
		}

		GetDlgItem(IDC_DESKEW_CANNY_LOW)->EnableWindow(TRUE);
		GetDlgItem(IDC_DESKEW_CANNY_HIGH)->EnableWindow(TRUE);
	}
}
