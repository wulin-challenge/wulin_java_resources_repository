#pragma once

class CEnhanceDlg : public CDialog
{
	DECLARE_DYNAMIC(CEnhanceDlg)
	DECLARE_MESSAGE_MAP()
public:
	enum { IDD = IDD_ENHANCE_SETUP };
	CEnhanceDlg(HANDLE hVideoInput);
	virtual ~CEnhanceDlg();
protected:
	HANDLE m_hVideoInput;

	virtual BOOL OnInitDialog();
	virtual void DoDataExchange(CDataExchange* pDX);
	afx_msg void OnBnClickedOk();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
public:
	afx_msg void OnBnClickedDaecEnabled();
};
