#include "stdafx.h"
#include "ImProc.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

BEGIN_MESSAGE_MAP(CImProcApp, CWinApp)
END_MESSAGE_MAP()

CImProcApp theApp;

CImProcApp::CImProcApp()
{
}

BOOL CImProcApp::InitInstance()
{
	INITCOMMONCONTROLSEX InitCtrls;
	InitCtrls.dwSize = sizeof(InitCtrls);
#if(_WIN32_WINNT >= 0x0501)
	InitCtrls.dwICC = ICC_STANDARD_CLASSES;
#else
	InitCtrls.dwICC = ICC_WIN95_CLASSES;
#endif
	InitCommonControlsEx(&InitCtrls);

	CWinApp::InitInstance();

	EnableTaskbarInteraction(FALSE);

	// AfxInitRichEdit2();

	CMainFrame* pFrame = new CMainFrame;
	if (!pFrame) return FALSE;
	m_pMainWnd = pFrame;

	pFrame->LoadFrame(
		IDR_MAINFRAME, WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE, NULL, NULL);

	pFrame->ShowWindow(SW_SHOW);
	pFrame->UpdateWindow();

	return TRUE;
}

int CImProcApp::ExitInstance()
{

	return CWinApp::ExitInstance();
}
