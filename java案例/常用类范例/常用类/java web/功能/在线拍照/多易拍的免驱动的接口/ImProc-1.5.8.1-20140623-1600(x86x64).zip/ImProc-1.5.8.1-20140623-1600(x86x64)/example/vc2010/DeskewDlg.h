#pragma once

class CDeskewDlg : public CDialog
{
	DECLARE_DYNAMIC(CDeskewDlg)
	DECLARE_MESSAGE_MAP()
public:
	enum { IDD = IDD_DESKEW_SETUP };
	HANDLE m_hVideoInput;

	CDeskewDlg(HANDLE hVideoInput);
	virtual ~CDeskewDlg();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	virtual BOOL OnInitDialog();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnBnClickedOk();
public:
	afx_msg void OnBnClickedDeskewRotateOnly();
	afx_msg void OnBnClickedDeskewBlackPad();
	afx_msg void OnBnClickedDeskewWhitePad();
};
