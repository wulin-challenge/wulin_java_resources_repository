#pragma once

CStringW LoadConfigPath(void)
{
	CStringW strOut;

	GetModuleFileNameW(NULL, strOut.GetBuffer(1024), 1024);
	strOut.ReleaseBuffer();
	strOut = strOut.Left(strOut.ReverseFind(L'\\'));
	strOut += L"\\ImProc-1.0.ini";

	return strOut;
}

int LoadConfigInt(LPCWSTR szAppName, LPCWSTR szKeyName, int nDefault)
{
	CStringW szFileName, szBuffer;

	szFileName = LoadConfigPath();
	GetPrivateProfileStringW(
	    szAppName, szKeyName, L"", szBuffer.GetBuffer(1024), 1024, szFileName);
	szBuffer.ReleaseBuffer();

	return szBuffer.IsEmpty() ? nDefault : _wtoi(szBuffer);
}

float LoadConfigFloat(LPCWSTR szAppName, LPCWSTR szKeyName, float nDefault)
{
	CStringW szFileName, szBuffer;

	szFileName = LoadConfigPath();
	GetPrivateProfileStringW(
	    szAppName, szKeyName, L"", szBuffer.GetBuffer(1024), 1024, szFileName);
	szBuffer.ReleaseBuffer();

	return szBuffer.IsEmpty() ? nDefault : (float)_wtof(szBuffer);
}

CStringW LoadConfigString(LPCWSTR szAppName, LPCWSTR szKeyName)
{
	CStringW szFileName, szBuffer;

	szFileName = LoadConfigPath();
	GetPrivateProfileStringW(
	    szAppName, szKeyName, L"", szBuffer.GetBuffer(1024), 1024, szFileName);
	szBuffer.ReleaseBuffer();

	return szBuffer;
}
