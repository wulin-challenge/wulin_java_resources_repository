﻿#include "stdafx.h"
#include "ImProc.h"
#include "EnhanceDlg.h"
#include <VideoInputDLL.h>

IMPLEMENT_DYNAMIC(CEnhanceDlg, CDialog)
BEGIN_MESSAGE_MAP(CEnhanceDlg, CDialog)
	ON_BN_CLICKED(IDOK, &CEnhanceDlg::OnBnClickedOk)
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_DAEC_ENABLED, &CEnhanceDlg::OnBnClickedDaecEnabled)
END_MESSAGE_MAP()

CEnhanceDlg::CEnhanceDlg(HANDLE hVideoInput)
	: CDialog(CEnhanceDlg::IDD, NULL)
{
	m_hVideoInput = hVideoInput;
}

CEnhanceDlg::~CEnhanceDlg()
{
}

BOOL CEnhanceDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	bool bEnhance;
	int nHue, nSaturate, nGain, nSharp, nSmooth;
	float nContrast, nGamma, nSharpScale, nSmoothSigma;
	float nVignette;
	CSliderCtrl* pHue, *pSaturate, *pGain, *pSharp, *pSmooth;
	CSliderCtrl* pContrast, *pGamma, *pSharpScale, *pSmoothSigma;
	CSliderCtrl* pVignette;
	CEdit* xHue, *xSaturate, *xGain, *xSharp, *xSmooth;
	CEdit* xContrast, *xGamma, *xSharpScale, *xSmoothSigma;
	CEdit* xVignette;
	CString szText;
	size_t nDeviceIndex;
	bool bAuto;

	nDeviceIndex = IP::GetDeviceIndex(m_hVideoInput);

	if (IP::IsImageFilePlaying(m_hVideoInput))
	{
		IP::GetImageFileEnhance(m_hVideoInput, &bEnhance, &nHue,
								&nSaturate, &nContrast, &nGain, &nGamma, &nSharp,
								&nSharpScale, &nSmooth, &nSmoothSigma);
		nVignette = IP::GetImageFileVignetting(m_hVideoInput);
	}
	else if (IP::IsDevicePlaying(m_hVideoInput, nDeviceIndex))
	{
		IP::GetDeviceEnhance(m_hVideoInput, nDeviceIndex, &bEnhance, &nHue,
							 &nSaturate, &nContrast, &nGain, &nGamma, &nSharp,
							 &nSharpScale, &nSmooth, &nSmoothSigma);
		nVignette = IP::GetDeviceVignetting(m_hVideoInput, nDeviceIndex);

		if (IP::GetDeviceCustomExposure(m_hVideoInput, nDeviceIndex, &bAuto, NULL, NULL, NULL, NULL, NULL)
				&& bAuto)

		{
			((CButton*)GetDlgItem(IDC_DAEC_ENABLED))->SetCheck(TRUE);
		}
	}

	pHue = (CSliderCtrl*)GetDlgItem(IDC_ENHANCE_HUE);
	pSaturate = (CSliderCtrl*)GetDlgItem(IDC_ENHANCE_SATURATE);
	pGain = (CSliderCtrl*)GetDlgItem(IDC_ENHANCE_GAIN);
	pSharp = (CSliderCtrl*)GetDlgItem(IDC_ENHANCE_SHARP);
	pSmooth = (CSliderCtrl*)GetDlgItem(IDC_ENHANCE_SMOOTH);
	pContrast = (CSliderCtrl*)GetDlgItem(IDC_ENHANCE_CONTRAST);
	pGamma = (CSliderCtrl*)GetDlgItem(IDC_ENHANCE_GAMMA);
	pSharpScale = (CSliderCtrl*)GetDlgItem(IDC_ENHANCE_SHARP_SCALE);
	pSmoothSigma = (CSliderCtrl*)GetDlgItem(IDC_ENHANCE_SMOOTH_SIGMA);
	pVignette = (CSliderCtrl*)GetDlgItem(IDC_ENHANCE_VIGNETTING);

	xHue = (CEdit*)GetDlgItem(TXT_ENHANCE_HUE);
	xSaturate = (CEdit*)GetDlgItem(TXT_ENHANCE_SATURATE);
	xGain = (CEdit*)GetDlgItem(TXT_ENHANCE_GAIN);
	xSharp = (CEdit*)GetDlgItem(TXT_ENHANCE_SHARP);
	xSmooth = (CEdit*)GetDlgItem(TXT_ENHANCE_SMOOTH);
	xContrast = (CEdit*)GetDlgItem(TXT_ENHANCE_CONTRAST);
	xGamma = (CEdit*)GetDlgItem(TXT_ENHANCE_GAMMA);
	xSharpScale = (CEdit*)GetDlgItem(TXT_ENHANCE_SHARP_SCALE);
	xSmoothSigma = (CEdit*)GetDlgItem(TXT_ENHANCE_SMOOTH_SIGMA);
	xVignette = (CEdit*)GetDlgItem(TXT_ENHANCE_VIGNETTING);

	pHue->SetRange(0, 360);
	pSaturate->SetRange(0, 100);
	pGain->SetRange(0, 200);
	pSharp->SetRange(0, 10);
	pSmooth->SetRange(0, 10);
	pContrast->SetRange(0, 100);
	pGamma->SetRange(0, 100);
	pSharpScale->SetRange(0, 100);
	pSmoothSigma->SetRange(0, 100);
	pVignette->SetRange(0, 90);

	pHue->SetPos(nHue);
	pSaturate->SetPos(nSaturate);
	pGain->SetPos(nGain);
	pSharp->SetPos(nSharp);
	pSmooth->SetPos(nSmooth);
	pContrast->SetPos((int)(nContrast * 10 + 0.5f));
	pGamma->SetPos((int)(nGamma * 10 + 0.5f));
	pSharpScale->SetPos((int)(nSharpScale * 10 + 0.5f));
	pSmoothSigma->SetPos((int)(nSmoothSigma * 10 + 0.5f));
	pVignette->SetPos((int)nVignette);

	szText.Format(TEXT("%d"), nHue); xHue->SetWindowText(szText);
	szText.Format(TEXT("%d"), nSaturate); xSaturate->SetWindowText(szText);
	szText.Format(TEXT("%d"), nGain); xGain->SetWindowText(szText);
	szText.Format(TEXT("%d"), nSharp); xSharp->SetWindowText(szText);
	szText.Format(TEXT("%d"), nSmooth); xSmooth->SetWindowText(szText);
	szText.Format(TEXT("%.2f"), nContrast); xContrast->SetWindowText(szText);
	szText.Format(TEXT("%.2f"), nGamma); xGamma->SetWindowText(szText);
	szText.Format(TEXT("%.2f"), nSharpScale); xSharpScale->SetWindowText(szText);
	szText.Format(TEXT("%.2f"), nSmoothSigma); xSmoothSigma->SetWindowText(szText);
	szText.Format(TEXT("%.0f"), nVignette); xVignette->SetWindowText(szText);

	return TRUE;
}

void CEnhanceDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

void CEnhanceDlg::OnBnClickedOk()
{

	CDialog::OnOK();
}

void CEnhanceDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	bool bEnhance;
	int nHue, nSaturate, nGain, nSharp, nSmooth;
	int nNewPos, nMinPos, nMaxPos;
	float nContrast, nGamma, nSharpScale, nSmoothSigma;
	float nVignette;
	CSliderCtrl* pHue, *pSaturate, *pGain, *pSharp, *pSmooth;
	CSliderCtrl* pContrast, *pGamma, *pSharpScale, *pSmoothSigma;
	CSliderCtrl* pVignette;
	CSliderCtrl* pSlider;
	CEdit* xHue, *xSaturate, *xGain, *xSharp, *xSmooth;
	CEdit* xContrast, *xGamma, *xSharpScale, *xSmoothSigma;
	CEdit* xVignette;
	CString szText;
	size_t nDeviceIndex;

	nDeviceIndex = IP::GetDeviceIndex(m_hVideoInput);

	if (IP::IsImageFilePlaying(m_hVideoInput))
	{
		IP::GetImageFileEnhance(m_hVideoInput, &bEnhance, &nHue,
								&nSaturate, &nContrast, &nGain, &nGamma, &nSharp,
								&nSharpScale, &nSmooth, &nSmoothSigma);
		nVignette = IP::GetImageFileVignetting(m_hVideoInput);
	}
	else if (IP::IsDevicePlaying(m_hVideoInput, nDeviceIndex))
	{
		IP::GetDeviceEnhance(m_hVideoInput, nDeviceIndex, &bEnhance, &nHue,
							 &nSaturate, &nContrast, &nGain, &nGamma, &nSharp,
							 &nSharpScale, &nSmooth, &nSmoothSigma);
		nVignette = IP::GetDeviceVignetting(m_hVideoInput, nDeviceIndex);
	}

	pHue = (CSliderCtrl*)GetDlgItem(IDC_ENHANCE_HUE);
	pSaturate = (CSliderCtrl*)GetDlgItem(IDC_ENHANCE_SATURATE);
	pGain = (CSliderCtrl*)GetDlgItem(IDC_ENHANCE_GAIN);
	pSharp = (CSliderCtrl*)GetDlgItem(IDC_ENHANCE_SHARP);
	pSmooth = (CSliderCtrl*)GetDlgItem(IDC_ENHANCE_SMOOTH);
	pContrast = (CSliderCtrl*)GetDlgItem(IDC_ENHANCE_CONTRAST);
	pGamma = (CSliderCtrl*)GetDlgItem(IDC_ENHANCE_GAMMA);
	pSharpScale = (CSliderCtrl*)GetDlgItem(IDC_ENHANCE_SHARP_SCALE);
	pSmoothSigma = (CSliderCtrl*)GetDlgItem(IDC_ENHANCE_SMOOTH_SIGMA);
	pVignette = (CSliderCtrl*)GetDlgItem(IDC_ENHANCE_VIGNETTING);

	xHue = (CEdit*)GetDlgItem(TXT_ENHANCE_HUE);
	xSaturate = (CEdit*)GetDlgItem(TXT_ENHANCE_SATURATE);
	xGain = (CEdit*)GetDlgItem(TXT_ENHANCE_GAIN);
	xSharp = (CEdit*)GetDlgItem(TXT_ENHANCE_SHARP);
	xSmooth = (CEdit*)GetDlgItem(TXT_ENHANCE_SMOOTH);
	xContrast = (CEdit*)GetDlgItem(TXT_ENHANCE_CONTRAST);
	xGamma = (CEdit*)GetDlgItem(TXT_ENHANCE_GAMMA);
	xSharpScale = (CEdit*)GetDlgItem(TXT_ENHANCE_SHARP_SCALE);
	xSmoothSigma = (CEdit*)GetDlgItem(TXT_ENHANCE_SMOOTH_SIGMA);
	xVignette = (CEdit*)GetDlgItem(TXT_ENHANCE_VIGNETTING);

	pSlider = (CSliderCtrl*)pScrollBar;
	nNewPos = pSlider->GetPos();
	pSlider->GetRange(nMinPos, nMaxPos);

	if (nSBCode == SB_LINELEFT) /*nNewPos -= 1*/;
	else if (nSBCode == SB_LINERIGHT) /*nNewPos += 1*/;
	else if (nSBCode == SB_PAGELEFT) /*nNewPos += 10*/;
	else if (nSBCode == SB_PAGERIGHT) /*nNewPos -= 10*/;
	else if (nSBCode == SB_LEFT) nNewPos = nMinPos;
	else if (nSBCode == SB_RIGHT) nNewPos = nMaxPos;
	else if (nSBCode == SB_THUMBPOSITION) nNewPos = nPos;
	else if (nSBCode == SB_THUMBTRACK) nNewPos = nPos;

	nNewPos = min(max(nNewPos, nMinPos), nMaxPos);

	if (pSlider == pHue) nHue = nNewPos;
	else if (pSlider == pSaturate) nSaturate = nNewPos;
	else if (pSlider == pGain) nGain = nNewPos;
	else if (pSlider == pSharp) nSharp = nNewPos;
	else if (pSlider == pSmooth) nSmooth = nNewPos;
	else if (pSlider == pContrast) nContrast = nNewPos * 0.1f;
	else if (pSlider == pGamma) nGamma = nNewPos * 0.1f;
	else if (pSlider == pSharpScale) nSharpScale = nNewPos * 0.1f;
	else if (pSlider == pSmoothSigma) nSmoothSigma = nNewPos * 0.1f;
	else if (pSlider == pVignette) nVignette = (float)nNewPos;

	szText.Format(TEXT("%d"), nHue); xHue->SetWindowText(szText);
	szText.Format(TEXT("%d"), nSaturate); xSaturate->SetWindowText(szText);
	szText.Format(TEXT("%d"), nGain); xGain->SetWindowText(szText);
	szText.Format(TEXT("%d"), nSharp); xSharp->SetWindowText(szText);
	szText.Format(TEXT("%d"), nSmooth); xSmooth->SetWindowText(szText);
	szText.Format(TEXT("%.2f"), nContrast); xContrast->SetWindowText(szText);
	szText.Format(TEXT("%.2f"), nGamma); xGamma->SetWindowText(szText);
	szText.Format(TEXT("%.2f"), nSharpScale); xSharpScale->SetWindowText(szText);
	szText.Format(TEXT("%.2f"), nSmoothSigma); xSmoothSigma->SetWindowText(szText);
	szText.Format(TEXT("%.0f"), nVignette); xVignette->SetWindowText(szText);

	if (IP::IsImageFilePlaying(m_hVideoInput))
	{
		IP::SetImageFileEnhance(m_hVideoInput, bEnhance, nHue,
								nSaturate, nContrast, nGain, nGamma, nSharp,
								nSharpScale, nSmooth, nSmoothSigma);
		IP::SetImageFileVignetting(m_hVideoInput, nVignette);
	}
	else if (IP::IsDevicePlaying(m_hVideoInput, nDeviceIndex))
	{
		IP::SetDeviceEnhance(m_hVideoInput, nDeviceIndex, bEnhance, nHue,
							 nSaturate, nContrast, nGain, nGamma, nSharp,
							 nSharpScale, nSmooth, nSmoothSigma);
		IP::SetDeviceVignetting(m_hVideoInput, nDeviceIndex, nVignette);
	}

	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CEnhanceDlg::OnBnClickedDaecEnabled()
{
	size_t nDeviceIndex;
	bool bAuto;
	int nCtrl, nVal, nMin, nMax, nDef, nStep;

	nDeviceIndex = IP::GetDeviceIndex(m_hVideoInput);

	if (IP::GetDeviceCameraControl(m_hVideoInput, nDeviceIndex, 4, &bAuto, &nVal, &nMin, &nMax, &nDef, &nStep) &&
			IP::SetDeviceCameraControl(m_hVideoInput, nDeviceIndex, 4, false, nVal))
	{
		nCtrl = 4;
	}
	else if (IP::GetDeviceCameraControl(m_hVideoInput, nDeviceIndex, 4, &bAuto, &nVal, &nMin, &nMax, &nDef, &nStep) &&
			 IP::SetDeviceCameraControl(m_hVideoInput, nDeviceIndex, 4, false, nVal))
	{
		nCtrl = 5;
	}
	else
	{
		nCtrl = -1;
	}

	if (nCtrl == 4)
	{
		nMin = nMin < -5 ? -5 : nMin;
	}

	if (nCtrl >= 0 && ((CButton*)GetDlgItem(IDC_DAEC_ENABLED))->GetCheck())
	{
		if (MessageBoxW(L"AF530?", L"?", MB_YESNO) == IDYES)
		{
			IP::SetDeviceCameraControl(m_hVideoInput, nDeviceIndex, 4, true, -1);
			IP::SetDeviceVideoProcAmp(m_hVideoInput, nDeviceIndex, 9, false, 5);
			IP::SetDeviceCustomExposure(m_hVideoInput, nDeviceIndex, true, 19, 0, 10, 160, 200);
		}
		else
		{
			IP::SetDeviceCustomExposure(m_hVideoInput, nDeviceIndex, true, nCtrl, nMin, nMax, 160, 200);
		}
	}
	else
	{
		IP::SetDeviceCustomExposure(m_hVideoInput, nDeviceIndex, false, nCtrl, nMin, nMax, 160, 200);
		((CButton*)GetDlgItem(IDC_DAEC_ENABLED))->SetCheck(FALSE);
	}
}
