#pragma once

#include <string>
#include <vector>

class CStitchTool : public CDialog
{
	DECLARE_DYNAMIC(CStitchTool)
	DECLARE_MESSAGE_MAP()
public:
	enum { IDD = IDD_STITCH_TOOL };
	HANDLE m_hVideoInput;
	std::vector<std::wstring> m_fileList;

	CStitchTool(HANDLE hVideoInput);
	virtual ~CStitchTool(void);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);
public:
	afx_msg void OnBnClickedStitchGrab();
	afx_msg void OnBnClickedStitchDo();
	virtual BOOL OnInitDialog();
};
