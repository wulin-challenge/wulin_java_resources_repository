#include "stdafx.h"
#include "ImProc.h"
#include "ResolutionDlg.h"

IMPLEMENT_DYNAMIC(CResolutionDlg, CDialog)
BEGIN_MESSAGE_MAP(CResolutionDlg, CDialog)
	ON_BN_CLICKED(IDOK, &CResolutionDlg::OnBnClickedOk)
END_MESSAGE_MAP()

CResolutionDlg::CResolutionDlg(
	LPWSTR szFormatName, int* pWidth, int* pHeight,
	float* pDpiX, float* pDpiY)
	: CDialog(CResolutionDlg::IDD, NULL)
{
	m_szFormatName = szFormatName;
	m_pWidth = pWidth;
	m_pHeight = pHeight;
	m_pDpiX = pDpiX;
	m_pDpiY = pDpiY;
	m_nFormatIndex = 0;
}

CResolutionDlg::~CResolutionDlg()
{
}

void CResolutionDlg::AddFormatName(LPWSTR szFormatName)
{
	m_szFormatList.Add(szFormatName);
}

void CResolutionDlg::SetFormatIndex(size_t nFormatIndex)
{
	m_nFormatIndex = nFormatIndex;
}

void CResolutionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BOOL CResolutionDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	CComboBox* cbResList = (CComboBox*)GetDlgItem(IDC_RESOLUTION_LIST);

	for (size_t i = 0; i < m_szFormatList.GetCount(); i++)
	{
		cbResList->AddString(CW2T(m_szFormatList[i]));
	}

	cbResList->SetCurSel(m_nFormatIndex);

	return TRUE;
}

void CResolutionDlg::OnBnClickedOk()
{
	CComboBox* cbResList = (CComboBox*)GetDlgItem(IDC_RESOLUTION_LIST);
	CString szFormatName;
	CStringW szText;

	cbResList->GetLBText(cbResList->GetCurSel(), szFormatName);
	wcscpy_s(m_szFormatName, 1024, CT2W(szFormatName));

	GetDlgItemTextW(IDC_RESOLUTION_X, szText);
	*m_pWidth = _wtoi(szText);
	GetDlgItemTextW(IDC_RESOLUTION_Y, szText);
	*m_pHeight = _wtoi(szText);
	GetDlgItemTextW(IDC_RESOLUTION_DPI_X, szText);
	*m_pDpiX = (float)_wtof(szText);
	GetDlgItemTextW(IDC_RESOLUTION_DPI_Y, szText);
	*m_pDpiY = (float)_wtof(szText);

	CDialog::OnOK();
}
