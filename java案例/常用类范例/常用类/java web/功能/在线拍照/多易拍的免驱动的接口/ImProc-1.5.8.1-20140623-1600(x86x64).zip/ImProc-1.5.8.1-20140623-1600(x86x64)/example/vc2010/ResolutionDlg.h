#pragma once

#include <atlcoll.h>

class CResolutionDlg : public CDialog
{
	DECLARE_DYNAMIC(CResolutionDlg)
	DECLARE_MESSAGE_MAP()
public:
	enum { IDD = IDD_RESOLUTION };
	LPWSTR m_szFormatName;
	ATL::CAtlArray<CStringW> m_szFormatList;
	int* m_pWidth, *m_pHeight;
	float* m_pDpiX, *m_pDpiY;
	size_t m_nFormatIndex;

	CResolutionDlg(LPWSTR szFormatName, int* pWidth, int* pHeight,
				   float* pDpiX, float* pDpiY);
	virtual ~CResolutionDlg();
	void AddFormatName(LPWSTR szFormatName);
	void SetFormatIndex(size_t nFormatIndex);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
};
