#pragma once

class CSetupDPIDlg : public CDialog
{
	DECLARE_DYNAMIC(CSetupDPIDlg)
	DECLARE_MESSAGE_MAP()
public:
	enum { IDD = IDD_SETUP_DPI };
	float m_nFovX, m_nFovY, m_nDpiX, m_nDpiY;
	float* m_pFovX, *m_pFovY, *m_pDpiX, *m_pDpiY;

	CSetupDPIDlg(float* pFovX, float* pFovY,
	             float* pDpiX, float* pDpiY,
	             CWnd* pParent);
	virtual ~CSetupDPIDlg();
protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	afx_msg void OnBnClickedOk();
};
