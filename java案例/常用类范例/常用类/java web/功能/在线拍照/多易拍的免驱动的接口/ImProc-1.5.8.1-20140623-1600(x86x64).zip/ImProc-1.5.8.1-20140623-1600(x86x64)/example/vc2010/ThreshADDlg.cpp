#include "stdafx.h"
#include "ImProc.h"
#include "ChildView.h"
#include "ThreshADDlg.h"

IMPLEMENT_DYNAMIC(CThreshADDlg, CDialog)
BEGIN_MESSAGE_MAP(CThreshADDlg, CDialog)
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_THRESH_AD_ENABLED, &CThreshADDlg::OnBnClickedThreshAdEnabled)
	ON_BN_CLICKED(IDOK, &CThreshADDlg::OnBnClickedOk)
END_MESSAGE_MAP()

CThreshADDlg::CThreshADDlg(float* pRate, int* pLow, int* pHigh,
                           int* pX, int* pY, bool* pEnabled,
                           CWnd* pParent)
	: CDialog(CThreshADDlg::IDD, pParent)
{
	m_pRate = pRate;
	m_pLow = pLow;
	m_pHigh = pHigh;
	m_pX = pX;
	m_pY = pY;
	m_pEnabled = pEnabled;
}

CThreshADDlg::~CThreshADDlg()
{
}

void CThreshADDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

void CThreshADDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	CSliderCtrl* pRate, *pLow, *pHigh, *pX, *pY, *pSlider;
	CEdit* xRate, *xLow, *xHigh, *xX, *xY;
	CButton* pEnabled;
	CString szText;

	pRate = (CSliderCtrl*)GetDlgItem(IDC_THRESH_AD_RATE);
	pLow = (CSliderCtrl*)GetDlgItem(IDC_THRESH_AD_LOW);
	pHigh = (CSliderCtrl*)GetDlgItem(IDC_THRESH_AD_HIGH);
	pX = (CSliderCtrl*)GetDlgItem(IDC_THRESH_AD_X);
	pY = (CSliderCtrl*)GetDlgItem(IDC_THRESH_AD_Y);

	xRate = (CEdit*)GetDlgItem(TXT_THRESH_AD_RATE);
	xLow = (CEdit*)GetDlgItem(TXT_THRESH_AD_LOW);
	xHigh = (CEdit*)GetDlgItem(TXT_THRESH_AD_HIGH);
	xX = (CEdit*)GetDlgItem(TXT_THRESH_AD_X);
	xY = (CEdit*)GetDlgItem(TXT_THRESH_AD_Y);

	pEnabled = (CButton*)GetDlgItem(IDC_THRESH_AD_ENABLED);
	pSlider = (CSliderCtrl*)pScrollBar;

	int nNewPos = pSlider->GetPos();
	int nMinPos, nMaxPos;

	pSlider->GetRange(nMinPos, nMaxPos);

	switch (nSBCode)
	{
	case SB_LINELEFT:
		nNewPos -= 1;
		break;
	case SB_LINERIGHT:
		nNewPos += 1;
		break;
	case SB_PAGELEFT:
		nNewPos += 10;
		break;
	case SB_PAGERIGHT:
		nNewPos -= 10;
		break;
	case SB_LEFT:
		nNewPos = nMinPos;
		break;
	case SB_RIGHT:
		nNewPos = nMaxPos;
		break;
	case SB_THUMBPOSITION:
		nNewPos = nPos;
		break;
	case SB_THUMBTRACK:
		nNewPos = nPos;
		break;
	case SB_ENDSCROLL:
		break;
	}

	nNewPos = min(max(nNewPos, nMinPos), nMaxPos);
	pSlider->SetPos(nNewPos);

	if (pSlider == pRate)
	{
		szText.Format(TEXT("%.3f"), nNewPos * 0.001f);
		xRate->SetWindowText(szText);
	}
	else if (pSlider == pLow)
	{
		szText.Format(TEXT("%d"), nNewPos);
		xLow->SetWindowText(szText);
	}
	else if (pSlider == pHigh)
	{
		szText.Format(TEXT("%d"), nNewPos);
		xHigh->SetWindowText(szText);
	}
	else if (pSlider == pX)
	{
		szText.Format(TEXT("%d"), nNewPos);
		xX->SetWindowText(szText);
	}
	else if (pSlider == pY)
	{
		szText.Format(TEXT("%d"), nNewPos);
		xY->SetWindowText(szText);
	}

	if (nSBCode == SB_ENDSCROLL)
	{
		((CChildView*)m_pParentWnd)->OnUpdateThresholdAdaptiveParams(
		    pRate->GetPos() * 0.001f, pX->GetPos(), pY->GetPos(),
		    pLow->GetPos(), pHigh->GetPos(), pEnabled->GetCheck() == TRUE);
	}

	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

BOOL CThreshADDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	CSliderCtrl* pRate, *pLow, *pHigh, *pX, *pY;
	CEdit* xRate, *xLow, *xHigh, *xX, *xY;
	CButton* pEnabled;
	CString szText;

	pRate = (CSliderCtrl*)GetDlgItem(IDC_THRESH_AD_RATE);
	pLow = (CSliderCtrl*)GetDlgItem(IDC_THRESH_AD_LOW);
	pHigh = (CSliderCtrl*)GetDlgItem(IDC_THRESH_AD_HIGH);
	pX = (CSliderCtrl*)GetDlgItem(IDC_THRESH_AD_X);
	pY = (CSliderCtrl*)GetDlgItem(IDC_THRESH_AD_Y);

	xRate = (CEdit*)GetDlgItem(TXT_THRESH_AD_RATE);
	xLow = (CEdit*)GetDlgItem(TXT_THRESH_AD_LOW);
	xHigh = (CEdit*)GetDlgItem(TXT_THRESH_AD_HIGH);
	xX = (CEdit*)GetDlgItem(TXT_THRESH_AD_X);
	xY = (CEdit*)GetDlgItem(TXT_THRESH_AD_Y);

	pEnabled = (CButton*)GetDlgItem(IDC_THRESH_AD_ENABLED);

	pRate->SetRange(0, 1000);
	pLow->SetRange(0, 255);
	pHigh->SetRange(0, 255);
	pX->SetRange(0, 1000);
	pY->SetRange(0, 1000);

	pRate->SetPos((int)(*m_pRate * 1000));
	pLow->SetPos(*m_pLow);
	pHigh->SetPos(*m_pHigh);
	pX->SetPos(*m_pX);
	pY->SetPos(*m_pY);

	pEnabled->SetCheck(*m_pEnabled ? TRUE : FALSE);

	szText.Format(TEXT("%.3f"), pRate->GetPos() * 0.001f);
	xRate->SetWindowText(szText);
	szText.Format(TEXT("%d"), pLow->GetPos());
	xLow->SetWindowText(szText);
	szText.Format(TEXT("%d"), pHigh->GetPos());
	xHigh->SetWindowText(szText);
	szText.Format(TEXT("%d"), pX->GetPos());
	xX->SetWindowText(szText);
	szText.Format(TEXT("%d"), pY->GetPos());
	xY->SetWindowText(szText);

	return TRUE;
}

void CThreshADDlg::OnBnClickedThreshAdEnabled()
{
	CButton* pEnabled;
	CSliderCtrl* pRate, *pLow, *pHigh, *pX, *pY;
	//bool bEnabled;

	pEnabled = (CButton*)GetDlgItem(IDC_THRESH_AD_ENABLED);
	pRate = (CSliderCtrl*)GetDlgItem(IDC_THRESH_AD_RATE);
	pLow = (CSliderCtrl*)GetDlgItem(IDC_THRESH_AD_LOW);
	pHigh = (CSliderCtrl*)GetDlgItem(IDC_THRESH_AD_HIGH);
	pX = (CSliderCtrl*)GetDlgItem(IDC_THRESH_AD_X);
	pY = (CSliderCtrl*)GetDlgItem(IDC_THRESH_AD_Y);

	//bEnabled = pEnabled->GetCheck() == TRUE;
	//pEnabled->SetCheck(!bEnabled);

	((CChildView*)m_pParentWnd)->OnUpdateThresholdAdaptiveParams(
	    pRate->GetPos() * 0.001f, pX->GetPos(), pY->GetPos(),
	    pLow->GetPos(), pHigh->GetPos(), pEnabled->GetCheck() == TRUE);
}

void CThreshADDlg::OnBnClickedOk()
{
	CButton* pEnabled;
	CSliderCtrl* pRate, *pLow, *pHigh, *pX, *pY;

	pEnabled = (CButton*)GetDlgItem(IDC_THRESH_AD_ENABLED);
	pRate = (CSliderCtrl*)GetDlgItem(IDC_THRESH_AD_RATE);
	pLow = (CSliderCtrl*)GetDlgItem(IDC_THRESH_AD_LOW);
	pHigh = (CSliderCtrl*)GetDlgItem(IDC_THRESH_AD_HIGH);
	pX = (CSliderCtrl*)GetDlgItem(IDC_THRESH_AD_X);
	pY = (CSliderCtrl*)GetDlgItem(IDC_THRESH_AD_Y);

	*m_pEnabled = pEnabled->GetCheck() == TRUE;
	*m_pRate = pRate->GetPos() * 0.001f;
	*m_pLow = pLow->GetPos();
	*m_pHigh = pHigh->GetPos();
	*m_pX = pX->GetPos();
	*m_pY = pY->GetPos();

	CDialog::OnOK();
}
