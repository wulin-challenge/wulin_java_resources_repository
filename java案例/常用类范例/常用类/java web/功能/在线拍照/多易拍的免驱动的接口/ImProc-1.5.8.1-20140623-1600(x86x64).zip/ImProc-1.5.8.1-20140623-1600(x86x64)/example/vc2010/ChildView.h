#pragma once

#include <VideoInputDLL.h>
//#include <NI2C01.h>

class CChildView : public CWnd
{
	DECLARE_MESSAGE_MAP()
protected:
	////////////////////////////////////////////////////////////////
	// Construct, Destruct
	////////////////////////////////////////////////////////////////
	HANDLE m_hVideoInput;
public:
	static void WINAPI OnFrameCallback(
		void* buffer, int width, int height, int channels, int step,
		void* param);
	virtual void FrameRecv(void* buffer, int width, int height,
		int channels, int step);

	CChildView();
	virtual ~CChildView();

protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg LRESULT OnGrabNow(WPARAM wParam, LPARAM lParam);

	afx_msg void OnGrab();
	afx_msg void OnHide();

	////////////////////////////////////////////////////////////////
	// DEVICE
	////////////////////////////////////////////////////////////////
public:
	BOOL OnDeviceChange(UINT nEventType, DWORD_PTR dwData);
protected:
	afx_msg void OnUpdateDeviceList();
	afx_msg void OnDeviceSelect(UINT nID);

	////////////////////////////////////////////////////////////////
	// FILE
	////////////////////////////////////////////////////////////////
	CStringW m_szDefaultPath;
	size_t m_nDefaultName;
	bool m_bShowGrabbed;

	bool m_grabRotate;
	int m_grabRotateLang;
	CStringW m_grabRotateText;

	afx_msg void OnFileOpenImage();
	afx_msg void OnFileSaveBmp();
	afx_msg void OnFileSaveJpeg();
	afx_msg void OnFileSaveTiff();
	afx_msg void OnFileDefaultpath();
	afx_msg void OnFileProperties();
	afx_msg void OnFileSetupDpi();
	afx_msg void OnFileShowgrabbed();
	afx_msg void OnUpdateFileShowgrabbed(CCmdUI* pCmdUI);

	////////////////////////////////////////////////////////////////
	// PROCESS: BarcodeR
	////////////////////////////////////////////////////////////////
	afx_msg void OnShowBarcode(void);
	afx_msg void OnProcessBarcoder();
	afx_msg void OnUpdateProcessBarcoder(CCmdUI* pCmdUI);

	////////////////////////////////////////////////////////////////
	// PROCESS: Deskew
	////////////////////////////////////////////////////////////////
	afx_msg void OnDeskewPreview();
	afx_msg void OnUpdateDeskewPreview(CCmdUI* pCmdUI);
	afx_msg void OnDeskewCrop();
	afx_msg void OnUpdateDeskewCrop(CCmdUI* pCmdUI);
	afx_msg void OnDeskewEnabled();
	afx_msg void OnUpdateDeskewEnabled(CCmdUI* pCmdUI);
	afx_msg void OnDeskewFindstamp();
	afx_msg void OnUpdateDeskewFindstamp(CCmdUI* pCmdUI);

	////////////////////////////////////////////////////////////////
	// PROCESS: Threshold
	////////////////////////////////////////////////////////////////
public:
	afx_msg void OnUpdateThresholdAdaptiveParams(
		float nRate, int nX, int nY, int nLow, int nHigh,
		bool bEnabled);
protected:
	afx_msg void OnThresholdOtsu();
	afx_msg void OnUpdateThresholdOtsu(CCmdUI* pCmdUI);
	afx_msg void OnThresholdAdaptive();
	afx_msg void OnUpdateThresholdAdaptive(CCmdUI* pCmdUI);

	////////////////////////////////////////////////////////////////
	// VIEW
	////////////////////////////////////////////////////////////////
	afx_msg void OnViewCrop();
	afx_msg void OnUpdateViewCrop(CCmdUI* pCmdUI);
	afx_msg void OnViewResolution();

	////////////////////////////////////////////////////////////////
	// VIEW: ColorMode
	////////////////////////////////////////////////////////////////
	afx_msg void OnColormodeColor();
	afx_msg void OnColormodeGrayscale();
	afx_msg void OnColormodeBlackwhite();
	afx_msg void OnColormodePreview();
	afx_msg void OnUpdateColormodeColor(CCmdUI* pCmdUI);
	afx_msg void OnUpdateColormodeGrayscale(CCmdUI* pCmdUI);
	afx_msg void OnUpdateColormodeBlackwhite(CCmdUI* pCmdUI);
	afx_msg void OnUpdateColormodePreview(CCmdUI* pCmdUI);

	////////////////////////////////////////////////////////////////
	// VIEW: ColorSpace
	////////////////////////////////////////////////////////////////
	afx_msg void OnColorspaceBgr();
	afx_msg void OnColorspaceHsv();
	afx_msg void OnColorspaceYuv();
	afx_msg void OnUpdateColorspaceBgr(CCmdUI* pCmdUI);
	afx_msg void OnUpdateColorspaceHsv(CCmdUI* pCmdUI);
	afx_msg void OnUpdateColorspaceYuv(CCmdUI* pCmdUI);

	////////////////////////////////////////////////////////////////
	// VIEW: ColorChannel
	////////////////////////////////////////////////////////////////
	afx_msg void OnColorchannelDisabled();
	afx_msg void OnColorchannel1();
	afx_msg void OnColorchannel2();
	afx_msg void OnColorchannel3();
	afx_msg void OnUpdateColorchannelDisabled(CCmdUI* pCmdUI);
	afx_msg void OnUpdateColorchannel1(CCmdUI* pCmdUI);
	afx_msg void OnUpdateColorchannel2(CCmdUI* pCmdUI);
	afx_msg void OnUpdateColorchannel3(CCmdUI* pCmdUI);

	////////////////////////////////////////////////////////////////
	// VIEW: Rotate
	////////////////////////////////////////////////////////////////
	afx_msg void OnRotate0();
	afx_msg void OnRotate90();
	afx_msg void OnRotate180();
	afx_msg void OnRotate270();
	afx_msg void OnUpdateRotate0(CCmdUI* pCmdUI);
	afx_msg void OnUpdateRotate90(CCmdUI* pCmdUI);
	afx_msg void OnUpdateRotate180(CCmdUI* pCmdUI);
	afx_msg void OnUpdateRotate270(CCmdUI* pCmdUI);

	////////////////////////////////////////////////////////////////
	// VIEW: Flip
	////////////////////////////////////////////////////////////////
	afx_msg void OnFlipX();
	afx_msg void OnFlipY();
	afx_msg void OnUpdateFlipX(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFlipY(CCmdUI* pCmdUI);

	////////////////////////////////////////////////////////////////
	// PROCESS: OCR
	////////////////////////////////////////////////////////////////
	afx_msg void OnShowOCR(void);
	afx_msg void OnOcrEnabled();
	afx_msg void OnOcrEnglish();
	afx_msg void OnOcrChinesetrad();
	afx_msg void OnOcrChinesesimp();
	afx_msg void OnUpdateOcrEnabled(CCmdUI* pCmdUI);
	afx_msg void OnUpdateOcrEnglish(CCmdUI* pCmdUI);
	afx_msg void OnUpdateOcrChinesetrad(CCmdUI* pCmdUI);
	afx_msg void OnUpdateOcrChinesesimp(CCmdUI* pCmdUI);
public:
	afx_msg void OnUndistortGrabchessonly();
	afx_msg void OnUpdateUndistortGrabchessonly(CCmdUI *pCmdUI);
	afx_msg void OnUndistortDotraining();
	afx_msg void OnUndistortEnabled();
	afx_msg void OnUpdateUndistortEnabled(CCmdUI *pCmdUI);
	afx_msg void OnUndistortLoadfromfile();
	afx_msg void OnBinarizeDithering();
	afx_msg void OnUpdateBinarizeDithering(CCmdUI *pCmdUI);
	afx_msg void OnFileJpegquality();
	afx_msg void OnFileSavePdf();
	afx_msg void OnFileJpegPdf();
	afx_msg void OnAutograbEnabled();
	afx_msg void OnUpdateAutograbEnabled(CCmdUI *pCmdUI);
	afx_msg void OnAutograbSetting();
	afx_msg void OnDeskewSetting();
	afx_msg void OnMiscFacehighlight();
	afx_msg void OnUpdateMiscFacehighlight(CCmdUI *pCmdUI);
	afx_msg void OnEnhanceEnabled();
	afx_msg void OnUpdateEnhanceEnabled(CCmdUI *pCmdUI);
	afx_msg void OnEnhanceSetting();
	afx_msg void OnMouseLeft();
	afx_msg void OnMouseRight();
	afx_msg void OnMouseWheel();
	afx_msg void OnUpdateMouseLeft(CCmdUI *pCmdUI);
	afx_msg void OnUpdateMouseRight(CCmdUI *pCmdUI);
	afx_msg void OnUpdateMouseWheel(CCmdUI *pCmdUI);
	afx_msg void OnGrabcombineVert();
	afx_msg void OnGrabcombineHorz();
	afx_msg void OnUpdateWatermarkEnabled(CCmdUI *pCmdUI);
	afx_msg void OnWatermarkEnabled();
	afx_msg void OnWatermarkSetting();
	afx_msg void OnGrabcombineStitching();
	afx_msg void OnRotateAny();
	afx_msg void OnMiscFillborder();
	afx_msg void OnUpdateMiscFillborder(CCmdUI *pCmdUI);
	afx_msg void OnFileJpegTiff();
	afx_msg void OnMiscFillhole();
	afx_msg void OnUpdateMiscFillhole(CCmdUI *pCmdUI);
	afx_msg void OnFileGrabRotate();
	afx_msg void OnUpdateFileGrabRotate(CCmdUI *pCmdUI);
	afx_msg void OnFileRotate0();
	afx_msg void OnFileRotate90();
	afx_msg void OnFileRotate180();
	afx_msg void OnFileRotate270();
	afx_msg void OnFileJpegZip();
};
