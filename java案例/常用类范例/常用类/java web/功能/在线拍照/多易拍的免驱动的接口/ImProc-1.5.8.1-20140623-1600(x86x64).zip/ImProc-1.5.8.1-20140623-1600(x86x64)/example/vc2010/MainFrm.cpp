#include "stdafx.h"
#include "ImProc.h"
#include "MainFrm.h"
#include <dbt.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd);
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_SETFOCUS()
	ON_WM_DEVICECHANGE()
END_MESSAGE_MAP()

CMainFrame::CMainFrame()
{
	m_hDeviceNotify = NULL;
}

CMainFrame::~CMainFrame()
{
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CFrameWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(0);

	return TRUE;
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	if (!m_childView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW,
							CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL))
		return -1;

	SetWindowTextW(L"Image Process Toolkit");

	DEV_BROADCAST_DEVICEINTERFACE data;
	memset(&data, 0, sizeof(DEV_BROADCAST_DEVICEINTERFACE));
	data.dbcc_size = sizeof(DEV_BROADCAST_DEVICEINTERFACE);
	data.dbcc_devicetype = DBT_DEVTYP_DEVICEINTERFACE;

#if(_WIN32_WINNT >= 0x0501)
	m_hDeviceNotify = RegisterDeviceNotification(
						  GetSafeHwnd(), &data,
						  DEVICE_NOTIFY_WINDOW_HANDLE |
						  DEVICE_NOTIFY_ALL_INTERFACE_CLASSES);
#else
	m_hDeviceNotify = RegisterDeviceNotification(
						  GetSafeHwnd(), &data,
						  DEVICE_NOTIFY_WINDOW_HANDLE);
#endif

	return 0;
}

void CMainFrame::OnDestroy()
{
	CFrameWnd::OnDestroy();

	if (m_hDeviceNotify)
	{
		UnregisterDeviceNotification(m_hDeviceNotify);
		m_hDeviceNotify = NULL;
	}
}

BOOL CMainFrame::OnDeviceChange(UINT nEventType, DWORD_PTR dwData)
{
	return dwData ? m_childView.OnDeviceChange(nEventType, dwData)
		   : CFrameWnd::OnDeviceChange(nEventType, dwData);
}

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}
#endif //_DEBUG

void CMainFrame::OnSetFocus(CWnd* /*pOldWnd*/)
{
	m_childView.SetFocus();
}

BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
	if (m_childView.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	return CFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}
