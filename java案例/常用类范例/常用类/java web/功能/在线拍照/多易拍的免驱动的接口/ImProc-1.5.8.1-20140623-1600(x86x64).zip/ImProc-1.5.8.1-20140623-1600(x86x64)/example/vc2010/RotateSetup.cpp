#include "stdafx.h"
#include "RotateSetup.h"
#include <VideoInputDLL.h>

IMPLEMENT_DYNAMIC(RotateSetup, CDialog);
BEGIN_MESSAGE_MAP(RotateSetup, CDialog)
	ON_WM_HSCROLL()
END_MESSAGE_MAP()

RotateSetup::RotateSetup(HANDLE hVideoInput):
	CDialog(RotateSetup::IDD, NULL)
{
	m_hVideoInput = hVideoInput;
}

RotateSetup::~RotateSetup()
{
}

void RotateSetup::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BOOL RotateSetup::OnInitDialog()
{
	CDialog::OnInitDialog();

	int nAngle;
	CString szText;
	size_t nDeviceIndex;
	CSliderCtrl* pAngle;
	CEdit* xAngle;

	nDeviceIndex = IP::GetDeviceIndex(m_hVideoInput);

	if (IP::IsImageFilePlaying(m_hVideoInput))
	{
		nAngle = IP::GetImageFileRotate(m_hVideoInput);
	}
	else if (IP::IsDevicePlaying(m_hVideoInput, nDeviceIndex))
	{
		nAngle = IP::GetDeviceRotate(m_hVideoInput, nDeviceIndex);
	}
	else
	{
		nAngle = 0;
	}

	pAngle = (CSliderCtrl*)GetDlgItem(IDC_ROTATE_ANGLE);
	pAngle->SetRange(0, 360);
	pAngle->SetPos(nAngle);

	xAngle = (CEdit*)GetDlgItem(TXT_ROTATE_ANGLE);
	szText.Format(TEXT("%d"), nAngle);
	xAngle->SetWindowText(szText);

	return TRUE;
}

void RotateSetup::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	int nAngle, nNewPos, nMinPos, nMaxPos;
	CString szText;
	size_t nDeviceIndex;
	CSliderCtrl* pAngle, *pSlider;
	CEdit* xAngle;

	nDeviceIndex = IP::GetDeviceIndex(m_hVideoInput);

	if (IP::IsImageFilePlaying(m_hVideoInput))
	{
		nAngle = IP::GetImageFileRotate(m_hVideoInput);
	}
	else if (IP::IsDevicePlaying(m_hVideoInput, nDeviceIndex))
	{
		nAngle = IP::GetDeviceRotate(m_hVideoInput, nDeviceIndex);
	}

	pAngle = (CSliderCtrl*)GetDlgItem(IDC_ROTATE_ANGLE);
		xAngle = (CEdit*)GetDlgItem(TXT_ROTATE_ANGLE);

	pSlider = (CSliderCtrl*)pScrollBar;
	nNewPos = pSlider->GetPos();
	pSlider->GetRange(nMinPos, nMaxPos);

	if (nSBCode == SB_LINELEFT) /*nNewPos -= 1*/;
	else if (nSBCode == SB_LINERIGHT) /*nNewPos += 1*/;
	else if (nSBCode == SB_PAGELEFT) /*nNewPos += 10*/;
	else if (nSBCode == SB_PAGERIGHT) /*nNewPos -= 10*/;
	else if (nSBCode == SB_LEFT) nNewPos = nMinPos;
	else if (nSBCode == SB_RIGHT) nNewPos = nMaxPos;
	else if (nSBCode == SB_THUMBPOSITION) nNewPos = nPos;
	else if (nSBCode == SB_THUMBTRACK) nNewPos = nPos;

	nNewPos = min(max(nNewPos, nMinPos), nMaxPos);

	if (pSlider == pAngle) nAngle = nNewPos;
	szText.Format(TEXT("%d"), nAngle);
	xAngle->SetWindowText(szText);

	if (IP::IsImageFilePlaying(m_hVideoInput))
	{
		IP::SetImageFileRotate(m_hVideoInput, nAngle);
	}
	else if (IP::IsDevicePlaying(m_hVideoInput, nDeviceIndex))
	{
		IP::SetDeviceRotate(m_hVideoInput, nDeviceIndex, nAngle);
	}

	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}
