#include "stdafx.h"
#include "ImProc.h"
#include "SetupDPIDlg.h"

IMPLEMENT_DYNAMIC(CSetupDPIDlg, CDialog)
BEGIN_MESSAGE_MAP(CSetupDPIDlg, CDialog)
	ON_BN_CLICKED(IDOK, &CSetupDPIDlg::OnBnClickedOk)
END_MESSAGE_MAP()

CSetupDPIDlg::CSetupDPIDlg(float* pFovX, float* pFovY,
                           float* pDpiX, float* pDpiY,
                           CWnd* pParent)
	: CDialog(CSetupDPIDlg::IDD, pParent)
{
	m_pFovX = pFovX;
	m_pFovY = pFovY;
	m_pDpiX = pDpiX;
	m_pDpiY = pDpiY;

	m_nFovX = *pFovX;
	m_nFovY = *pFovY;
	m_nDpiX = *pDpiX;
	m_nDpiY = *pDpiY;
}

CSetupDPIDlg::~CSetupDPIDlg()
{
}

void CSetupDPIDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, TXT_SETUPDPI_FOV_X, m_nFovX);
	DDX_Text(pDX, TXT_SETUPDPI_FOV_Y, m_nFovY);
	DDX_Text(pDX, TXT_SETUPDPI_DPI_X, m_nDpiX);
	DDX_Text(pDX, TXT_SETUPDPI_DPI_Y, m_nDpiY);
}

void CSetupDPIDlg::OnBnClickedOk()
{
	UpdateData(TRUE);

	*m_pFovX = m_nFovX;
	*m_pFovY = m_nFovY;
	*m_pDpiX = m_nDpiX;
	*m_pDpiY = m_nDpiY;

	CDialog::OnOK();
}
