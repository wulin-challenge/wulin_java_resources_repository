﻿使用步骤：
//---------win7 64bit,for IE8 or IE9------------------------//
首先需要先注册release内的VideoInputDcom.exe
1.以系统管理员身分执行cmd.exe
2.输入指令 : cd "VideoInputDcom.exe所在路俓"
3.注册指令 : VideoInputDcom.exe /regserver
皆下来需要注册x64version内的VideoInput64Ctl.dll
4.输入指令 : cd "VideoInput64Ctl.dll所在路俓"
5.注册指令 : regsvr32 VideoInput64Ctl.dll
//注意事项，即使是在64位元的系统，IE默认仍是开启32位元。
//要开启64位元IE请到C:\Program Files\Internet Explorer内开启

//---------win7 64bit&win8 64bit,for IE10以上---------------//
// IE10以上版本即使开启IE 64位元，IE仍然会用32位元的分页开启，
// 因此IE10以上版本需要注册32位元ocx
1.以系统管理员身分执行cmd.exe
2.输入指令 : cd "VideoInputCtl.ocx所在路径"
3.注册指令 : "C:\windows\SysWOW64\regsvr32" VideoInputCtl.ocx
//注意，64位元的系统中，32位元的程式并非位于system32内，而是在SysWOW64中
//所以是用SysWOW64内的regsvr32注册


//-------------------------其他常见问题---------------------//

1.若注册失败，主要原因有两个。一是不具备管理员权限，二是遗漏相关组件。
若是遗漏相关组件，可用dependency walker查看。64位元VideoInput64Ctl.dll需要用64位元的
dependency walker调查。
2.若注册皆成功，在允许IE执行控制项后，IE立刻当机：
请用管理员权限执行cmd，注册DCOM。

3.VideoInputDcom.exe的反注册指令："VideoInputDcom.exe \unregserver"
4.VideoInputCtl.ocx的反注册指令："C:\windows\SysWOW64\regsvr32" -u VideoInputCtl.ocx
5.VideoInput64Ctl.dll的反注册指令：regsvr32 -u VideoInput64Ctl.dll



