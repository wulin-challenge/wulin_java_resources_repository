#pragma once

#include "ImProc.h"

class RotateSetup : public CDialog
{
	DECLARE_DYNAMIC(RotateSetup)
	DECLARE_MESSAGE_MAP()
private:
	enum { IDD = IDD_ROTATE_SETUP };
	HANDLE m_hVideoInput;
public:
	RotateSetup(HANDLE hVideoInput);
	virtual ~RotateSetup();
protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	virtual BOOL OnInitDialog();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
};
