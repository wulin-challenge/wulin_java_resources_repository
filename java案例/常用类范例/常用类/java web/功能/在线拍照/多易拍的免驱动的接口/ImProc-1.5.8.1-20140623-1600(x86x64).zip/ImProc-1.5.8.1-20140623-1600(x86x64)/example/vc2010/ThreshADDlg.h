#pragma once

class CThreshADDlg : public CDialog
{
	DECLARE_DYNAMIC(CThreshADDlg)
	DECLARE_MESSAGE_MAP()
public:
	enum { IDD = IDD_THRESH_AD };
	CThreshADDlg(float* pRate, int* pLow, int* pHigh,
	             int* pX, int* pY, bool* pEnabled,
	             CWnd* pParent);
	virtual ~CThreshADDlg();
protected:
	float* m_pRate;
	int* m_pLow, *m_pHigh, *m_pX, *m_pY;
	bool* m_pEnabled;

	virtual void DoDataExchange(CDataExchange* pDX);
	virtual BOOL OnInitDialog();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnBnClickedThreshAdEnabled();
	afx_msg void OnBnClickedOk();
};
