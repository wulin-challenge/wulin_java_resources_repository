#pragma once

#define _WIN32_WINNT 0x0500

#include <WinSDKVer.h>
#include <SDKDDKVer.h>
