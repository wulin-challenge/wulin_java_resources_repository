#pragma once

class CAutoGrabDlg : public CDialog
{
	DECLARE_DYNAMIC(CAutoGrabDlg)
	DECLARE_MESSAGE_MAP()
public:
	enum { IDD = IDD_AUTO_GRAB };
	int* m_pLow, *m_pHigh, *m_pTime, m_nMaxSize;
	LPWSTR m_szPrefix, m_szExt;

	CAutoGrabDlg(int* pLow, int* pHigh, int* pTime,
				 LPWSTR szPrefix, LPWSTR szExt, int nMaxSize);
	virtual ~CAutoGrabDlg(void);

	virtual void DoDataExchange(CDataExchange* pDX);
	virtual BOOL OnInitDialog();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedAutograbPrefix();
};
