#pragma once

#include <windows.h>

#define WM_GRAB_NOW     (WM_USER + 0x0159)
#define WM_MASK_CHANGED (WM_USER + 0x015A)

typedef void (WINAPI* FrameCallback)(
	void* buffer, int width, int height, int channels, int step,
	void* param);

EXTERN_C namespace IP
{
	////////////////////////////////////////////////////////////////////////
	// Initialize, Release
	////////////////////////////////////////////////////////////////////////

	HANDLE WINAPI
		CreateVideoInput(void);

	bool WINAPI
		ReleaseVideoInput(HANDLE hVideoInput);

	bool WINAPI
		SetRegInfo(HANDLE hVideoInput, LPCWSTR szRegInfo);

	bool WINAPI
		SetFrameCallback(HANDLE hVideoInput, FrameCallback pCallback,
		void* pParam);

	////////////////////////////////////////////////////////////////////////
	// Open, Close
	////////////////////////////////////////////////////////////////////////

	size_t WINAPI
		GetDeviceIndex(HANDLE hVideoInput);

	size_t WINAPI
		GetDeviceCount(HANDLE hVideoInput);

	bool WINAPI
		GetDeviceName(HANDLE hVideoInput, size_t nDeviceIndex,
		LPWSTR szDeviceName, size_t nNameSize);

	int WINAPI
		GetDeviceType(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		OpenDevice(HANDLE hVideoInput, size_t nDeviceIndex);

	size_t WINAPI
		OpenDeviceName(HANDLE hVideoInput, LPCWSTR szDeviceName);

	void WINAPI
		OpenDeviceAsync(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		WaitForOpenDevice(HANDLE hVideoInput, size_t nDeviceIndex,
		DWORD timeout);

	bool WINAPI
		OpenImageFile(HANDLE hVideoInput, LPCWSTR szFileName);

	bool WINAPI
		CloseDevice(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		CloseImageFile(HANDLE hVideoInput);

	bool WINAPI
		IsDeviceOpened(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		IsImageFileOpened(HANDLE hVideoInput);

	////////////////////////////////////////////////////////////////////////
	// Device Formats
	////////////////////////////////////////////////////////////////////////

	size_t WINAPI
		GetDeviceFormatCount(HANDLE hVideoInput, size_t nDeviceIndex);

	size_t WINAPI
		GetDeviceFormatIndex(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		GetDeviceFormat(HANDLE hVideoInput, size_t nDeviceIndex,
		size_t nFormatIndex, size_t* pWidth, size_t* pHeight,
		LPWSTR szType = NULL, size_t nTypeSize = 0);

	bool WINAPI
		GetDeviceFormatName(HANDLE hVideoInput, size_t nDeviceIndex,
		size_t nFormatIndex, LPWSTR szFormatName, size_t nNameSize);

	bool WINAPI
		SetDeviceFormat(HANDLE hVideoInput, size_t nDeviceIndex,
		size_t nWidth, size_t nHeight, LPCWSTR szType = NULL);

	bool WINAPI
		SetDeviceFormatIndex(HANDLE hVideoInput, size_t nDeviceIndex,
		size_t nFormatIndex);

	bool WINAPI
		SetDeviceFormatName(HANDLE hVideoInput, size_t nDeviceIndex,
		LPCWSTR szFormatName);

	bool WINAPI
		SetDeviceFormatByDPI(HANDLE hVideoInput, size_t nDeviceIndex,
		size_t nWidth, size_t nHeight,
		float nDpiX, float nDpiY);

	////////////////////////////////////////////////////////////////////////
	// Start, Stop
	////////////////////////////////////////////////////////////////////////

	bool WINAPI
		StartPlayDevice(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		StopPlayDevice(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		IsDevicePlaying(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		StartPlayImageFile(HANDLE hVideoInput);

	bool WINAPI
		StopPlayImageFile(HANDLE hVideoInput);

	bool WINAPI
		IsImageFilePlaying(HANDLE hVideoInput);

	bool WINAPI
		SetStopOnChange(HANDLE hVideoInput, bool bStopOnChange);

	////////////////////////////////////////////////////////////////////////
	// Preview
	////////////////////////////////////////////////////////////////////////

	bool WINAPI
		SetPreviewWindow(HANDLE hVideoInput, HWND hWnd);

	HWND WINAPI
		GetPreviewWindow(HANDLE hVideoInput);

	bool WINAPI
		GetDisplayRect(HANDLE hVideoInput, int* pX, int* pY,
		int* pW, int* pH);

	bool WINAPI
		SetFastPreview(HANDLE hVideoInput, bool bPreview);

	////////////////////////////////////////////////////////////////////////
	// Grab
	////////////////////////////////////////////////////////////////////////

	bool WINAPI
		ProcessFileName(HANDLE hVideoInput, LPWSTR szFileName, size_t nMaxSize);

	bool WINAPI
		ShowSaveFileDialog(HANDLE hVideoInput, LPCWSTR szFilter,
		LPCWSTR szDefaultExt, LPWSTR szFileName, size_t nMaxSize);

	BSTR WINAPI
		GrabToBase64(HANDLE hVideoInput, LPCWSTR szFileExt);

	bool WINAPI
		GrabToFile(HANDLE hVideoInput, LPCWSTR szFileName);

	bool WINAPI
		GrabToPdf(HANDLE hVideoInput, LPCWSTR szFileName, LPCWSTR szTitle,
		LPCWSTR szAuthor, LPCWSTR szKeyword, LPCWSTR szSubject,
		LPCWSTR szCreator);

	bool WINAPI
		CombineImages(HANDLE hVideoInput, LPCWSTR szFileLines,
		LPCWSTR szFileOut, int nCols, int bgValue);

	bool WINAPI
		StitchImages(HANDLE hVideoInput, LPCWSTR szFileLines,
		LPCWSTR szFileOut, bool bRemoveBorder);

	bool WINAPI
		RotateImage(HANDLE hVideoInput, LPCWSTR szFileIn,
		LPCWSTR szFileOut, int nAngle);

	bool WINAPI
		SetJpegQuality(HANDLE hVideoInput, float nJpegQuality);

	float WINAPI
		GetJpegQuality(HANDLE hVideoInput);

	bool WINAPI
		SetGrabbedDPI(HANDLE hVideoInput, float nDpiX, float nDpiY);

	bool WINAPI
		ResizeGrabbedFile(HANDLE hVideoInput, LPCWSTR szFileIn,
		LPCWSTR szFileOut, size_t nWidth, size_t nHeight,
		bool bKeepDpi);

	bool WINAPI
		RotateGrabbedFileByString(HANDLE hVideoInput, LPCWSTR szFileIn,
		LPCWSTR szFileOut, LPCWSTR szString, int nLanguage);

	bool WINAPI
		ShowGrabbedFile(HANDLE hVideoInput, LPCWSTR szFileName);

	bool WINAPI
		JpegToPdf(HANDLE hVideoInput, LPCWSTR szFileIn, LPCWSTR szFileOut,
		LPCWSTR szTitle, LPCWSTR szAuthor, LPCWSTR szKeyword,
		LPCWSTR szSubject, LPCWSTR szCreator);

	bool WINAPI
		JpegToTiff(HANDLE hVideoInput, LPCWSTR szFileIn, LPCWSTR szFileOut);

	bool WINAPI
		JpegToZip(HANDLE hVideoInput, LPCWSTR szFileIn, LPCWSTR szFileOut, LPCWSTR szPassword);

	bool WINAPI
		SetDeviceAutoGrab(HANDLE hVideoInput, size_t nDeviceIndex, bool bAutoGrab);

	bool WINAPI
		GetDeviceAutoGrab(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		SetDeviceAutoGrabSetting(HANDLE hVideoInput, size_t nDeviceIndex,
		int nStableLow, int nStableHigh, int nStableTime,
		LPCWSTR szGrabPrefix, LPCWSTR szGrabExt);

	bool WINAPI
		GetDeviceAutoGrabSetting(HANDLE hVideoInput, size_t nDeviceIndex,
		int* pStableLow, int* pStableHigh, int* pStableTime,
		LPWSTR szGrabPrefix, LPWSTR szGrabExt, size_t nMaxSize);

	bool WINAPI
		SetDeviceNotifyWindow(HANDLE hVideoInput, size_t nDeviceIndex, HWND hWnd);

	HWND WINAPI
		GetDeviceNotifyWindow(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		HttpPostFile(LPCWSTR szHttpAddr, LPCWSTR szFileName, LPCWSTR szFileResult);

	bool WINAPI
		HttpPostFileH(LPCWSTR szHttpAddr, LPCWSTR szFileName, LPCWSTR szHeaders,
		LPCWSTR szFileResult);

	////////////////////////////////////////////////////////////////////////
	// Property
	////////////////////////////////////////////////////////////////////////

	bool WINAPI
		ShowDevicePages(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		ShowImageFilePages(HANDLE hVideoInput);

	bool WINAPI
		SetDeviceFOV(HANDLE hVideoInput, size_t nDeviceIndex,
		float nFovX, float nFovY);

	bool WINAPI
		GetDeviceFOV(HANDLE hVideoInput, size_t nDeviceIndex,
		float* pFovX, float* pFovY);

	bool WINAPI
		GetDeviceDPI(HANDLE hVideoInput, size_t nDeviceIndex,
		float* pDpiX, float* pDpiY);

	bool WINAPI
		SetImageFileFOV(HANDLE hVideoInput, float nFovX, float nFovY);

	bool WINAPI
		GetImageFileFOV(HANDLE hVideoInput, float* pFovX, float* pFovY);

	bool WINAPI
		GetImageFileDPI(HANDLE hVideoInput, float* pDpiX, float* pDpiY);

	////////////////////////////////////////////////////////////////////////
	// ColorMode
	////////////////////////////////////////////////////////////////////////

	bool WINAPI
		SetColorMode(HANDLE hVideoInput, int nColorMode);

	int WINAPI
		GetColorMode(HANDLE hVideoInput);

	bool WINAPI
		SetColorPreview(HANDLE hVideoInput, bool bPreview);

	bool WINAPI
		GetColorPreview(HANDLE hVideoInput);

	bool WINAPI
		SetColorSpace(HANDLE hVideoInput, int nColorSpace);

	int WINAPI
		GetColorSpace(HANDLE hVideoInput);

	bool WINAPI
		SetColorChannel(HANDLE hVideoInput, int nColorChannel);

	int WINAPI
		GetColorChannel(HANDLE hVideoInput);

	bool WINAPI
		SetBinarizeMode(HANDLE hVideoInput, int nBinarizeMode);

	int WINAPI
		GetBinarizeMode(HANDLE hVideoInput);

	bool WINAPI
		SetBinarizeAdaptive(HANDLE hVideoInput, float nRate,
		int nX, int nY, int nLow, int nHigh);

	bool WINAPI
		GetBinarizeAdaptive(HANDLE hVideoInput, float* pRate,
		int* pX, int* pY, int* pLow, int* pHigh);

	////////////////////////////////////////////////////////////////////////
	// Rotate and Flip
	////////////////////////////////////////////////////////////////////////

	bool WINAPI
		SetDeviceRotate(HANDLE hVideoInput, size_t nDeviceIndex,
		int nAngle);

	int WINAPI
		GetDeviceRotate(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		SetImageFileRotate(HANDLE hVideoInput, int nAngle);

	int WINAPI
		GetImageFileRotate(HANDLE hVideoInput);

	bool WINAPI
		SetDeviceFlipX(HANDLE hVideoInput, size_t nDeviceIndex,
		bool bFlipX);

	bool WINAPI
		SetDeviceFlipY(HANDLE hVideoInput, size_t nDeviceIndex,
		bool bFlipY);

	bool WINAPI
		GetDeviceFlipX(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		GetDeviceFlipY(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		SetImageFileFlipX(HANDLE hVideoInput, bool bFlipX);

	bool WINAPI
		SetImageFileFlipY(HANDLE hVideoInput, bool bFlipY);

	bool WINAPI
		GetImageFileFlipX(HANDLE hVideoInput);

	bool WINAPI
		GetImageFileFlipY(HANDLE hVideoInput);

	////////////////////////////////////////////////////////////////////////
	// Deskew
	////////////////////////////////////////////////////////////////////////

	bool WINAPI
		SetDeviceDeskew(HANDLE hVideoInput, size_t nDeviceIndex,
		bool bDeskew);

	bool WINAPI
		GetDeviceDeskew(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		SetImageFileDeskew(HANDLE hVideoInput, bool bDeskew);

	bool WINAPI
		GetImageFileDeskew(HANDLE hVideoInput);

	bool WINAPI
		SetDeskewPreview(HANDLE hVideoInput, bool bPreview);

	bool WINAPI
		GetDeskewPreview(HANDLE hVideoInput);

	bool WINAPI
		SetDeskewCrop(HANDLE hVideoInput, bool bCrop);

	bool WINAPI
		GetDeskewCrop(HANDLE hVideoInput);

	bool WINAPI
		SetDeskewStamp(HANDLE hVideoInput, bool bStamp);

	bool WINAPI
		GetDeskewStamp(HANDLE hVideoInput);

	bool WINAPI
		SetDeviceDeskewSetting(HANDLE hVideoInput, size_t nDeviceIndex,
		int nMergeDist, int nDownSize, int nGaussKernel,
		int nDilateKernel, int nReservX, int nReservY,
		int nCannyLow, int nCannyHigh);

	bool WINAPI
		GetDeviceDeskewSetting(HANDLE hVideoInput, size_t nDeviceIndex,
		int* pMergeDist, int* pDownSize, int* pGaussKernel,
		int* pDilateKernel, int* pReservX, int* pReservY,
		int* pCannyLow, int* pCannyHigh);

	bool WINAPI
		SetImageFileDeskewSetting(HANDLE hVideoInput,
		int nMergeDist, int nDownSize, int nGaussKernel,
		int nDilateKernel, int nReservX, int nReservY,
		int nCannyLow, int nCannyHigh);

	bool WINAPI
		GetImageFileDeskewSetting(HANDLE hVideoInput,
		int* pMergeDist, int* pDownSize, int* pGaussKernel,
		int* pDilateKernel, int* pReservX, int* pReservY,
		int* pCannyLow, int* pCannyHigh);

	bool WINAPI
		SetDeviceFillBorder(HANDLE hVideoInput, size_t nDeviceIndex,
		bool bFillBorder);

	bool WINAPI
		GetDeviceFillBorder(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI 
		SetImageFileFillBorder(HANDLE hVideoInput, bool bFillBorder);

	bool WINAPI 
		GetImageFileFillBorder(HANDLE hVideoInput);

	bool WINAPI
		SetDeviceFillHole(HANDLE hVideoInput, size_t nDeviceIndex,
		bool bFillHole);

	bool WINAPI
		GetDeviceFillHole(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI 
		SetImageFileFillHole(HANDLE hVideoInput, bool bFillHole);

	bool WINAPI 
		GetImageFileFillHole(HANDLE hVideoInput);

	////////////////////////////////////////////////////////////////////////
	// SrcRect, DstRect, MaskRect
	////////////////////////////////////////////////////////////////////////

	bool WINAPI
		SetDeviceSrcRect(HANDLE hVideoInput, size_t nDeviceIndex,
		float nX, float nY, float nW, float nH);

	bool WINAPI
		SetDeviceDstRect(HANDLE hVideoInput, size_t nDeviceIndex,
		float nX, float nY, float nW, float nH);

	bool WINAPI
		SetDeviceMaskRect(HANDLE hVideoInput, size_t nDeviceIndex,
		float nX, float nY, float nW, float nH);

	bool WINAPI
		GetDeviceSrcRect(HANDLE hVideoInput, size_t nDeviceIndex,
		float* pX, float* pY, float* pW, float* pH);

	bool WINAPI
		GetDeviceDstRect(HANDLE hVideoInput, size_t nDeviceIndex,
		float* pX, float* pY, float* pW, float* pH);

	bool WINAPI
		GetDeviceMaskRect(HANDLE hVideoInput, size_t nDeviceIndex,
		float* pX, float* pY, float* pW, float* pH);

	bool WINAPI
		SetImageFileSrcRect(HANDLE hVideoInput,
		float nX, float nY, float nW, float nH);

	bool WINAPI
		SetImageFileDstRect(HANDLE hVideoInput,
		float nX, float nY, float nW, float nH);

	bool WINAPI
		SetImageFileMaskRect(HANDLE hVideoInput,
		float nX, float nY, float nW, float nH);

	bool WINAPI
		GetImageFileSrcRect(HANDLE hVideoInput,
		float* pX, float* pY, float* pW, float* pH);

	bool WINAPI
		GetImageFileDstRect(HANDLE hVideoInput,
		float* pX, float* pY, float* pW, float* pH);

	bool WINAPI
		GetImageFileMaskRect(HANDLE hVideoInput,
		float* pX, float* pY, float* pW, float* pH);

	bool WINAPI
		ZoomDeviceDstRect(HANDLE hVideoInput, size_t nDeviceIndex,
		float nScaleX, float nScaleY);

	bool WINAPI
		MoveDeviceDstRect(HANDLE hVideoInput, size_t nDeviceIndex,
		float nOffsetX, float nOffsetY);

	bool WINAPI
		ZoomImageFileDstRect(HANDLE hVideoInput,
		float nScaleX, float nScaleY);

	bool WINAPI
		MoveImageFileDstRect(HANDLE hVideoInput,
		float nOffsetX, float nOffsetY);

	bool WINAPI
		SetMouseEnabled(HANDLE hVideoInput,
		bool bLeft, bool bRight, bool bWheel);

	bool WINAPI
		GetMouseEnabled(HANDLE hVideoInput,
		bool* bLeft, bool* bRight, bool* bWheel);

	////////////////////////////////////////////////////////////////////////
	// NICapUSB
	////////////////////////////////////////////////////////////////////////

	bool WINAPI
		SetAppendMac(HANDLE hVideoInput, bool bAppendMac);

	bool WINAPI
		CheckAppendedMac(HANDLE hVideoInput, LPCWSTR szFileName);

	bool WINAPI
		CheckDeviceMac(HANDLE hVideoInput, size_t nDeviceIndex,
		LPCWSTR szMac);

	bool WINAPI
		TickDeviceAutoFocus(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		SetDeviceFocus(HANDLE hVideoInput, size_t nDeviceIndex,
		int nFocusVal);

	bool WINAPI
		GetDeviceFocus(HANDLE hVideoInput, size_t nDeviceIndex,
		int* nFocusVal, int* nFocusMin, int* nFocusMax);

	bool WINAPI
		SetDeviceAutoFocus(HANDLE hVideoInput, size_t nDeviceIndex,
		bool bAutoFocus);

	bool WINAPI
		GetDeviceAutoFocus(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		SetDeviceExposure(HANDLE hVideoInput, size_t nDeviceIndex,
		int nExpVal);

	bool WINAPI
		GetDeviceExposure(HANDLE hVideoInput, size_t nDeviceIndex,
		int* nExpVal, int* nExpMin, int* nExpMax);

	bool WINAPI
		SetDeviceAutoExposure(HANDLE hVideoInput, size_t nDeviceIndex,
		bool bAutoExp);

	bool WINAPI
		GetDeviceAutoExposure(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		SetDeviceBrightness(HANDLE hVideoInput, size_t nDeviceIndex,
		int nBriVal);

	bool WINAPI
		GetDeviceBrightness(HANDLE hVideoInput, size_t nDeviceIndex,
		int* nBriVal, int* nBriMin, int* nBriMax);

	bool WINAPI
		SetDeviceContrast(HANDLE hVideoInput, size_t nDeviceIndex,
		int nConVal);

	bool WINAPI
		GetDeviceContrast(HANDLE hVideoInput, size_t nDeviceIndex,
		int* nConVal, int* nConMin, int* nConMax);

	bool WINAPI
		SetDeviceCameraControl(HANDLE hVideoInput, size_t nDeviceIndex,
		int nId, bool bAuto, int nVal);

	bool WINAPI
		GetDeviceCameraControl(HANDLE hVideoInput, size_t nDeviceIndex,
		int nId, bool* pAuto, int* pVal, int* pMin,
		int* pMax, int* pDef, int* pStep);

	bool WINAPI
		SetDeviceVideoProcAmp(HANDLE hVideoInput, size_t nDeviceIndex,
		int nId, bool bAuto, int nVal);

	bool WINAPI
		GetDeviceVideoProcAmp(HANDLE hVideoInput, size_t nDeviceIndex,
		int nId, bool* pAuto, int* pVal, int* pMin,
		int* pMax, int* pDef, int* pStep);

	////////////////////////////////////////////////////////////////////////
	// BarcodeR
	////////////////////////////////////////////////////////////////////////

	bool WINAPI
		SetDeviceBarcode(HANDLE hVideoInput, size_t nDeviceIndex,
		bool bBarcode);

	bool WINAPI
		GetDeviceBarcode(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		SetImageFileBarcode(HANDLE hVideoInput, bool bBarcode);

	bool WINAPI
		GetImageFileBarcode(HANDLE hVideoInput);

	size_t WINAPI
		GetBarcodeCount(HANDLE hVideoInput);

	bool WINAPI
		GetBarcodeContent(HANDLE hVideoInput, size_t nIndex,
		LPWSTR szBarcode, size_t nMaxSize);

	bool WINAPI
		GetBarcodeTypeName(HANDLE hVideoInput, size_t nIndex,
		LPWSTR szTypeName, size_t nMaxSize);

	bool WINAPI
		SetDeviceQRcode(HANDLE hVideoInput, size_t nDeviceIndex,
		bool bQRcode);

	bool WINAPI
		GetDeviceQRcode(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		SetImageFileQRcode(HANDLE hVideoInput, bool bQRcode);

	bool WINAPI
		GetImageFileQRcode(HANDLE hVideoInput);

	size_t WINAPI
		GetQRcodeCount(HANDLE hVideoInput);

	bool WINAPI
		GetQRcodeContent(HANDLE hVideoInput, size_t nIndex,
		LPWSTR szQRcode, size_t nMaxSize);

	bool WINAPI
		GetQRcodeTypeName(HANDLE hVideoInput, size_t nIndex,
		LPWSTR szTypeName, size_t nMaxSize);

	////////////////////////////////////////////////////////////////////////
	// OCR
	////////////////////////////////////////////////////////////////////////

	bool WINAPI
		SetDeviceOCR(HANDLE hVideoInput, size_t nDeviceIndex, bool bOCR);

	bool WINAPI
		GetDeviceOCR(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		SetImageFileOCR(HANDLE hVideoInput, bool bOCR);

	bool WINAPI
		GetImageFileOCR(HANDLE hVideoInput);

	bool WINAPI
		SetOCRLanguage(HANDLE hVideoInput, int nLanguage);

	int WINAPI
		GetOCRLanguage(HANDLE hVideoInput);

	size_t WINAPI
		GetOCRLength(HANDLE hVideoInput);

	bool WINAPI
		GetOCRResult(HANDLE hVideoInput, LPWSTR szOCR, size_t nMaxSize);

	bool WINAPI
		DoOCRFile(HANDLE hVideoInput, LPCWSTR szFile);

	////////////////////////////////////////////////////////////////////////
	// Undistort
	////////////////////////////////////////////////////////////////////////

	bool WINAPI
		SetGrabChessOnly(HANDLE hVideoInput, bool bChessOnly);

	bool WINAPI
		GetGrabChessOnly(HANDLE hVideoInput);

	bool WINAPI
		SetChessSize(HANDLE hVideoInput, size_t nCols, size_t nRows);

	bool WINAPI
		GetChessSize(HANDLE hVideoInput, size_t* pCols, size_t* pRows);

	bool WINAPI
		TrainChessSamples(HANDLE hVideoInput, LPCWSTR szRootDir,
		bool bFishEyes, bool bTangent);

	bool WINAPI
		SetDeviceUndistort(HANDLE hVideoInput, size_t nDeviceIndex,
		bool bUndistort);

	bool WINAPI
		GetDeviceUndistort(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		SetDeviceUndistortCoeffs(HANDLE hVideoInput, size_t nDeviceIndex,
		LPCWSTR szCoeffs);

	bool WINAPI
		GetDeviceUndistortCoeffs(HANDLE hVideoInput, size_t nDeviceIndex,
		LPWSTR szCoeffs, size_t nMaxSize);

	////////////////////////////////////////////////////////////////////////
	// Enhance
	////////////////////////////////////////////////////////////////////////

	bool WINAPI
		SetDeviceEnhance(HANDLE hVideoInput, size_t nDeviceIndex,
		bool enhance, int hue, int saturate, float contrast,
		int gain, float gamma, int sharp, float sharpScale,
		int smooth, float smoothSigma);

	bool WINAPI
		SetDeviceVignetting(HANDLE hVideoInput, size_t nDeviceIndex,
		float nAngle);

	bool WINAPI
		GetDeviceEnhance(HANDLE hVideoInput, size_t nDeviceIndex,
		bool* enhance, int* hue, int* saturate,
		float* contrast, int* gain, float* gamma, int* sharp,
		float* sharpScale, int* smooth, float* smoothSigma);

	float WINAPI
		GetDeviceVignetting(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		SetImageFileEnhance(HANDLE hVideoInput,
		bool enhance, int hue, int saturate, float contrast,
		int gain, float gamma, int sharp, float sharpScale,
		int smooth, float smoothSigma);

	bool WINAPI
		SetImageFileVignetting(HANDLE hVideoInput, float nAngle);

	bool WINAPI
		GetImageFileEnhance(HANDLE hVideoInput,
		bool* enhance, int* hue, int* saturate,
		float* contrast, int* gain, float* gamma, int* sharp,
		float* sharpScale, int* smooth, float* smoothSigma);

	float WINAPI
		GetImageFileVignetting(HANDLE hVideoInput);

	bool WINAPI
		SetDeviceFaceHighlight(HANDLE hVideoInput, size_t nDeviceIndex,
		bool bHighlight, int nGaussKernel, int nRunStep,
		LPCWSTR szXmlFile);
	bool WINAPI
		GetDeviceFaceHighlight(HANDLE hVideoInput, size_t nDeviceIndex,
		bool* bHighlight, int* nGaussKernel, int* nRunStep,
		LPWSTR szXmlFile, size_t nMaxSize);

	bool WINAPI
		SetImageFileFaceHighlight(HANDLE hVideoInput,
		bool bHighlight, int nGaussKernel, int nRunStep,
		LPCWSTR szXmlFile);
	bool WINAPI
		GetImageFileFaceHighlight(HANDLE hVideoInput,
		bool* bHighlight, int* nGaussKernel, int* nRunStep,
		LPWSTR szXmlFile, size_t nMaxSize);

	////////////////////////////////////////////////////////////////////////
	// Record
	////////////////////////////////////////////////////////////////////////

	bool WINAPI
		SetDeviceRecord(HANDLE hVideoInput, size_t nDeviceIndex,
		bool bRecord);

	bool WINAPI
		GetDeviceRecord(HANDLE hVideoInput, size_t nDeviceIndex);

	bool WINAPI
		SetDeviceRecordFileName(HANDLE hVideoInput, size_t nDeviceIndex,
		LPCWSTR szFileName);

	bool WINAPI
		GetDeviceRecordFileName(HANDLE hVideoInput, size_t nDeviceIndex,
		LPWSTR szFileName, size_t nMaxSize);

	bool WINAPI
		SetDeviceRecordCodec(HANDLE hVideoInput, size_t nDeviceIndex,
		LPCWSTR szCodecName);

	bool WINAPI
		GetDeviceRecordCodec(HANDLE hVideoInput, size_t nDeviceIndex,
		LPWSTR szCodecName, size_t nMaxSize);

	////////////////////////////////////////////////////////////////////////
	// Exposure
	////////////////////////////////////////////////////////////////////////

	bool WINAPI
		SetDeviceCustomExposure(HANDLE hVideoInput, size_t nDeviceIndex,
		bool bAutoExp, int nCtrlExp, int nMinExp,
		int nMaxExp, int nLowVal, int nHighVal);
	bool WINAPI
		GetDeviceCustomExposure(HANDLE hVideoInput, size_t nDeviceIndex,
		bool* bAutoExp, int* nCtrlExp, int* nMinExp,
		int* nMaxExp, int* nLowVal, int* nHighVal);

	////////////////////////////////////////////////////////////////////////
	// Watermark
	////////////////////////////////////////////////////////////////////////

	bool WINAPI
		SetDeviceWatermark(HANDLE hVideoInput, size_t nDeviceIndex,
		bool bWatermark);
	bool WINAPI
		SetDeviceWatermarkText(HANDLE hVideoInput, size_t nDeviceIndex,
		LPCWSTR szText, float x, float y, float w, float h);
	bool WINAPI
		SetDeviceWatermarkFont(HANDLE hVideoInput, size_t nDeviceIndex,
		LPCWSTR szFontName, float nFontSize, int nFontColor, int nFontTrans);
	bool WINAPI
		GetDeviceWatermark(HANDLE hVideoInput, size_t nDeviceIndex);
	bool WINAPI
		GetDeviceWatermarkText(HANDLE hVideoInput, size_t nDeviceIndex,
		LPWSTR szText, size_t nMaxsize, float* x, float* y, float* w, float* h);
	bool WINAPI
		GetDeviceWatermarkFont(HANDLE hVideoInput, size_t nDeviceIndex,
		LPWSTR szFontName, size_t nMaxsize, float* nFontSize, int* nFontColor,
		int* nFontTrans);
}
