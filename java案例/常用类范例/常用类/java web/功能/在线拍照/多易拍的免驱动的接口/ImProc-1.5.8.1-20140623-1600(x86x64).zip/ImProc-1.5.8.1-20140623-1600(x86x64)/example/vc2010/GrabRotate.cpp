﻿#include "stdafx.h"
#include "ImProc.h"
#include "GrabRotate.h"

IMPLEMENT_DYNAMIC(CGrabRotate, CDialog)
BEGIN_MESSAGE_MAP(CGrabRotate, CDialog)
	ON_BN_CLICKED(IDOK, &CGrabRotate::OnBnClickedOk)
END_MESSAGE_MAP()

CGrabRotate::CGrabRotate(CWnd* pParent /*=NULL*/)
	: CDialog(CGrabRotate::IDD, pParent)
{
}

CGrabRotate::~CGrabRotate()
{
}

void CGrabRotate::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BOOL CGrabRotate::OnInitDialog()
{
	CDialog::OnInitDialog();

	((CComboBox*)GetDlgItem(IDC_GRAB_ROTATE_LANGUAGE))->AddString(L"English(US)");
	((CComboBox*)GetDlgItem(IDC_GRAB_ROTATE_LANGUAGE))->AddString(L"中文(繁體)");
	((CComboBox*)GetDlgItem(IDC_GRAB_ROTATE_LANGUAGE))->AddString(L"中文(简体)");

	return TRUE;
}

void CGrabRotate::OnBnClickedOk()
{
	GetDlgItemTextW(IDC_GRAB_ROTATE, m_text);
	m_lang = ((CComboBox*)GetDlgItem(IDC_GRAB_ROTATE_LANGUAGE))->GetCurSel();

	CDialog::OnOK();
}
