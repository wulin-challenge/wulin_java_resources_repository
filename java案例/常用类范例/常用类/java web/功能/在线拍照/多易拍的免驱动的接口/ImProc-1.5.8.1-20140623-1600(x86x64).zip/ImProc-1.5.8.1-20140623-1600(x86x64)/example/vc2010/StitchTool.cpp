#include "stdafx.h"
#include "ImProc.h"
#include "StitchTool.h"
#include <VideoInputDLL.h>

IMPLEMENT_DYNAMIC(CStitchTool, CDialog);
BEGIN_MESSAGE_MAP(CStitchTool, CDialog)
	ON_BN_CLICKED(IDC_STITCH_GRAB, &CStitchTool::OnBnClickedStitchGrab)
	ON_BN_CLICKED(IDC_STITCH_DO, &CStitchTool::OnBnClickedStitchDo)
END_MESSAGE_MAP()

CStitchTool::CStitchTool(HANDLE hVideoInput)
	: CDialog(CStitchTool::IDD, NULL)
{
	m_hVideoInput = hVideoInput;
}

CStitchTool::~CStitchTool(void)
{
	for (int i = 0; i < (int)m_fileList.size(); i++)
	{
		DeleteFileW(m_fileList[i].c_str());
	}
}

void CStitchTool::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

void CStitchTool::OnBnClickedStitchGrab()
{
	WCHAR tempDir[1024], tempFile[1024];

	if (m_fileList.size() >= 9)
	{
		return;
	}

	memset(tempDir, 0, sizeof(tempDir));
	memset(tempFile, 0, sizeof(tempFile));
	GetTempPathW(1024, tempDir);
	GetTempFileNameW(tempDir, L"NI", 0, tempFile);
	PathAddExtensionW(tempFile, L".bmp");
	PathRenameExtensionW(tempFile, L".bmp");

	if (IP::GrabToFile(m_hVideoInput, tempFile))
	{
		m_fileList.push_back(tempFile);

		swprintf_s(tempDir, L"%d / 9", (int)m_fileList.size());
		SetDlgItemTextW(TXT_STITCH_NUM, tempDir);
	}

	if (m_fileList.size() >= 9)
	{
		OnBnClickedStitchDo();
	}
}

void CStitchTool::OnBnClickedStitchDo()
{
	CFileDialog ofd(FALSE, L".jpg", NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		L"Image files|*.bmp;*.jpg;*.png;*.tif||");

	std::wstring fileLines, fileOut;

	if (ofd.DoModal() != IDOK)
	{
		return;
	}

	fileOut = ofd.GetPathName();

	for (int i = 0; i < (int)m_fileList.size(); i++)
	{
		fileLines += m_fileList[i] + L"\n";
	}

	if (IP::StitchImages(m_hVideoInput, fileLines.c_str(), fileOut.c_str(), true))
	{
		IP::ShowGrabbedFile(m_hVideoInput, fileOut.c_str());
	}

	for (int i = 0; i < (int)m_fileList.size(); i++)
	{
		DeleteFileW(m_fileList[i].c_str());
	}

	SetDlgItemTextW(TXT_STITCH_NUM, L"0 / 9");
	m_fileList.clear();
}

BOOL CStitchTool::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetDlgItemTextW(TXT_STITCH_NUM, L"0 / 9");

	return TRUE;
}
