#include "stdafx.h"
#include "ImProc.h"
#include "WatermarkSetup.h"
#include <VideoInputDLL.h>


IMPLEMENT_DYNAMIC(CWatermarkSetup, CDialog);
BEGIN_MESSAGE_MAP(CWatermarkSetup, CDialog)
	ON_BN_CLICKED(IDC_WATERMARK_MASKTORECT, &CWatermarkSetup::OnBnClickedWatermarkMasktorect)
	ON_BN_CLICKED(IDOK, &CWatermarkSetup::OnBnClickedOk)
	ON_EN_CHANGE(TXT_WATERMARK_X, &CWatermarkSetup::OnEnChangeWatermarkText)
	ON_EN_CHANGE(TXT_WATERMARK_Y, &CWatermarkSetup::OnEnChangeWatermarkText)
	ON_EN_CHANGE(TXT_WATERMARK_W, &CWatermarkSetup::OnEnChangeWatermarkText)
	ON_EN_CHANGE(TXT_WATERMARK_H, &CWatermarkSetup::OnEnChangeWatermarkText)
	ON_EN_CHANGE(TXT_WATERMARK_TEXT, &CWatermarkSetup::OnEnChangeWatermarkText)
	ON_EN_CHANGE(TXT_WATERMARK_FONT, &CWatermarkSetup::OnEnChangeWatermarkFont)
	ON_EN_CHANGE(TXT_WATERMARK_SIZE, &CWatermarkSetup::OnEnChangeWatermarkFont)
	ON_EN_CHANGE(TXT_WATERMARK_COLOR, &CWatermarkSetup::OnEnChangeWatermarkFont)
	ON_EN_CHANGE(TXT_WATERMARK_TRANS, &CWatermarkSetup::OnEnChangeWatermarkFont)
END_MESSAGE_MAP()

CWatermarkSetup::CWatermarkSetup(HANDLE hVideoInput)
	: CDialog(CWatermarkSetup::IDD, NULL)
	, m_szText(_T(""))
	, m_szRectX(_T(""))
	, m_szRectY(_T(""))
	, m_szRectW(_T(""))
	, m_szRectH(_T(""))
	, m_szFont(_T(""))
	, m_szSize(_T(""))
	, m_szColor(_T(""))
	, m_szTrans(_T(""))
{
	m_hVideoInput = hVideoInput;
	m_nDeviceIndex = IP::GetDeviceIndex(m_hVideoInput);
}

CWatermarkSetup::~CWatermarkSetup()
{
}

void CWatermarkSetup::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, TXT_WATERMARK_TEXT, m_szText);
	DDX_Text(pDX, TXT_WATERMARK_X, m_szRectX);
	DDX_Text(pDX, TXT_WATERMARK_Y, m_szRectY);
	DDX_Text(pDX, TXT_WATERMARK_W, m_szRectW);
	DDX_Text(pDX, TXT_WATERMARK_H, m_szRectH);
	DDX_Text(pDX, TXT_WATERMARK_FONT, m_szFont);
	DDX_Text(pDX, TXT_WATERMARK_SIZE, m_szSize);
	DDX_Text(pDX, TXT_WATERMARK_COLOR, m_szColor);
	DDX_Text(pDX, TXT_WATERMARK_TRANS, m_szTrans);
}

BOOL CWatermarkSetup::OnInitDialog()
{
	CDialog::OnInitDialog();

	CStringW text, font;
	float x, y, w, h, size;
	int color, trans;

	IP::GetDeviceWatermarkText(m_hVideoInput, m_nDeviceIndex,
		text.GetBuffer(1024), 1024, &x, &y, &w, &h);
	IP::GetDeviceWatermarkFont(m_hVideoInput, m_nDeviceIndex,
		font.GetBuffer(1024), 1024, &size, &color, &trans);

	text.ReleaseBuffer();
	font.ReleaseBuffer();

	m_szText = CW2T(text);
	m_szRectX.Format(TEXT("%.2f"), x);
	m_szRectY.Format(TEXT("%.2f"), y);
	m_szRectW.Format(TEXT("%.2f"), w);
	m_szRectH.Format(TEXT("%.2f"), h);
	m_szFont = CW2T(font);
	m_szSize.Format(TEXT("%.2f"), size);
	m_szColor.Format(TEXT("%06x"), color);
	m_szTrans.Format(TEXT("%d"), trans);

	UpdateData(FALSE);
	return TRUE;
}

void CWatermarkSetup::OnBnClickedWatermarkMasktorect()
{
	float x, y, w, h;

	UpdateData(TRUE);
	IP::GetDeviceMaskRect(m_hVideoInput, m_nDeviceIndex, &x, &y, &w, &h);
	IP::SetDeviceMaskRect(m_hVideoInput, m_nDeviceIndex, 0, 0, 0, 0);

	if (w <= 0 || h <= 0)
	{
		x = y = 0;
		w = h = 1;
	}

	m_szRectX.Format(TEXT("%.2f"), x);
	m_szRectY.Format(TEXT("%.2f"), y);
	m_szRectW.Format(TEXT("%.2f"), w);
	m_szRectH.Format(TEXT("%.2f"), h);

	UpdateData(FALSE);
	OnEnChangeWatermarkText();
}

void CWatermarkSetup::OnBnClickedOk()
{
	CDialog::OnOK();
}

void CWatermarkSetup::OnEnChangeWatermarkText()
{
	float x, y, w, h;
	CStringW text;

	UpdateData(TRUE);

	x = (float)_ttof(m_szRectX);
	y = (float)_ttof(m_szRectY);
	w = (float)_ttof(m_szRectW);
	h = (float)_ttof(m_szRectH);
	text = CT2W(m_szText);

	IP::SetDeviceWatermarkText(m_hVideoInput, m_nDeviceIndex, text, x, y, w, h);
}

void CWatermarkSetup::OnEnChangeWatermarkFont()
{
	CStringW name;
	float size;
	int color, trans;

	UpdateData(TRUE);

	name = CT2W(m_szFont);
	size = (float)_ttof(m_szSize);
	color = _tcstol(m_szColor, NULL, 16);
	trans = _ttoi(m_szTrans);

	IP::SetDeviceWatermarkFont(m_hVideoInput, m_nDeviceIndex, name, size, color, trans);
}
