#pragma once

class CGrabRotate : public CDialog
{
	DECLARE_DYNAMIC(CGrabRotate)
	DECLARE_MESSAGE_MAP()
public:
	enum { IDD = IDD_GRAB_ROTATE };
	CStringW m_text;
	int m_lang;

	CGrabRotate(CWnd* pParent = NULL);
	virtual ~CGrabRotate();
protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
};
