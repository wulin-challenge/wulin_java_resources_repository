﻿Public Class Form1
    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        ComboBox1.Items.Clear()
        Dim nDeviceCount, szDeviceName
        nDeviceCount = VideoInputCtl.GetDeviceCount()
        For nDeviceIndex = 0 To nDeviceCount - 1
            szDeviceName = VideoInputCtl.GetDeviceName(nDeviceIndex)
            ComboBox1.Items.Add(szDeviceName)
        Next
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        ComboBox2.Items.Clear()
        Dim nFormatCount, szFormatName
        VideoInputCtl.OpenDevice(ComboBox1.SelectedIndex)
        VideoInputCtl.StartPlayDevice(ComboBox1.SelectedIndex)
        nFormatCount = VideoInputCtl.GetDeviceFormatCount(ComboBox1.SelectedIndex)
        For nFormatIndex = 0 To nFormatCount - 1
            szFormatName = VideoInputCtl.GetDeviceFormatName(ComboBox1.SelectedIndex, nFormatIndex)
            ComboBox2.Items.Add(szFormatName)
        Next
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles ComboBox2.SelectedIndexChanged
        VideoInputCtl.SetDeviceFormatIndex(ComboBox1.SelectedIndex, ComboBox2.SelectedIndex)
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim dialog As SaveFileDialog
        dialog = New SaveFileDialog
        dialog.Filter = "BMP|*.bmp|JPEG|*.jpg|TIFF|*.tif"
        If dialog.ShowDialog() = DialogResult.OK Then
            VideoInputCtl.SetDeviceDeskew(ComboBox1.SelectedIndex, CheckBox1.Checked)
            VideoInputCtl.SetJpegQuality(0.8)
            VideoInputCtl.GrabToFile(dialog.FileName)
        End If
    End Sub

    Private Sub ComboBox3_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles ComboBox3.SelectedIndexChanged
        VideoInputCtl.SetColorMode(ComboBox3.SelectedIndex)
    End Sub
End Class
