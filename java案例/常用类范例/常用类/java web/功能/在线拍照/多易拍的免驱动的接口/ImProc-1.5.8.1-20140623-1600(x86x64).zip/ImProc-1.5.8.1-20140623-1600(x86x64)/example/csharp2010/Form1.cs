﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace VideoInputForm
{
    public partial class Form1 : Form
    {        
        string folderDefault;
        string formatDefault = ".bmp";
        IntPtr videoHandle;
        List<string> listDevice;
        bool IsDevice;
        int deviceIndex = 0;

        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            folderDefault = System.Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            this.MouseWheel += new MouseEventHandler(Form1_MouseWheel);
            videoHandle = VideoInput.CreateVideoInput();
            VideoInput.SetPreviewWindow(videoHandle, pictureVideo.Handle);

            #region Get number of cam
            int nCount = VideoInput.GetDeviceCount(videoHandle);
            listDevice = new List<string>();
            for (int i = 0; i < nCount; i++)
            {
                StringBuilder szDeviceName = new StringBuilder(1024);
                VideoInput.GetDeviceName(videoHandle, i, szDeviceName, szDeviceName.Capacity);
                listDevice.Add(szDeviceName.ToString());
            }
            this.SetStyle(ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.FromArgb(50, 255, 255, 255);

            foreach (string s in listDevice)
            {
                ToolStripMenuItem item = new ToolStripMenuItem();
                item.Click += new EventHandler(Device_Click);
                item.Text = s;
                item.Tag = s;
                menuDeive.DropDownItems.Add(item);
            }
            #endregion
        }      

        #region UI
        void Form1_MouseWheel(object sender, MouseEventArgs e)
        {
            int nIndex = VideoInput.GetDeviceIndex(videoHandle);
            if (e.Delta > 0)
            {
                VideoInput.ZoomDeviceDstRect(videoHandle, nIndex, 0.9f, 0.9f);
                VideoInput.ZoomImageFileDstRect(videoHandle, 0.9f, 0.9f);
            }
            else
            {
                VideoInput.ZoomDeviceDstRect(videoHandle, nIndex, 1.1f, 1.1f);
                VideoInput.ZoomImageFileDstRect(videoHandle, 1.1f, 1.1f);
            }
        }
        void Device_Click(object sender, EventArgs e)
        {
            string deviceName = (sender as ToolStripMenuItem).Tag.ToString();
            ActivateDevice(deviceName);
            OnDeviceOpen();
        }
        private void menuOpenImage_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                OpenImage(openFileDialog1.FileName);            
                OnImageOpen();
            }
        }
        private void menuSaveAs_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                GrabToFile(saveFileDialog1.FileName);
            }
        }
        private void menuDeskewEnable_CheckedChanged(object sender, EventArgs e)
        {
            SetDeskewEnable(menuDeskewEnable.Checked);
        }
        private void menuDeskewSetting_Click(object sender, EventArgs e)
        {
            int[] Values = GetImageDeskewSetting();
            DeskewSettingDialog dsDialog = new DeskewSettingDialog(SetDeskewSetting, Values);
            if (dsDialog.ShowDialog() != System.Windows.Forms.DialogResult.OK)
            {
                SetDeskewSetting(Values[0], Values[1], Values[2], Values[3], Values[4], Values[5], Values[6], Values[7]);
            }
        }
        private void menuSnapshot_Click(object sender, EventArgs e)
        {
            string filename = Path.Combine(folderDefault, string.Format("P0001{0}", formatDefault));
            int index = 1;
            while (File.Exists(filename))
            {
                index++;
                filename = Path.Combine(folderDefault, string.Format("P{0:0000}{1}", index, formatDefault));
            }

            /*Grab to file*/           
            if (GrabToFile(filename))
            {
                /*Show image from file*/
                //WinImage winImg = new WinImage(filename);
                //winImg.Show();
            }
            /*Grab to base64*/
            Image img = GrabToImage(formatDefault);
            /*Show image from image*/
            if (img != null)
            {
                WinImage winImg = new WinImage(img);
                winImg.Show();
            }
        }
        private void OnDeviceOpen()
        {
            IsDevice = true;
            SetDeskewEnable(menuDeskewEnable.Checked);
        }
        private void OnImageOpen()
        {
            IsDevice = false;
            SetDeskewEnable(menuDeskewEnable.Checked);
        }
        #endregion

        #region FUNCTION
        void ActivateDevice(string dName)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(dName);
            int index = VideoInput.OpenDeviceName(videoHandle, sb);
            VideoInput.StartPlayDevice(videoHandle, index);
            deviceIndex = index;
        }
        void OpenImage(string filename)
        {
            StringBuilder sb = new StringBuilder(filename.Length);
            sb.Append(filename);
            bool a = VideoInput.OpenImageFile(videoHandle, sb);
            VideoInput.StartPlayImageFile(videoHandle);
        }
        bool GrabToFile(string filename)
        {
            return  VideoInput.GrabToFile(videoHandle, filename);
        }
        Image GrabToImage(string ext)
        {
            string base64 = VideoInput.GrabToBase64(videoHandle, ext);
            return Base64ToImage(base64);
        }
        void SetDeskewEnable(bool enable)
        {
            if (IsDevice)
                VideoInput.SetDeviceDeskew(videoHandle, deviceIndex, enable);
            else
                VideoInput.SetImageFileDeskew(videoHandle, enable);
            VideoInput.SetDeskewPreview(videoHandle, enable);
        }
        void SetDeskewSetting(int nMergeDist, int nDownSize, int nGaussKernel, int nDilateKernel, int nReservX, int nReservY, int nCannyLow, int nCannyHigh)
        {
            if (IsDevice)
                VideoInput.SetDeviceDeskewSetting(videoHandle, deviceIndex, nMergeDist, nDownSize, nGaussKernel, nDilateKernel, nReservX, nReservY, nCannyLow, nCannyHigh);
            else
                VideoInput.SetImageFileDeskewSetting(videoHandle, nMergeDist, nDownSize, nGaussKernel, nDilateKernel, nReservX, nReservY, nCannyLow, nCannyHigh);
        }
        /// <summary>
        /// SetImageFileDeskewSetting
        /// </summary>
        /// <returns>
        /// [0]:MergeDist
        /// [1]:DownSize
        /// [2]:GaussKernel
        /// [3]:DilateKernel
        /// [4]:ReservX
        /// [5]:ReservY
        /// [6]:CannyLow
        /// [7]:CannyHigh
        /// </returns>
        int[] GetImageDeskewSetting()
        {
            int[] result = new int[8];
            if (IsDevice)
                VideoInput.GetDeviceDeskewSetting(videoHandle,deviceIndex, out result[0], out result[1], out result[2], out result[3], out result[4], out result[5], out result[6], out result[7]);
            else
                VideoInput.GetImageFileDeskewSetting(videoHandle, out result[0], out result[1], out result[2], out result[3], out result[4], out result[5], out result[6], out result[7]);
            return result;
        }
        Image Base64ToImage(string base64String)
        {
            // Convert Base64 String to byte[]
            byte[] imageBytes = Convert.FromBase64String(base64String);
            Image image;
            using (MemoryStream ms = new MemoryStream(imageBytes, 0, imageBytes.Length))
            {                
                // Convert byte[] to Image
                ms.Write(imageBytes, 0, imageBytes.Length);
                image = Image.FromStream(ms, true);
            }
            return image;
        }
        #endregion              

    }

    public delegate void SetDeskewSetting(int nMergeDist, int nDownSize, int nGaussKernel, int nDilateKernel, int nReservX, int nReservY, int nCannyLow, int nCannyHigh);
}
