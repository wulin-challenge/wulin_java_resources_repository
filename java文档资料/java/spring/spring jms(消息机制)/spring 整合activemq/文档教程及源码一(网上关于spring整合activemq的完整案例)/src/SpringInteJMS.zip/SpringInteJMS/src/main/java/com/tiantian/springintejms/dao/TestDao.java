package com.tiantian.springintejms.dao;

import java.util.List;
import java.util.Map;

public interface TestDao {

	public void insert(String name);
	
	public List<Map<String, Object>> findAll();
	
	public Map<String, Object> findById(int id);
	
	
}
