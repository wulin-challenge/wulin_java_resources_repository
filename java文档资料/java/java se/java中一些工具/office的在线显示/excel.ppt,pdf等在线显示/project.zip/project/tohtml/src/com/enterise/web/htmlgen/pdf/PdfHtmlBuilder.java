package com.enterise.web.htmlgen.pdf;

import java.util.List;

import com.enterise.web.htmlgen.HtmlBuilder;

public class PdfHtmlBuilder extends HtmlBuilder {

}