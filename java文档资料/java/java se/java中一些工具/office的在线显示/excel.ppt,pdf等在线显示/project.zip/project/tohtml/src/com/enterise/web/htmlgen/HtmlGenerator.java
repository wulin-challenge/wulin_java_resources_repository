package com.enterise.web.htmlgen;

public interface HtmlGenerator {

	public void generate();
}