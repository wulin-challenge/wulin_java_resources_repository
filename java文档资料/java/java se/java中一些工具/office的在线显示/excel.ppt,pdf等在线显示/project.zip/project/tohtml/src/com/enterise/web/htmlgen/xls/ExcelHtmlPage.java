package com.enterise.web.htmlgen.xls;

import org.dom4j.Element;

import com.enterise.web.htmlgen.HtmlPage;

public class ExcelHtmlPage extends HtmlPage {
	
	private Element currentParagraph;
	
	public Element getCurrentParagraph() {
		return currentParagraph;
	}
	
	public void addParagraph() {
		Element pElem = getBodyElement().addElement("p");
		currentParagraph = pElem;
	}
	
	public void addTextLine(String textLine) {
		Element textLineElem = getCurrentParagraph().addElement("br");
		textLineElem.setText(textLine);
	}
}