package com.enterise.web.htmlgen.xls;

import java.util.List;

import com.enterise.web.htmlgen.HtmlBuilder;

public class ExcelHtmlBuilder extends HtmlBuilder {

}