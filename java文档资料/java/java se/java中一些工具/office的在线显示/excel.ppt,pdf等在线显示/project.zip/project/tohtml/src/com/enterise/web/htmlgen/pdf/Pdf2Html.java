package com.enterise.web.htmlgen.pdf;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.pdfbox.pdmodel.PDDocument;
import org.pdfbox.pdmodel.PDPage;
import org.pdfbox.pdmodel.PDResources;
import org.pdfbox.pdmodel.graphics.xobject.PDXObjectImage;
import org.pdfbox.util.PDFTextStripper;

import com.enterise.web.htmlgen.HtmlGenerator;
/**
 * 这个是转换成了图片  pdf转换成html没有什么需求吧   如果需要在线看的话直接转换成swf就行啊
 * @author LIMING
 *
 */
public class Pdf2Html implements HtmlGenerator {

	private PDDocument document;
	PdfHtmlBuilder pdfHtmlBuilder = new PdfHtmlBuilder();
	private List pages;
	
	public Pdf2Html(InputStream pdfFileInputStream) {
		try {
			document = PDDocument.load(pdfFileInputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void generate() {
		
		int numberOfPages = document.getNumberOfPages();
		List pages = document.getDocumentCatalog().getAllPages();
		
		PDFTextStripper pdfTextStripper = null;
		try {
			pdfTextStripper = new PDFTextStripper();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		for (int i = 1; i <= numberOfPages; i++) {
			
			pdfHtmlBuilder.addHtmlPage(new PdfHtmlPage());
			PdfHtmlPage page = (PdfHtmlPage)pdfHtmlBuilder.getCurrentPage();
						
			pdfTextStripper.setStartPage(i);
			pdfTextStripper.setEndPage(i);
			String text = null;
			try {
				text = pdfTextStripper.getText(document);
			} catch (IOException e) {
				e.printStackTrace();
			}
			Reader reader = new StringReader(text);
			BufferedReader bufferedReader = new BufferedReader(reader);
			try {
				String textLine = null;
				while ((textLine = bufferedReader.readLine()) != null) {
					page.addTextLine(textLine);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			PDPage pDPage = (PDPage)pages.get(i - 1);
			PDResources resources = pDPage.getResources();
			try {
				Map images;
				images = resources.getImages();
				if( images != null )
	            {
	                Iterator imageIter = images.keySet().iterator();
	                while( imageIter.hasNext() )
	                {
	                    String key = (String)imageIter.next();
	                    PDXObjectImage image = (PDXObjectImage)images.get( key );
	                    page.addPicture(image, "png");
	                }
	            }
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
        try {
			document.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		pdfHtmlBuilder.writeToFile();
	}
	
	public static void main(String[] args) {
		InputStream is = null;
		try {
			is = new FileInputStream("F:/111.pdf");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Pdf2Html pdf2Html = new Pdf2Html(is);
		pdf2Html.generate();
	}
}