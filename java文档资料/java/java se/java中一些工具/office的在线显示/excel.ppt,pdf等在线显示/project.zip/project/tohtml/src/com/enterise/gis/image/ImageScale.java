package com.enterise.gis.image;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

/**
 * 图片转换成图片
 * @author LIMING
 * @link QQ:1151143484 
 */
public class ImageScale {
    
	
	private int preferredWidth;//首选宽度（最合适宽度）
	private int preferredHeight;//高度...
	
	/**
	 * 构造方法
	 * @param preferredWidth
	 * @param preferredHeight
	 */
	public ImageScale(int preferredWidth, int preferredHeight) {
		this.preferredWidth = preferredWidth;
		this.preferredHeight = preferredHeight;
	}
	
	
	public BufferedImage scale(BufferedImage srcImg) {
		//获取需要转换图片的 宽 高 
		int srcImgWidth = srcImg.getWidth();
		int srcImgHeight = srcImg.getHeight();
		//看一下子 
		System.out.println(srcImgWidth+":"+srcImgHeight);
		
		float scale;//比例
		//如果小于需要转换的宽 高  就直接把原图返回去
		if (srcImgWidth <= preferredWidth && srcImgHeight <= preferredHeight) {
			return srcImg;
		}
		//如果图片的高小于需要转换图片的高
		if (srcImgWidth > preferredWidth && srcImgHeight <= preferredHeight) {
			scale = (float)preferredWidth / (float)srcImgWidth;
			int destImgWidth = preferredWidth;
			int destImgHeight = (int)Math.floor(preferredHeight * scale);
			return createImage(srcImg, destImgWidth, destImgHeight);
		}
		//如果图片的宽小于需要转换图片的宽
		if (srcImgWidth <= preferredWidth && srcImgHeight > preferredHeight) {
			scale = (float)preferredHeight / (float)srcImgHeight;
			int destImgWidth = (int)Math.floor(preferredWidth * scale);
			int destImgHeight = preferredHeight;
			return createImage(srcImg, destImgWidth, destImgHeight);
		}
		// 都小于
		if (srcImgWidth > preferredWidth && srcImgHeight > preferredHeight) {
			float scale1 = (float)preferredWidth / (float)srcImgWidth;
			float scale2 = (float)preferredHeight / (float)srcImgHeight;
			//找最小比例
			if (scale1 <= scale2) {
				scale = scale1;				
			} else {
				scale = scale2;
			}
			int destImgWidth = (int)Math.floor(srcImgWidth * scale);
			int destImgHeight = (int)Math.floor(srcImgHeight * scale);
			//按照比例计算出的宽 高 进行等比缩放
			return createImage(srcImg, destImgWidth, destImgHeight);
		}
		return null;
	}
	private BufferedImage createImage(BufferedImage srcImg, int destImgWidth, int destImgHeight) {
		BufferedImage destImg = new BufferedImage(destImgWidth, destImgHeight, 
				BufferedImage.TYPE_INT_RGB);
		Graphics g = destImg.getGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, destImgWidth, destImgHeight);
		g.drawImage(srcImg, 0, 0, destImgWidth, destImgHeight, null);
		g.dispose();		
		return destImg;
	}
	public static void main(String[] args) {
		try {
			BufferedImage srcImg = ImageIO.read(new File("f:/test2.png"));
			ImageScale imageScale = new ImageScale(500, 500);
			BufferedImage destImg = imageScale.scale(srcImg);
			ImageIO.write(destImg, "png", new File("f:/test3.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}