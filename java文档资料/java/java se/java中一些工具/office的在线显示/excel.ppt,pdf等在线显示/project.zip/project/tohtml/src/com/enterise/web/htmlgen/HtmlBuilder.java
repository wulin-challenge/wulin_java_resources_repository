package com.enterise.web.htmlgen;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
/**
 * @author LIMING
 * @link QQ:1151143484 
 */
public class HtmlBuilder {

	private List pageList;
	private HtmlPage currentPage;
	private String documentId;
	private int pictureCount = 0;

	public HtmlBuilder() {
		pageList = new ArrayList();
		documentId = String.valueOf(System.currentTimeMillis());
	}

	public void addHtmlPage(HtmlPage htmlPage) {
		pageList.add(htmlPage);
		htmlPage.setDocumentId(documentId);
		currentPage = htmlPage;
	}

	public HtmlPage getCurrentPage() {
		return currentPage;
	}

	public void writeToFile() {
		Iterator iter = pageList.iterator();
		int i = 0;
		while (iter.hasNext()) {
			i++;
			HtmlPage page = (HtmlPage) iter.next();
			String pageId = documentId + "-" + i;
			Pagination pagination = new Pagination(documentId, i, pageList.size());
			page.addPagination(pagination);
			try {
				File htmlFile = new File("f:/test/"+pageId + ".html");
				Writer writer = new FileWriter(htmlFile);
				writer.write(page.getPageContent());
				writer.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public List getPageList() {
		return pageList;
	}
	
	public String getDocumentId() {
		return documentId;
	}
}