import java.io.*;
import java.text.ParseException;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 * ����xls�ļ���et �ļ���
 * @author sunzh
 * 2010-11-23
 *
 */
public class poicreaxls {
	public static void main(String[] args) throws ParseException, IOException {
		HSSFWorkbook wb = new HSSFWorkbook(); 
	    HSSFSheet sheet = wb.createSheet("new sheet1"); 
	    for(int i=0;i<15;i++){
	    	
	    	HSSFRow row = sheet.createRow((short)i); 
	    	row.createCell((short)1).setCellValue("����"); 
	    	row.createCell((short)3).setCellValue("This is a string"); 
	    }
//	    FileOutputStream fileOut = new FileOutputStream("D:/workbook.et"); 
	    FileOutputStream fileOut = new FileOutputStream("D:/workbook.xls"); 
	    wb.write(fileOut); 
	    fileOut.close(); 
	    System.out.println("Ok.");
	}
}
