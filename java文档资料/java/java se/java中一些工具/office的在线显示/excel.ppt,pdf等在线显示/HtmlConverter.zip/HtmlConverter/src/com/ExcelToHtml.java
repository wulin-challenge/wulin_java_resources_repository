package com;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFClientAnchor;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFPalette;
import org.apache.poi.hssf.usermodel.HSSFPicture;
import org.apache.poi.hssf.usermodel.HSSFPictureData;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFShape;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.PictureData;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddress;

public class ExcelToHtml {

 public ExcelToHtml() {
  
 }
    
 private int sumWidth;
 private Map<String,String>map;
 
 
 public static void writeFile(String content, String srcPath, String targetPath) {  
     FileOutputStream fos = null;  
     BufferedWriter bw = null;  
     try {  
         File file = new File(targetPath);  
         fos = new FileOutputStream(file);  
         bw = new BufferedWriter(new OutputStreamWriter(fos,"UTF-8"));  
         bw.write(content);  
     } catch (FileNotFoundException fnfe) {  
         fnfe.printStackTrace();  
     } catch (IOException ioe) {  
         ioe.printStackTrace();  
     } finally {  
         try {  
             if (bw != null)  
                 bw.close();  
             if (fos != null)  
                 fos.close();  
         } catch (IOException ie) {  
         }  
     }  
 }  
 
 public static void main(String args[]) throws Exception {
	  String filepath = "C://Temp//doc4.xls";
	  String outputFile = "C://Temp//doc4.html" ;
	  String folder = "C://Temp" ;
	  convertToHtml(filepath, outputFile, folder) ;
 }
 
 public static void convertToHtml(String fileName, String outPutFile,final String folder)
 	throws Exception {
	  ExcelToHtml eu = new ExcelToHtml();
	  StringBuffer htmlbuf = getHmtlBuf(eu,fileName);
	  writeFile(htmlbuf.toString(),fileName,outPutFile);
}

 private static StringBuffer getHmtlBuf(ExcelToHtml eu, String filepath){
	 HSSFWorkbook workbook = eu.readExcelFile(filepath);
	  String exceltitle = eu.getFirstRowContent(workbook, 0);
	  try {
		eu.getPicPosition(workbook);
	} catch (Exception e) {
		e.printStackTrace();
	}
	  StringBuffer htmlbuf = new StringBuffer("");
	  htmlbuf.append(eu.headerHtmlStart(exceltitle));
	  htmlbuf.append(eu.headerHtmlEnd());
	  htmlbuf.append(eu.bodyHtml(workbook, 0));
	  htmlbuf.append(eu.bodyHtmlEnd());
	  return htmlbuf;
 }
 private StringBuffer headerHtmlStart(String title) {
	  StringBuffer sb = new StringBuffer("");
	  sb.append("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">");
	  sb.append("<html>\n");
	  sb.append("<head>\n");
	  sb.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n");
	  sb.append("<META HTTP-EQUIV=\"pragma\" CONTENT=\"no-cache\">\n");
	  sb.append("<META HTTP-EQUIV=\"Cache-Control\" CONTENT=\"no-cache, must-revalidate\">\n");
	  sb.append("<META HTTP-EQUIV=\"expires\" CONTENT=\"0\">\n");
	  sb.append("<title>" + title + "</title>\n");
	  return sb;
 }

 private StringBuffer headerHtmlEnd() {
	  StringBuffer sb = new StringBuffer("");
	  sb.append("</head>\n");
	  sb.append("<body>\n");// ����ҳ���ˢ����
	
	  return sb;
 }


 private StringBuffer bodyHtml(HSSFWorkbook workbook, int sheetindex) {
	  HSSFSheet sheet = workbook.getSheetAt(sheetindex);
	 
	  int lastRowNum = sheet.getLastRowNum();
	  HSSFRow row1 = null;
	  HSSFCell cell1 = null;
	  int lastColNums=0;
	  for (int rowNum = sheet.getFirstRowNum(),i=0; rowNum <= lastRowNum; rowNum++,i++) {
		  row1 = (HSSFRow) sheet.getRow(rowNum);
		  for (int colNum = 0,j=0; colNum < lastColNums; colNum++,j++) {
		    cell1 = row1.getCell(colNum);
		    int tdwidth = sheet.getColumnWidth(colNum) / 32;
		    //��ͷ���ܵ�width
		    // System.out.println("tdwidth="+tdwidth);
		     sumWidth+=tdwidth;  
		     this.setSumWidth(sumWidth);
		    }
		  break;
	 }
 
	 StringBuffer sb = new StringBuffer("");
	  sb.append("<table border width=\""+this.getSumWidth()+"px\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n");
	  sb.append("<thead>  \n");
	  sb.append("</thead>\n");
	  sb.append("<tbody>\n");
	  sb.append(excelToHtmlJs(workbook, sheetindex,lastRowNum));
	  sb.append("</tbody>\n");
	  sb.append("</table>\n");
	  return sb;
 }

 private StringBuffer bodyHtmlEnd() {
	  StringBuffer sb = new StringBuffer("");
	  sb.append("</body>\n");
	  sb.append("</html>\n");
	  return sb;
 }

 //��ȡtd�Ŀ���
 private int getTdWidth(Sheet sheet, int startCol, int endCol) {
  int tdwidth = 0;
  for (int i = startCol; i <= endCol; i++) {
   int tempwidth = sheet.getColumnWidth(i) / 32;
   tdwidth = tdwidth + tempwidth;

  }
  return tdwidth;
 }

 
 
 private StringBuffer excelToHtmlJs( HSSFWorkbook workbook, int sheetindex,int lastRowNum) {
	  HSSFSheet sheet = workbook.getSheetAt(sheetindex);
	  Map<String, String> map[] = getRowSpanColSpanMap(sheet);
	  HSSFRow row = null;

	  HSSFCell cell = null;
	  List rangennumList = this.getRangeRows(sheet);
	  int rangenum = rangennumList == null ? 0 : rangennumList.size();
  
	  if(rangenum==2){
	   rangenum+=1;
	  }
	  if(rangenum==3){
	    rangenum+=1;
	  }
	  
	  if(rangenum==7){
	     rangenum-=2;
	   }
	   if (rangenum==12) {
	    	  rangenum-=6;
	    }
      if (rangenum==13) {
    	  rangenum-=7;
      }
      if (rangenum==8) {
      rangenum-=3;
      }
      if(rangenum==11){
       rangenum-=5;
      }
      if(rangenum==10){
       rangenum-=4;
      }
      if(rangenum==9){
       rangenum-=3;
      }
      if(rangenum==14){
       rangenum-=8;
      }
      if(rangenum==18){
       rangenum/=3;
      }
      if(rangenum==15){
       rangenum-=9;
      }
      if(rangenum==16){
       rangenum-=10;
      }
      if(rangenum==17){
       rangenum-=12;
      }
  
      StringBuffer strbuf = new StringBuffer("");
      
      short borderColor = 0;
      short bordertop = 0;
      short borderleft = 0;
      short borderright = 0;
      short borderbottom = 0;
      short colorbottom = 0;
      short colortop = 0;
      short colorleft = 0;
      short colorright = 0;
    
      String borstyletop = "";
      String borstyleleft = "";
      String borstyleright = "";
      String borstylebottom = "";
      String bortopcolor = "";
      String borleftcolor = "";
      String borrightcolor = "";
      String borbottomcolor = "";
	     
      for (int rowNum = sheet.getFirstRowNum(); rowNum <= lastRowNum; rowNum++) {

		   row = (HSSFRow) sheet.getRow(rowNum);
		 
		   if (row == null) {
			   strbuf.append("<tr><td > &nbsp;</td></tr>");
			   continue;
		   }
		   
		   
		   float heightval = row.getHeightInPoints()+8f;
		   strbuf.append("<tr height=\""+heightval+"px\">");
		   int lastColNum = row.getLastCellNum();
		   for (int colNum = 0; colNum < lastColNum; colNum++) {
			   
		    	 borderColor = 0;    
		    	 bordertop = 0;      
		    	 borderleft = 0;     
		    	 borderright = 0;    
		    	 borderbottom = 0;   
		    	 colorbottom = 0;    
		    	 colortop = 0;       
		    	 colorleft = 0;      
		    	 colorright = 0;     
		    	                      
		    	 borstyletop = "";   
		    	 borstyleleft = "";  
		    	 borstyleright = ""; 
		    	 borstylebottom = "";
		    	 bortopcolor = "";   
		    	 borleftcolor = "";  
		    	 borrightcolor = ""; 
		    	 borbottomcolor = "";
				cell = row.getCell(colNum);
				int tdwidth = sheet.getColumnWidth(colNum) / 32;
				if (cell == null) {
					cell = row.createCell(colNum);
					cell.setCellValue("");
					//strbuf.append("<td>&nbsp;</td>");
					//continue;
				} 
				HSSFCellStyle cellStyle = cell.getCellStyle();
				cellStyle.setWrapText(true);      
				cell.setCellStyle(cellStyle); 
				String stringValue = getCellValue(cell);
				
			    if (map[0].containsKey(rowNum + "," + colNum)) {
				     String pointString = map[0].get(rowNum + "," + colNum);
				     map[0].remove(rowNum + "," + colNum);
				     int bottomeRow = Integer.valueOf(pointString.split(",")[0]);
				     int bottomeCol = Integer.valueOf(pointString.split(",")[1]);
				     
				     int rowSpan = bottomeRow - rowNum + 1;
				     int colSpan = bottomeCol - colNum + 1;
				     strbuf.append("<td width=\""
				       + getTdWidth(sheet, colNum, bottomeCol)
				       + "px\" rowspan=\"" + rowSpan + "\" colspan=\""
				       + colSpan + "\" ");
				     
				    
			    	 HSSFRow tempRow = (HSSFRow) sheet.getRow(bottomeRow);
			    	 if( rowSpan>1 && tempRow!=null ){
			    		 HSSFCell tempcell = tempRow.getCell(colNum);
			    		 if( tempcell!=null ){
				    		 borderbottom = tempcell.getCellStyle().getBorderBottom();   
				    		 colorbottom = tempcell.getCellStyle().getBottomBorderColor();  
				    	 }
			    	 } 
			    	 
			    	 if( colSpan>1 ){
			    		 HSSFCell tempcell = row.getCell(bottomeCol);
			    		 if( tempcell!=null ){
				    		 borderright = tempcell.getCellStyle().getBorderRight();   
				    		 colorright = tempcell.getCellStyle().getRightBorderColor(); 
				    		// System.out.println("rowNum="+(rowNum)+"\tcolNum="+(bottomeCol)+"\tborderright="+borderright);
				    	 }
			    	 }
			    	 
			      //System.out.print(">>>>"+getTdWidth(sheet,colNum,bottomeCol)+",");
			    } else if (map[1].containsKey(rowNum + "," + colNum)) {//���ϲ����ĵ�Ԫ��
			    	map[1].remove(rowNum + "," + colNum);
			    	if( rowNum == 20 && colNum ==3 ){
			    		//System.out.println("rowNum=\t"+rowNum+"\tcolNum="+colNum+">>>>\tborderright="+cell.getCellStyle().getBorderRight());
			    	}
			    	continue;
			    } else {
			    	strbuf.append("<td width=\"" + tdwidth + "px\" ");
			    }
	     
		    if (cellStyle != null) {
		
		    	
		    	short alignment = cellStyle.getAlignment();
		
		    	strbuf.append("align=\"" + convertAlignToHtml(alignment)+ "\" ");
		
		    	short verticalAlignment = cellStyle.getVerticalAlignment();
		    	strbuf.append("valign=\"" + convertVerticalAlignToHtml(verticalAlignment) + "\" ");
		
		    	HSSFFont hf = cellStyle.getFont(workbook);
		
		    	short boldWeight = hf.getBoldweight();
		
		    	short fontColor = hf.getColor();
		
		    	strbuf.append("style=\"");
		
		    	HSSFPalette palette = workbook.getCustomPalette(); // ��HSSFPalette���������ɫ�Ĺ��ʱ�׼��ʽ
		
		    	HSSFColor hc = palette.getColor(fontColor);
		      //System.out.println("=="+boldWeight);
		    	strbuf.append("font-weight:" + boldWeight + ";"); //����Ӵ�
		
		    	//sb.append("font-size: " + hf.getFontHeight()/2 + "%;");
		     // //�����С
			     strbuf.append("font-size: " + hf.getFontHeightInPoints()+ "pt;");
			     strbuf.append("font-family:" + hf.getFontName() + ";");
			
			     String fontColorStr = convertToStardColor(hc);
			     if (fontColorStr != null && !"".equals(fontColorStr.trim())) {
			    	 strbuf.append("color:" + fontColorStr + ";"); // ������ɫ
			     }
		
			     short bgColor = cellStyle.getFillForegroundColor();
			
			     hc = palette.getColor(bgColor);
			
			     String bgColorStr = convertToStardColor(hc);
			
			     if (bgColorStr != null && !"".equals(bgColorStr.trim())) {
			    	 strbuf.append("background-color:" + bgColorStr + ";"); // ������ɫ
			     }
		
			     
			     bordertop = cellStyle.getBorderTop();                                               
			     borderleft = cellStyle.getBorderLeft();                                             
			     if( borderright == 0 ) borderright = cellStyle.getBorderRight();  
			     if( borderbottom == 0 ) borderbottom = cellStyle.getBorderBottom();   
			     if( colorbottom == 0 ) colorbottom = cellStyle.getBottomBorderColor();     
			     colortop = cellStyle.getTopBorderColor();                                           
			     colorleft = cellStyle.getLeftBorderColor();                                         
			     
			     if( colorright == 0 ) colorright = cellStyle.getRightBorderColor();                                       
			                                                                                               
			     borstyletop = this.convertBorderStyleToHtml(bordertop);                            
			     borstyleleft = this.convertBorderStyleToHtml(borderleft);                          
			     borstyleright = this.convertBorderStyleToHtml(borderright);                        
			     borstylebottom = this.convertBorderStyleToHtml(borderbottom);                      
			     bortopcolor = this.convertBorderColorToHtml(colortop);                             
			     borleftcolor = this.convertBorderColorToHtml(colorleft);                           
			     borrightcolor = this.convertBorderColorToHtml(colorright);                         
			     borbottomcolor = this.convertBorderColorToHtml(colorbottom);                       
			     strbuf.append("border-top:" + this.getBorderStyle(borstyletop, bortopcolor)+ ";");
			     strbuf.append("border-left:"+ this.getBorderStyle(borstyleleft, borleftcolor) + ";");
			     strbuf.append("border-right:" + this.getBorderStyle(borstyleright, borrightcolor) + ";");
			     strbuf.append("border-bottom:"+ this.getBorderStyle(borstylebottom,borbottomcolor) + ";");
			     
			  // 	System.out.println(rowNum+"\t"+colNum+"\tborder-right:============"+ borstyleright+"\t"+stringValue+"\ttype=="+cell.getCellType());
		     // sb.append("border:" +
		     // this.convertBorderStyleToHtml(bordertop)+" "+
		     // convertBorderColorToHtml(colorbottom)+ ";");
		     // String
		
			     hc = palette.getColor(borderColor);
		
			     String borderColorStr = convertToStardColor(hc);
		
			     if (borderColorStr != null && !"".equals(borderColorStr.trim())) {
			
			     }
		
			     strbuf.append("\" ");
		    }
	
		    
		    strbuf.append(">");
		    if (stringValue == null || "".equals(stringValue.trim())) {
		    	String picStr = getIncludePicStr(rowNum,colNum,workbook);
		    	strbuf.append(picStr);
		    	if( picStr.trim().length()<=0){
		    		strbuf.append(" &nbsp; ");
		    	}
		    } else  {
		    	strbuf.append(stringValue);
		                  // System.out.println("StringValue="+stringValue);
		        //strbuf.append(stringValue.replaceAll("\\s*", "")+" ");
		    /* strbuf.append(" "
		       + stringValue.replace(String.valueOf((char) 160),
		         "&nbsp;") + " ");*/
		
		    }
		  // System.out.println(rowNum+"\t"+colNum+"\t"+stringValue); 
	     strbuf.append("</td>");
	
	   }
   
   strbuf.append("</tr>");


  }

  // sb.append("</table>\n");
  //System.out.println("sumwidth="+this.getSumWidth());//ȡ���ܿ��ȵ�����
  

  // System.out.println(sb.toString());
  return strbuf;
 }

 @Override
 public String toString() {
  return "ExcelUtils []";
 }


 @SuppressWarnings("unchecked")
 private Map<String, String>[] getRowSpanColSpanMap(Sheet sheet) {

  Map<String, String> map0 = new HashMap<String, String>();//û�кϲ��ĵ�Ԫ��
  Map<String, String> map1 = new HashMap<String, String>();//�ϲ��ĵ�Ԫ��

  int mergedNum = sheet.getNumMergedRegions();
  // System.out.println("mergedNum="+mergedNum);
  CellRangeAddress range = null;

  for (int i = 0; i < mergedNum; i++) {

   range = sheet.getMergedRegion(i);

   int topRow = range.getFirstRow();

   int topCol = range.getFirstColumn();

   int bottomRow = range.getLastRow();

   int bottomCol = range.getLastColumn();

   map0.put(topRow + "," + topCol, bottomRow + "," + bottomCol);

   // System.out.println(topRow + "," + topCol + "," + bottomRow + ","
   // + bottomCol);

   int tempRow = topRow;

   while (tempRow <= bottomRow) {

    int tempCol = topCol;

    while (tempCol <= bottomCol) {

     map1.put(tempRow + "," + tempCol, "");

     tempCol++;
    }

    tempRow++;
   }

   map1.remove(topRow + "," + topCol);

  }

  Map[] map = { map0, map1 };

  return map;
 }

 private String convertAlignToHtml(short alignment) {

  String align = "left";

  switch (alignment) {

  case HSSFCellStyle.ALIGN_LEFT:
   align = "left";
   break;
  case HSSFCellStyle.ALIGN_CENTER:
   align = "center";
   break;
  case HSSFCellStyle.ALIGN_RIGHT:
   align = "right";
   break;

  default:
   break;
  }

  return align;
 }

 private String getBorderStyle(String bortype, String borcolor) {
  String borstyle = "";
  if ("thin".equals(bortype)) {
   borstyle = "1px solid " + borcolor;
  } else if ("medium".equals(bortype)) {
   borstyle = "2px solid " + borcolor;
  } else if ("double".equals(bortype)) {
   borstyle = "double 2.25pt " + borcolor;
  } else if ("dotted".equals(bortype)) {
   borstyle = "1px dotted " + borcolor;
  } else if ("dashed".equals(bortype)) {
   borstyle = "1px dashed " + borcolor;
  }
  return borstyle;
 }

 private String convertBorderStyleToHtml(short bordertype) {
  String type = "none";
  switch (bordertype) {

  case HSSFCellStyle.BORDER_THIN:
   type = "thin";
   break;
  case HSSFCellStyle.BORDER_DOTTED:
   type = "dotted";
   break;
  case HSSFCellStyle.BORDER_DASHED:
   type = "dashed";
   break;
  case HSSFCellStyle.BORDER_NONE:
   type = "none";
   break;
  case HSSFCellStyle.BORDER_MEDIUM:
   type = "medium";
   break;
  case HSSFCellStyle.BORDER_DOUBLE:
   type = "double";
   break;

  default:
   break;
  }

  return type;
 }

 private String convertBorderColorToHtml(short bordercolor) {
  String type = "black";

  switch (bordercolor) {
  case HSSFColor.BLACK.index:
   type = "black";
   break;
  case HSSFColor.BLUE.index:
   type = "blue";
   break;
  case HSSFColor.RED.index:
   type = "red";
   break;

  default:
   break;
  }

  return type;
 }

 private String convertVerticalAlignToHtml(short verticalAlignment) {

  String valign = "middle";

  switch (verticalAlignment) {

  case HSSFCellStyle.VERTICAL_BOTTOM:
   valign = "bottom";
   break;
  case HSSFCellStyle.VERTICAL_CENTER:
   valign = "center";
   break;
  case HSSFCellStyle.VERTICAL_TOP:
   valign = "top";
   break;
  default:
   break;
  }

  return valign;
 }

 private String convertToStardColor(HSSFColor hc) {
  StringBuffer sb = new StringBuffer("");
  if (hc != null) {

   if (HSSFColor.AUTOMATIC.index == hc.getIndex()) {

    return null;
   }

   sb.append("#");

   for (int i = 0; i < hc.getTriplet().length; i++) {
    sb.append(fillWithZero(Integer.toHexString(hc.getTriplet()[i])));
   }
  }
  return sb.toString();
 }

 private String fillWithZero(String str) {

  if (str != null && str.length() < 2) {

   return "0" + str;
  }
  return str;
 }

 /**
  * ��ȡCell������
  * 
  * @param cell
  * @return
  */
 public String getStringCellValue(HSSFCell cell) {
  String cellvalue = "";
  if (cell == null) {
   return "";
  }
  switch (cell.getCellType()) {
  case HSSFCell.CELL_TYPE_STRING:
   cellvalue = cell.getStringCellValue();
   break;
  case HSSFCell.CELL_TYPE_NUMERIC:
   cellvalue = String.valueOf(cell.getNumericCellValue());
   break;
  case HSSFCell.CELL_TYPE_BOOLEAN:
   cellvalue = String.valueOf(cell.getBooleanCellValue());
   break;
  case HSSFCell.CELL_TYPE_BLANK:
   cellvalue = "";
   break;
  default:
   cellvalue = "";
   break;
  }
  if (cellvalue=="") {
   return "";
  }
  return cellvalue;
 }

 private String getCellValue(HSSFCell cell) {
	 if( cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC ){
		 //Date tjnyDate=HSSFDateUtil.getJavaDate(Double.parseDouble(strTJNY));
		 if(HSSFDateUtil.isCellDateFormatted(cell)) {  
            Date date = HSSFDateUtil.getJavaDate(cell.getNumericCellValue());  
            return new SimpleDateFormat("yyyy/m/d h:mm").format(date);  
		 }else{
			 DecimalFormat format = new DecimalFormat("#0.##");
			 return format.format(cell.getNumericCellValue());
		 }
	 }else if( cell.getCellType() == HSSFCell.CELL_TYPE_FORMULA){
		// �жϵ�ǰ��cell�Ƿ�ΪDate
         if (HSSFDateUtil.isCellDateFormatted(cell)) {
            // �����Date������ȡ�ø�Cell��Dateֵ
            Date date = cell.getDateCellValue();
            // ��Dateת���ɱ��ظ�ʽ���ַ���
            return  cell.getDateCellValue().toLocaleString();
         }else{// ����Ǵ�����
            // ȡ�õ�ǰCell����ֵ
        	 DecimalFormat format = new DecimalFormat("#0.##");
			 return format.format(cell.getNumericCellValue());
         }

	 }else if( cell.getCellType() ==  HSSFCell.CELL_TYPE_STRING ){
		 return cell.getStringCellValue();
	 }else{
		 return ""; 
	 }
 }

 /**
  * ��ȡexcel
  * 
  * @param filepath
  *            excel�ļ���ַ
  * @return HSSFWorkbook
  */
 public HSSFWorkbook readExcelFile(String filepath) {
	  HSSFWorkbook workbook = null;
		  try {
		   FileInputStream input = new FileInputStream(new File(filepath));
		   POIFSFileSystem fs = new POIFSFileSystem(input);
		   workbook = new HSSFWorkbook(fs);
		  } catch (Exception e) {
		   e.printStackTrace();
		  }
	  return workbook;
 }

 /**
  * ��ȡĳSheet����һ�е�����
  * 
  * @param workbook
  * @param sheetindex
  * @return
  */
 public String getFirstRowContent(HSSFWorkbook workbook, int sheetindex) {
	  String exceltitle = "";
	  if (workbook != null) {
		   HSSFSheet sheet = workbook.getSheetAt(sheetindex);
		   int firstrownum = sheet.getFirstRowNum();
		   HSSFRow row = sheet.getRow(firstrownum);
		   short fcellnum = row.getFirstCellNum();
		   short lcellnum = row.getLastCellNum();
		   for (int j = fcellnum; j < lcellnum; j++) {
			    HSSFCell cell = row.getCell(j);
			    exceltitle += getStringCellValue(cell);
		   }
	  }
	  return exceltitle;
 }

 public CellRangeAddress getRange(HSSFSheet sheet) {
  if (sheet != null) {
	   int rangenum = sheet.getNumMergedRegions();
	   for (int m = 0; m < rangenum; m++) {
		   CellRangeAddress range = sheet.getMergedRegion(m);
	   }
  }
  	return null;
 }

 public List getRangeRows(HSSFSheet sheet) {
  if (sheet != null) {
   int rangenum = sheet.getNumMergedRegions();//�ҵ���ǰsheet��Ԫ���й��ж��ٸ��ϲ�����  
   //System.out.println("RangenNum="+rangenum);
   ArrayList list = new ArrayList();
   if (rangenum > 0) {
    for (int i = 0; i < rangenum; i++) {
     CellRangeAddress range = sheet.getMergedRegion(i);//һ���ϲ���Ԫ����� CellRangeAddress   
     list.add(range.getFirstRow());
     list.add(range.getLastRow());
     list.add(range.getLastColumn());
     list.add(range.getFirstColumn());
    
     // range.
     // range.isInRange(rowInd, colInd)()

    }
    Collections.sort(list);
    this.removeDuplicateWithOrder(list);
    return list;
   }
  }
  return null;
 }
 
 public int getSumWidth(int sum){
  return sum;
 }

 /** List order maintained **/
 public static void removeDuplicateWithOrder(ArrayList arlList) {
  Set set = new HashSet();
  List newList = new ArrayList();
  for (Iterator iter = arlList.iterator(); iter.hasNext();) {
   Object element = iter.next();
   if (set.add(element))
    newList.add(element);
  }
  arlList.clear();
  arlList.addAll(newList);
 }

 public java.awt.Color toAWTColor(int R, int G, int B, int A) {
  return new java.awt.Color(R, G, B, A);
 }

 public int toRGB(int R, int G, int B) {
  return R << 16 | G << 8 | B;
 }

 public String getTdString(HSSFCell cell) {
  String tdstr = "";

  return tdstr;
 }
 
 public int getSumWidth() {
  return sumWidth;
 }

 public void setSumWidth(int sumWidth) {
  this.sumWidth = sumWidth;
 }

 
 public Map<String, String> getMap() {
	return map;
}

public void setMap(Map<String, String> map) {
	this.map = map;
}

private  String getIncludePicStr( int rowNum,int colNum,HSSFWorkbook workbook ){
	 String str = "";
	 try {
		if( map.get(rowNum+":"+colNum)!=null ){
			str = "<img style=\"vertical-align:middle\" align=\"absmiddle\" src=\""+map.get(rowNum+":"+colNum)+"\">";
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	 return str;
 }
 
 //��ȡͼƬ
 private void getPicPosition(HSSFWorkbook workbook) throws Exception{
	 map = new HashMap<String,String>();
	 List<HSSFPictureData> pictures = workbook.getAllPictures();  
	 HSSFSheet sheet = (HSSFSheet) workbook.getSheetAt(0);  
	 int i = 0;  
	 if(sheet.getDrawingPatriarch() != null 
			 && sheet.getDrawingPatriarch().getChildren() != null){
	     for (HSSFShape shape : sheet.getDrawingPatriarch().getChildren()) {  
	         HSSFClientAnchor anchor = (HSSFClientAnchor) shape.getAnchor();  
	         if (shape instanceof HSSFPicture) {  
	             HSSFPicture pic = (HSSFPicture) shape;  
	             int row = anchor.getRow1();  
	             System.out.println(i + "--->" + anchor.getRow1() + ":" + anchor.getCol1());  
	             int pictureIndex = pic.getPictureIndex()-1;  
	             HSSFPictureData picData = pictures.get(pictureIndex);  
	             System.out.println(i + "--->" + pictureIndex);  
	             String path = savePic(row, picData);  
	             map.put(anchor.getRow1() + ":" + anchor.getCol1(), path);
	         }  
	         i++;  
	     }  
	 }
 }
 
 private static String savePic(int i, PictureData pic) throws Exception {  
	  
     String ext = pic.suggestFileExtension();  
     String fileName = "f://test//pict" ;
     byte[] data = pic.getData();  
     if (ext.equals("jpeg")) {  
    	 fileName += i + ".jpg";
     }  
     if (ext.equals("png")) {  
    	 fileName += i + ".png";
     }  
     FileOutputStream out = new FileOutputStream(fileName);  
     out.write(data);  
     out.close();  
     return fileName;
 }  

}



