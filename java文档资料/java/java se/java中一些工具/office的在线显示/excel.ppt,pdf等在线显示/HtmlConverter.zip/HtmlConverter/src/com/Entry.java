package com ;

/**
 * @author loujian
 *
 */
public class Entry {

	public static void main(String[] args) {
		String inputFileName = "C://Temp//doc3.wps" ;
		String outputFileName = "C://Temp//doc3//doc3.html" ;
		String tmpFolder = "C://Temp//doc3//pic" ;
		
		double begin = System.currentTimeMillis() ;
		String result = toHtml(inputFileName,outputFileName,tmpFolder) ;
		System.out.println("result:" + result 
				+ "|time:"  + (System.currentTimeMillis() - begin)/1000 + "s") ;
	}

	/**
	 * @param inputFileName ȫ·��
	 * @param outputFileName ȫ·��
	 * @param tmpFolder ȫ·��������޷ָ���
	 * @return
	 */
	private static String toHtml(String inputFileName, String outputFileName,
			String tmpFolder) {
		
		if(inputFileName != null && inputFileName.trim().length() > 0
				&& outputFileName != null && outputFileName.trim().length() > 0
				&& tmpFolder != null && tmpFolder.trim().length() > 0){
			
			int index = inputFileName.lastIndexOf(".") ;
			
			if(index != -1){
				String suffix = inputFileName.substring(index + 1, inputFileName.length()) ;
				
				if(suffix != null && suffix.trim().length() > 0){
					if(suffix.equals("xls") || suffix.equals("et")){
						
						try {  
					           ExcelToHtml.convertToHtml(inputFileName,
					        		   outputFileName,tmpFolder);
					           return "success" ;
					       } catch (Exception e) {  
					           e.printStackTrace();
					           return "FAIL!!!" + e.getMessage() ;
					       }  
					}else if(suffix.equals("doc") || suffix.equals("wps")){
						
						   try {  
					           WordToHtml.convertToHtml(inputFileName,
					        		   outputFileName,tmpFolder);
					           return "success" ;
					       } catch (Exception e) {  
					           e.printStackTrace();
					           return "FAIL!!!" + e.getMessage() ;
					       }  
					}else{
						
						return "��֧�ִ����ļ����ͣ�" ;
					}
				}else{
					
					return "�ļ������Ϸ������ļ���׺��" ;
				}
			}else{
				
				return "�ļ������Ϸ���δ�ҵ��ļ���׺��" ; 
			}
		}else{
			
			return "�������Ϸ���" ;
		}
	}
}
