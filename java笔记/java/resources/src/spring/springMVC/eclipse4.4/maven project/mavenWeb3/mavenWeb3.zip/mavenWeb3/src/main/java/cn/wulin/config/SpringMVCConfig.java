package cn.wulin.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

@Configuration
public class SpringMVCConfig {
	ResourcePatternResolver resourcePatternResolver = new PathMatchingResourcePatternResolver();

	/**
	 * ��ʼ��Freemarker��Դ��Ϣ
	 * @return FreeMarkerConfigurer
	 * @throws Exception
	 */
	@Bean
	public FreeMarkerConfigurer freemarkerConfigurer() throws Exception{
		//org.springframework.ui.freemarker.FreeMarkerConfigurationFactory
		System.out.println("===============freeMarkerConfigurer============");
		FreeMarkerConfigurer freeMarkerConfigurer = new FreeMarkerConfigurer();
		freeMarkerConfigurer.setDefaultEncoding("UTF-8");
		//�õ�classpath���·���µ�myFreemarker����ļ���,������Ϊ��Դ�ļ�
		Resource[] resources = resourcePatternResolver.getResources("classpath*:resources");
		String[] templateLoaderPaths = new String[resources.length];
		for (int i = 0; i < resources.length; i++) {
			String templateLoaderPath = resources[i].getURI().toString();
			templateLoaderPaths[i] = templateLoaderPath;
		}
		freeMarkerConfigurer.setTemplateLoaderPaths(templateLoaderPaths);
		freeMarkerConfigurer.setFreemarkerVariables(buildFreemarkerVariables());
		return freeMarkerConfigurer;
	}
	
	protected Map<String,Object> buildFreemarkerVariables() throws Exception{
		Map<String,Object> variables = new HashMap<String, Object>();
		List<String> headset = new ArrayList<String>();
		headset.add("/config.html");
		variables.put("heads", headset);
		return variables;
	}
}
