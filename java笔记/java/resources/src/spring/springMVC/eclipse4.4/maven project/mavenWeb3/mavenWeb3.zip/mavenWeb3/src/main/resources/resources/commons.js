
alert("我是没有 my js ,");

function myTest(){
	alert("我成功被引用了!");
}