package cn.wulin.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping(value="testMavenJarController")
public class TestMavenJarController {
	@RequestMapping(value="start")
	public String start(){
		System.out.println("ok success mavenJar !!");
		return "freemarker2/first";
	}
	
	@RequestMapping(value="start2")
	public void start2(){
		System.out.println("ok success mavenJar 222 !!!");
	}
}
