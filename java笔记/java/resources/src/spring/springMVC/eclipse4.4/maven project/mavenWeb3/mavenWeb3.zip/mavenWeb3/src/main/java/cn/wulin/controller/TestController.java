package cn.wulin.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value="testController")
public class TestController {

	@RequestMapping(value="start")
	public String start(){
		System.out.println("ok success !!");
		return "freemarker/first";
	}
	
	@RequestMapping(value="start2")
	public void start2(){
		System.out.println("ok success 222 !!!");
	}
}
