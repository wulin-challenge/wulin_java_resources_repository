package cn.wulin.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

@Configuration
public class SpringMVCConfig {
	
	ResourcePatternResolver resourcePatternResolver = new PathMatchingResourcePatternResolver();

	/**
	 * ��ʼ��Freemarker��Դ��Ϣ
	 * @return FreeMarkerConfigurer
	 * @throws Exception
	 */
//	@Bean
//	public FreeMarkerConfigurer freemarkerConfigurer() throws Exception{
//		FreeMarkerConfigurer freeMarkerConfigurer = new FreeMarkerConfigurer();
//		freeMarkerConfigurer.setDefaultEncoding("UTF-8");
//		Resource[] resources = resourcePatternResolver.getResources("classpath*:myFreemarker");
//		String[] templateLoaderPaths = new String[resources.length];
//		for (int i = 0; i < resources.length; i++) {
//			String templateLoaderPath = resources[i].getURI().toString();
//			templateLoaderPaths[i] = templateLoaderPath;
//		}
//		freeMarkerConfigurer.setTemplateLoaderPaths(templateLoaderPaths);
//		return freeMarkerConfigurer;
//	}
//	
}
