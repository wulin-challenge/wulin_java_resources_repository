package cn.wulin.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import cn.wulin.domain.User;

public class MyMultiActionController extends MultiActionController{

	public ModelAndView addUserUI4(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		model.setViewName("user/addUserUI4");
		model.addObject("list1", new String[] { "AA", "BB", "CC" });
		return model;
	}
	
	public ModelAndView addUser4(HttpServletRequest request,
			HttpServletResponse response,User user) {
		System.out.println("form4 user->username : "+user.getUsername()+" ,"
				+ " user->password : "+user.getPassword()
				+" , number -> "+user.getNumber() + " , birthday -> "+new SimpleDateFormat("yyyy-MM-dd")
		.format(user.getBirthday())+" , group : "+user.getGroup());
		return new ModelAndView("user/success");
	}
	
	protected void initBinder(HttpServletRequest request,
			ServletRequestDataBinder binder) throws Exception {
		DateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
		fmt.setTimeZone(TimeZone.getTimeZone("GMT+8"));
		CustomDateEditor dateEditor = new CustomDateEditor(fmt, true);
		binder.registerCustomEditor(Date.class, dateEditor);
	}
}
