package cn.wulin.config;
import java.util.EnumSet;
import javax.servlet.DispatcherType;
import javax.servlet.FilterRegistration;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;
import javax.servlet.SessionCookieConfig;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.request.RequestContextListener;
import org.springframework.web.context.support.XmlWebApplicationContext;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.util.IntrospectorCleanupListener;

public class DefaultWebApplicationInitializer implements WebApplicationInitializer{

	@Override
	public void onStartup(ServletContext servletContext)
			throws ServletException {
		XmlWebApplicationContext applicationContext = new XmlWebApplicationContext();
		applicationContext.setConfigLocation("classpath*:META-INF/spring/module-*.xml");  
		
		//add listener
        servletContext.addListener(new ContextLoaderListener(applicationContext));
        servletContext.addListener(new IntrospectorCleanupListener());
        servletContext.addListener(new RequestContextListener());
//add filter
        
        EnumSet<DispatcherType> dispatcherTypes = EnumSet
				.of(DispatcherType.REQUEST);
        
        FilterRegistration.Dynamic characterEncodingFilter = servletContext.addFilter("CharacterEncodingFilter", new CharacterEncodingFilter());
        characterEncodingFilter.setInitParameter("encoding", "UTF-8");
        characterEncodingFilter.setInitParameter("forceEncoding", "true");
        characterEncodingFilter.addMappingForUrlPatterns(dispatcherTypes, true, "/*");
        
        DispatcherServlet dispatcherServlet = new DispatcherServlet(applicationContext);
        
        ServletRegistration.Dynamic dispatcher = servletContext.addServlet("mvc", dispatcherServlet);
        dispatcher.setLoadOnStartup(1);
        dispatcher.addMapping("/*");
     
        
        System.out.println("--------------------sfsdfsdf---------------");
	}

}
