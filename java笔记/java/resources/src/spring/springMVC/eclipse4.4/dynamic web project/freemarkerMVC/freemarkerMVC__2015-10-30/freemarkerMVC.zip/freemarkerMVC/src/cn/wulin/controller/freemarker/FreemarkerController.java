package cn.wulin.controller.freemarker;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;


//@Controller
//@RequestMapping(value="/FreemarkerController")
public class FreemarkerController implements Controller{

	public ModelAndView handleRequest(HttpServletRequest request,HttpServletResponse response)
			throws Exception {
		System.out.println("����freemarker");
		//org.springframework.web.servlet.mvc.ParameterizableViewController
		//org.springframework.web.servlet.mvc.UrlFilenameViewController
		return new ModelAndView("/WEB-INF/jsp/test");
	
	}
	
//	public static void main(String[] args) {
//		//org.springframework.web.servlet.view.freemarker.FreeMarkerViewResolver
//		//org.springframework.web.servlet.view.freemarker.FreeMarkerViewResolver
//	}
	
//		@RequestMapping(value="/jqrsIndex",method=RequestMethod.GET)
//		public void jqrsIndex()throws Exception{
//			System.out.println("����freemarker");
//			//return null;
//		}

}
