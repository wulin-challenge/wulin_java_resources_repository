package cn.wulin.domain;

import java.util.Date;

public class User {

	/**
	 * �û���
	 */
	private String username;
	
	/**
	 * ����
	 */
	private String password;
	
	/**
	 * ����
	 */
	private Integer age;
	
	/**
	 * ����
	 */
	private float hight;
	
	/**
	 * ����
	 */
	private Date birthday;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public float getHight() {
		return hight;
	}

	public void setHight(float hight) {
		this.hight = hight;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public String toString() {
		return "username : "+username+" , password : "+password+
				" , age : "+age+" , hight : "+hight+" , birthday : "+birthday;
	}
	
	
}
