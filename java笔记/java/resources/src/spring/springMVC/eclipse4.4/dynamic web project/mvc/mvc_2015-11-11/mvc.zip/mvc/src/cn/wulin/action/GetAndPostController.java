package cn.wulin.action;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.wulin.domain.User;

@Controller
@RequestMapping(value="getAndPostController")
public class GetAndPostController {

	/**
	 * ��ת������ҳ��
	 * @return
	 */
	@RequestMapping(value="addUserUI",method=RequestMethod.GET)
	public String addUserUI(String username,String password){
		System.out.println("username : "+username+" , password : "+password);
		return "user/addUserUI";
	}
	
	/**
	 * ��ת���ɹ�ҳ��
	 * http��������:[http://localhost:8888/mvc/getAndPostController/addUserUI.do?username=wulin&password=123456]
	 * @return
	 */
	@RequestMapping(value="addUser",method=RequestMethod.POST)
	public String addUser(User user){
		System.out.println(user);
		return "user/successUI";
	}
	
	/**
	 * ����ת����
	 */
	@InitBinder
	protected void initBinder(ServletRequestDataBinder binder)throws Exception{
		DateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
		fmt.setTimeZone(TimeZone.getTimeZone("GMT+8"));
		CustomDateEditor dateEditor = new CustomDateEditor(fmt, true);
		binder.registerCustomEditor(Date.class, dateEditor);
	}
}
