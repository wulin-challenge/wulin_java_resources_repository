package cn.wulin.controller.util;

import java.beans.PropertyEditorSupport;


public class MyPropertyEdit extends PropertyEditorSupport{

	@Override
	public void setValue(Object value) {
		super.setValue(value);
	}

	@Override
	public Object getValue() {
		return super.getValue();
	}

	public String getAsText() {
		return super.getAsText();
	}

	@Override
	public void setAsText(String text) throws IllegalArgumentException {
		super.setAsText(text);
	}

}
