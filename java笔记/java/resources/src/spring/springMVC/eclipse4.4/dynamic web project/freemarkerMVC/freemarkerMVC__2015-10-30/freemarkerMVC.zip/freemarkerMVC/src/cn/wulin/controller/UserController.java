package cn.wulin.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;


public class UserController extends AbstractController{

	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String judge = request.getParameter("judge");
		if("addUserUI".equals(judge)){
			return this.addUserUI(request, response);
		}else if("addUser".equals(judge)){
			return this.addUser(request, response);
		}
		
		return null;
	}
	
	/**
	 * ��ת��AddUserUIҳ��
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	private ModelAndView addUserUI(HttpServletRequest request,HttpServletResponse response) throws Exception{
		return new ModelAndView("user/addUserUI");
	} 
	
	/**
	 * ����User
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	private ModelAndView addUser(HttpServletRequest request,HttpServletResponse response) throws Exception{
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		System.out.println("username : "+username+" , password : "+password);
		return null;
	} 
	
	
}
