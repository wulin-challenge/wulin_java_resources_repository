package cn.wulin.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value="firstController")
public class FirstController {
	
	@RequestMapping(value="first")
	public ModelAndView first(){
		System.out.println("����ɹ�!!");
		return new ModelAndView("first");
	}
}
