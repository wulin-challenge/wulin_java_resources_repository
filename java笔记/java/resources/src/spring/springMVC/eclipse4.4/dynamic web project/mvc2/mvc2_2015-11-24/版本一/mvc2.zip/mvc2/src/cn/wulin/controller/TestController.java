package cn.wulin.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping(value="testController")
public class TestController {

	@RequestMapping(value="start")
	public String start(){
		System.out.println("ok success !!");
		return "first";
	}
	
	@RequestMapping(value="/{myDate}",method=RequestMethod.GET)
	public void myDate(@PathVariable("myDate") Date mydate){
		System.out.println(new SimpleDateFormat("yyyy-MM-dd").format(mydate));
	}
	
	/**
	 * ����ת����
	 */
	@InitBinder
	protected void initBinder(ServletRequestDataBinder binder)throws Exception{
		DateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
		fmt.setTimeZone(TimeZone.getTimeZone("GMT+8"));
		CustomDateEditor dateEditor = new CustomDateEditor(fmt, true);
		binder.registerCustomEditor(Date.class, dateEditor);
	}

}
